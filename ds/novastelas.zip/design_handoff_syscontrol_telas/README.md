# Handoff: SysControl — 15 seções, mobile e desktop

## Visão geral

Redesenho completo do SysControl (PDV de autopeças, pt-BR) em duas plataformas:

- **Mobile** — 55 telas, navegação inferior de 4 abas + Mais, 390×844
- **Desktop (web e Electron)** — 20 telas, sidebar fixa de 248px, 1280×820

As 15 seções do produto estão cobertas nas duas plataformas. O design system **SysControl Design System** já está implementado no projeto de destino, então este pacote documenta **apenas as telas** — não os tokens nem os componentes base.

## Sobre os arquivos de design

Os dois arquivos `.dc.html` neste pacote são **referências de design feitas em HTML** — protótipos que mostram a aparência e o comportamento pretendidos, não código de produção para copiar. A tarefa é **recriar essas telas no ambiente já existente do projeto**, usando os componentes do design system que já estão lá.

Todo valor visual nos arquivos vem de tokens (`var(--primary)`, `var(--radius-xl)`, `var(--font-mono)`). Se o seu projeto já expõe esses tokens, a tradução é direta: onde o HTML usa `var(--primary)`, use o mesmo token no seu código.

Os arquivos abrem em qualquer navegador. Use o inspetor para medir qualquer coisa que este documento não cubra.

## Fidelidade

**Alta fidelidade.** Cores, tipografia, espaçamentos e estados são finais e saem todos do design system. Reproduza fielmente — mas usando os componentes que já existem no projeto, não recriando-os.

Uma exceção: onde o HTML desenha um componente do design system à mão (por exemplo um switch, um checkbox, um campo de formulário), isso é só porque o protótipo precisava daquele visual. **No projeto real, use o componente equivalente** (`Switch`, `Checkbox`, `Field`, `Input`, `Select`). Os componentes que o protótipo importa de verdade — `Icon`, `Badge`, `Spinner` — são os do design system.

---

## As 15 seções

Cada seção existe nas duas plataformas. A coluna "diferença" indica onde o desktop não é só o mobile mais largo.

| # | Seção | Mobile | Desktop | Diferença estrutural |
|---|---|---|---|---|
| 01 | Login e criar loja | 2 telas + erro | 2 telas | Desktop: cartão central de 440px sobre fundo `--sidebar`. Electron ganha seletor local × online |
| 02 | Onboarding | 3 passos | 3 passos | Desktop: cartão de 720px, formulários em duas colunas, cabe sem rolar |
| 03 | Painel | 4 densidades (1a–1d) | 2 telas | **Decisão: usar 1a** (grade 2×N). Desktop: 5 indicadores numa linha só |
| 04 | Venda | 5 telas | 2 telas | **A maior diferença.** Mobile: bottom sheet de pagamento. Desktop: pagamento fixo em coluna de 352px, sempre visível |
| 05 | Produtos | 5 telas | 2 telas | Mobile: cartões. Desktop: tabela de 9 colunas com ordenação e paginação |
| 06 | Serviços | 2 telas | 2 telas | Desktop: 4 indicadores + tabela com técnico e comissão calculada |
| 07 | Recibos | 2 telas | 2 telas | Mobile: filtros colapsam. Desktop: filtros abertos na horizontal, cupom em modal |
| 08 | Orçamentos | 3 telas | 2 telas | Desktop: preview do documento em 520px — é o que o cliente vê |
| 09 | Clientes e fiado | 3 telas | 2 telas | Desktop: saldo devedor como coluna; conta em modal de 680px com histórico + formulário lado a lado |
| 10 | Comissões | 3 telas | 1 tela | Desktop: checkbox por linha, barra de ação fixa no rodapé |
| 11 | Relatórios | 2 telas | 1 tela | Desktop: as duas quebras (pagamento e vendedor) lado a lado |
| 12 | Despesas | 3 telas | 2 telas | Desktop: 4 indicadores + tabela; marcador de recorrente |
| 13 | Configurações | 3 telas | 1 tela | Mobile: lista de cartões empilhados. Desktop: 4 cartões em 2×2, cada um com seu botão de salvar |
| 14 | Equipe | 3 telas | 2 telas | Desktop: tabela com cargo, comissão do mês e status |
| 15 | Auditoria de preços | 3 telas | 2 telas | Desktop: tabela de alterações com de → para e variação |

Além disso o mobile tem duas faixas transversais:

- **Estados vazios** — 4 telas (busca sem resultado, sem clientes, sem pendências, sem despesas)
- **Carregando** — 9 esqueletos, um por seção

---

## Padrões que valem para todas as telas

Implemente estes primeiro. Eles aparecem em quase toda tela e definem 80% do trabalho.

### Shell mobile

```
390×844
├─ status bar          44px, hora em var(--font-mono) 13px/600
├─ app bar             44px, título em var(--font-display) 20px/600
│                      + filtros de período em chips de 32px quando houver
├─ conteúdo            flex:1, padding 16px, gap 12px, background var(--app-canvas)
└─ tab bar             78px (62px + 16px de safe area), background var(--background)
                       borda superior 1px var(--border)
```

**Tab bar — 5 itens fixos:** Painel (`layout-dashboard`), Vendas (`shopping-cart`), Produtos (`package`), Clientes (`users`), Mais (`menu`). Ícone 22px, label 10px/600 quando ativo e 500 quando não. Ativo em `var(--primary)`, resto em `var(--muted-foreground)`.

**Aba Mais** — as 10 seções que não cabem na barra, em três grupos rotulados:
- OPERAÇÃO: Recibos, Orçamentos, Serviços
- GESTÃO: Relatórios, Despesas, Comissões, Auditoria de preços
- CADASTROS E SISTEMA: Fornecedores, Equipe, Configurações

Linhas de 12px de padding vertical, ícone 19px em `var(--icon-muted)`, chevron à direita, badge numérico quando houver pendência.

### Shell desktop

```
1280×820
├─ sidebar   248px fixa, background var(--sidebar)
│            ├─ marca      60px, quadrado teal 30px + wordmark 17px
│            ├─ nav        13 itens de 36px, gap 2px, padding 12px 10px
│            └─ usuário    rodapé, avatar 32px + nome + cargo + ícone power
└─ main      flex:1
             ├─ topbar     56px, título 18px + controles à direita
             └─ conteúdo   padding 20-24px, background var(--app-canvas)
```

**Nav desktop — 13 itens**, na ordem: Painel, Venda, Produtos, Serviços, Recibos, Orçamentos (badge 2), Clientes, Comissões (badge 28), Relatórios, Despesas, Equipe, Auditoria de preços, Configurações. Item ativo: `background: var(--primary)`, texto `var(--white)`, peso 600. Inativo: `var(--sidebar-foreground)`, peso 500.

**Nota:** o protótipo do desktop lista **Caixa** na sidebar em algumas telas antigas — isso está errado. Caixa é um **perfil de acesso**, não uma seção; o lugar dela é como cargo em Equipe, ao lado de Vendedor e Técnico. Não implemente Caixa como item de navegação.

### Tabelas (desktop)

Toda tabela segue o mesmo molde:

- Container: `var(--card)`, borda 1px `var(--border)`, radius `var(--radius-xl)`, `var(--shadow-xs)`
- Cabeçalho: `background: var(--content2)`, padding 11px 18px, texto 10px/600 ALL CAPS com `var(--tracking-caps)` em `var(--muted-foreground)`
- Linhas: padding 12px 18px, borda superior 1px `var(--border)`, texto 13px/500
- Hover de linha: `background: var(--hover-surface)`, transição 120ms
- Colunas ordenáveis: ícone `chevrons-up-down` 12px ao lado do rótulo
- **Números sempre à direita**, em `var(--font-mono)` com `font-variant-numeric: tabular-nums`
- Ações por linha: `more-horizontal` 17px em `var(--icon-muted)`, coluna de 28px
- Larguras: colunas de dado fixas em px, coluna de descrição `flex:1` com `min-width:170px` (sem isso o cabeçalho desalinha em telas estreitas)

### Modais (desktop) vs bottom sheets (mobile)

A mesma ação usa formas diferentes:

| | Mobile | Desktop |
|---|---|---|
| Container | Bottom sheet, radius `var(--radius-2xl)` só no topo | Modal centralizado, radius `var(--radius-xl)` |
| Largura | 100% | 560px (formulário), 680px (com duas colunas), 720px (importação) |
| Posição | Ancorado embaixo, com alça de 38×4px | Centro da área de conteúdo — **`padding-left: 248px`** para não cobrir a sidebar |
| Scrim | `var(--overlay)` + blur 2px | idem |
| Botões | Empilhados ou lado a lado, altura 54-56px | Alinhados à direita, altura 44px |

### Estados vazios

Sempre: disco de 64px (`var(--content2)`, ícone 26px em `var(--icon-muted)`) → título 17px/600 → explicação 14px/400 em `var(--muted-foreground)` com `text-wrap: pretty` → **um botão nomeando a próxima ação**. Nunca "Nenhum resultado" sozinho.

### Esqueletos de carregamento

Cabeçalho e navegação ficam **reais**; só o que vem do servidor pisca. Blocos com `background: var(--skeleton-from)` (secundário) ou `var(--skeleton-to)` (valores em destaque), animação `1.4s ease-in-out infinite` alternando opacidade 1 → 0.5 → 1. Larguras variadas entre linhas para não parecer um padrão.

### Modo escuro

Já resolvido: as telas usam só tokens, então basta a classe `dark` no ancestral. Uma exceção proposital — o leitor de código de barras é escuro nos dois temas.

---

## Detalhe por seção

Abaixo, o que não se deduz olhando o arquivo. Para medidas e cores exatas, inspecione o HTML.

### 04 · Venda — a tela mais importante

**Mobile**, quatro etapas: carrinho vazio → resultados da busca → carrinho com cliente → bottom sheet de pagamento → recibo.

**Desktop**, uma tela só, duas colunas:

- **Esquerda** (`flex:1`): busca (44px, com contador de resultados) + botão Ler código → tabela de resultados → carrinho (`flex:1`, cresce) → cartão do cliente
- **Direita** (352px fixa, `border-left`): mão de obra + acréscimo/desconto → **total** → formas de pagamento em folha → linha "Pago / Falta" → checkbox CPF → **Concluir venda** (56px, `var(--success)`) + dica de atalhos

Regras do carrinho:
- Stepper de quantidade: 32px de altura, `−` / número / `+`. Quando a quantidade é 1, o `−` vira `trash-2`
- Cada linha mostra preço unitário e total, ambos alinhados à direita em larguras fixas
- Pagamento em folha: várias formas somam até fechar o total. "Falta" em `var(--money-negative)` enquanto houver saldo; o botão Concluir fica com `opacity: var(--disabled-opacity)` até zerar

**Electron:** ao concluir, o recibo sai direto na térmica sem diálogo. O modal de confirmação mostra a impressora, o formato (58mm) e a fila de sincronização.

### 03 · Painel — quatro densidades, escolha 1a

O mobile traz quatro variantes lado a lado (`1a`–`1d`). **A decisão foi `1a`: grade 2×N de cartões.** As outras três ficam no arquivo como registro, não implemente.

Indicadores, na ordem: Faturamento, Lucro líquido, Vendas, Mão de obra, Comissões. Depois: Venda potencial (cartão `var(--primary-soft)`) e Situação do estoque (zerados em `var(--danger)`, baixo em `var(--warning-icon)`, ambos navegáveis).

Desktop: os cinco indicadores numa linha (`repeat(5,1fr)`), depois Venda potencial e Estoque num split `1.7fr / 1fr`.

**Electron offline:** um alerta `var(--info-soft)` avisa que os números são daquele terminal, e o rótulo dos cartões muda ("só este terminal").

### 05 · Produtos

Colunas do desktop: Cód · Descrição · Tipo · Custo · Venda · Margem · Saldo · Situação · ações. Margem é **calculada** ((venda − custo) / venda), em `var(--money-positive)`.

Situação vem do saldo: `> mínimo` → Em estoque (success) · `≤ mínimo` → Estoque baixo (warning) · `0` → Esgotado (danger). Saldo baixo ou zero também colore o número.

Importação em lote (modal de 720px): arquivo lido → resumo novos × duplicados em dois cartões → radio de o que fazer com os duplicados → aviso de que nada é gravado até confirmar.

### 09 · Clientes e fiado

Saldo devedor é a informação mais consultada — no desktop é coluna própria, em `var(--money-negative)`, e quem deve ganha botão **Registrar pagamento** direto na linha.

Conta do cliente (modal de 680px): à esquerda o saldo em cartão `var(--danger-soft)`, vendas em aberto e histórico de pagamentos; à direita, num painel `var(--content2)`, o formulário de recebimento com atalhos Tudo/Metade e a previsão de "Saldo depois".

### 10 · Comissões

Checkbox por linha + selecionar tudo no cabeçalho. Comissões já pagas ficam com `opacity: var(--disabled-opacity)` e checkbox desabilitado. Barra de ação no rodapé mostra quantas estão selecionadas, o total e o botão de baixa. Após a baixa, toast verde com **Desfazer**.

Base de cálculo e taxa aparecem por linha — a taxa varia por tipo (peças 3%, mão de obra 10%, pneus 5%) e pode ser alterada por venda.

### 13 · Configurações

Quatro blocos, **cada um com seu próprio botão de salvar** (não um "Salvar tudo"):

1. Identidade da loja — nome, endereço, telefone, CNPJ, logo. Sai impresso nos recibos
2. Comissões — os três percentuais padrão, com aviso de que só valem para vendas futuras
3. Usuários e cargos — lista de usuários + os cargos (Vendedor, Técnico, **Caixa**)
4. Ferramentas do sistema — link de acesso, impressora, migração

Impressora e migração **só existem no Electron**. Migração é destrutiva: borda `var(--danger-soft-border)`, botão outline em `var(--danger)`, aviso explícito de que não pode ser desfeita.

### 15 · Auditoria de preços

Registro de toda alteração de preço: quando, produto, de → para, variação em %, efeito na margem, quem alterou, origem (manual ou importação). Variação positiva em `var(--money-positive)`, negativa em `var(--money-negative)`. O detalhe abre em modal com o antes/depois completo.

---

## Ordem de implementação sugerida

1. **Shells** — tab bar mobile e sidebar/topbar desktop. Tudo depende deles
2. **Painel** — só leitura, valida se os tokens estão certos
3. **Venda** — a mais importante e a mais diferente do que existe hoje
4. **Tabelas** — Produtos, Recibos, Clientes, Comissões, Despesas. Uma vez que a primeira funcione, as outras são variação de colunas
5. **Modais e sheets** — o padrão se repete em oito seções
6. **Auxiliares** — Serviços, Orçamentos, Equipe, Auditoria, Configurações, Onboarding, Login
7. **Estados vazios e esqueletos** — por último, mas não opcionais

---

## Conteúdo e copy

Todo texto nas telas é **pt-BR e literal** — use como está. As regras que segui, resumidas do design system:

- Verbos no imperativo, nunca "você": "Finalizar venda", "Ler código", "Dar entrada"
- Sentence case em tudo, exceto cabeçalhos de tabela e captions de indicador (ALL CAPS + `var(--tracking-caps)`)
- Dinheiro sempre `R$ 1.050,00` — vírgula decimal, ponto de milhar
- Deltas com sinal explícito: `+12,4%`, `− R$ 40,50`
- Vocabulário de status fixo: Pago · Pendente · Cancelado · Em estoque · Estoque baixo · Esgotado · Rascunho
- Sem emoji, sem exclamação

## Dados de exemplo

Loja fictícia **Barba Pneus** (Loja #4, Osasco/SP), dois usuários: Maria Barbosa (administrador, balcão) e João Ferreira (técnico). Catálogo de pneus, peças e acessórios. Volume de loja movimentada: 37 vendas/dia, 214/semana, 148 produtos, 86 clientes.

Os valores são consistentes entre telas — a venda #2041 tem os mesmos itens no carrinho, no recibo e no histórico. Se substituir por dados reais, mantenha a consistência: números que não fecham entre telas confundem quem revisa.

## Arquivos neste pacote

- `SysControl Mobile.dc.html` — 55 telas, 15 seções + estados vazios + esqueletos
- `SysControl Desktop.dc.html` — 20 telas, 15 seções, web e Electron

Ambos abrem direto no navegador. O canvas é organizado em seções na horizontal — use pan lateral para percorrer cada fluxo.

## Pendências conhecidas

- **Caixa na sidebar do desktop** — está errado, é perfil de acesso e não seção. Não implemente como navegação
- **Fornecedores** — aparece na aba Mais do mobile mas não tem tela desenhada. Não veio spec
- **Modo escuro** — funciona por token, mas não foi revisado tela por tela no desktop
