const {Card,Badge,Button,IconButton,Input,Icon,Avatar,Divider,Progress,EmptyState,Chip,StatCard,Tabs}=window.SysControlDesignSystem_02daf6;

/* ---------- chrome ---------- */
function StatusBar(){
  return <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",height:44,
    padding:"0 22px",flexShrink:0,background:"var(--sidebar)",color:"var(--sidebar-brand)",
    fontFamily:"var(--font-sans)",fontSize:13,fontWeight:600,letterSpacing:"0.01em"}}>
    <span style={{fontVariantNumeric:"tabular-nums"}}>14:32</span>
    <span style={{display:"flex",alignItems:"center",gap:5,opacity:.9}}>
      <Icon name="signal" size={14}/><Icon name="wifi" size={14}/><Icon name="battery-full" size={16}/></span>
  </div>;
}
function AppBar({title,subtitle,left,right,tone="teal"}){
  const dark=tone==="teal";
  return <div style={{display:"flex",alignItems:"center",gap:12,height:56,padding:"0 16px",flexShrink:0,
    background:dark?"var(--sidebar)":"var(--background)",
    borderBottom:dark?"none":"1px solid var(--border)"}}>
    {left}
    <div style={{flex:1,minWidth:0}}>
      <div style={{fontFamily:"var(--font-display)",fontSize:17,fontWeight:600,letterSpacing:"var(--tracking-heading)",
        color:dark?"var(--sidebar-brand)":"var(--foreground)",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{title}</div>
      {subtitle?<div style={{fontSize:12,color:dark?"var(--sidebar-muted)":"var(--muted-foreground)"}}>{subtitle}</div>:null}
    </div>
    {right}
  </div>;
}
function TabBar({active,onChange}){
  const tabs=[["painel","Painel","layout-dashboard"],["pdv","Vender","shopping-cart"],["estoque","Estoque","package"],["caixa","Caixa","banknote"],["mais","Mais","menu"]];
  return <nav style={{display:"flex",flexShrink:0,background:"var(--background)",borderTop:"1px solid var(--border)",
    padding:"6px 4px 22px"}}>
    {tabs.map(([k,l,ic])=>{const on=active===k;
      return <button key={k} onClick={()=>onChange(k)} style={{flex:1,display:"flex",flexDirection:"column",
        alignItems:"center",justifyContent:"center",gap:3,minHeight:48,border:0,background:"transparent",cursor:"pointer",
        color:on?"var(--primary)":"var(--muted-foreground)",fontFamily:"var(--font-sans)",fontSize:11,
        fontWeight:on?600:500,transition:"var(--transition-colors)"}}>
        <Icon name={ic} size={21} strokeWidth={on?2.2:1.8}/>{l}</button>;})}
  </nav>;
}
function Sheet({open,onClose,title,children,footer}){
  if(!open) return null;
  return <div onClick={onClose} style={{position:"absolute",inset:0,zIndex:40,display:"flex",flexDirection:"column",
    justifyContent:"flex-end",background:"var(--overlay)",animation:"m-fade 150ms ease"}}>
    <div onClick={e=>e.stopPropagation()} style={{background:"var(--card)",
      borderRadius:"var(--radius-2xl) var(--radius-2xl) 0 0",padding:"10px 16px 24px",
      boxShadow:"var(--shadow-large)",animation:"m-up 200ms cubic-bezier(0.16,1,0.3,1)",maxHeight:"82%",display:"flex",flexDirection:"column"}}>
      <div style={{width:38,height:4,borderRadius:99,background:"var(--content3)",margin:"0 auto 14px"}}/>
      <div style={{fontFamily:"var(--font-display)",fontSize:18,fontWeight:600,letterSpacing:"var(--tracking-heading)",marginBottom:14}}>{title}</div>
      <div style={{overflowY:"auto",flex:1,display:"flex",flexDirection:"column",gap:14}}>{children}</div>
      {footer?<div style={{paddingTop:16,display:"flex",gap:8}}>{footer}</div>:null}
      <style>{"@keyframes m-fade{from{opacity:0}to{opacity:1}}@keyframes m-up{from{transform:translateY(100%)}to{transform:none}}"}</style>
    </div>
  </div>;
}

/* ---------- screens ---------- */
function MPainel({go}){
  const D=window.SC_DATA;
  return <div style={{flex:1,overflowY:"auto",background:"var(--app-canvas)"}}>
    <div style={{background:"var(--sidebar)",padding:"4px 16px 26px",color:"var(--sidebar-brand)"}}>
      <div style={{fontSize:12,color:"var(--sidebar-muted)",letterSpacing:"var(--tracking-caps)",textTransform:"uppercase",fontWeight:600}}>Faturamento hoje</div>
      <div style={{fontFamily:"var(--font-display)",fontSize:38,fontWeight:600,letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums",marginTop:4}}>{window.SC_BRL(14280.5)}</div>
      <div style={{display:"flex",alignItems:"center",gap:6,marginTop:6,fontSize:13,color:"var(--primary-soft-foreground)"}}>
        <Icon name="trending-up" size={15}/><span style={{fontWeight:600}}>+12,4%</span><span style={{opacity:.75}}>vs. ontem</span></div>
    </div>
    <div style={{padding:16,display:"flex",flexDirection:"column",gap:14,marginTop:-14}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        <StatCard label="Vendas" value="63" unit="pedidos" icon="receipt" padding={16}/>
        <StatCard label="Crítico" value="3" unit="itens" icon="triangle-alert" tone="warning"/>
      </div>
      <Card padding={16}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
          <span style={{fontFamily:"var(--font-display)",fontSize:15,fontWeight:600,letterSpacing:"var(--tracking-heading)"}}>Reposição urgente</span>
          <Button variant="link" size="sm" onClick={()=>go("estoque")}>Ver tudo</Button>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {D.pecas.filter(p=>p.qtd<p.min).map(p=><div key={p.id} style={{display:"flex",flexDirection:"column",gap:6}}>
            <div style={{display:"flex",justifyContent:"space-between",gap:8,fontSize:14}}>
              <span style={{fontWeight:500}}>{p.nome}</span>
              <span style={{fontFamily:"var(--font-mono)",fontSize:13,color:"var(--muted-foreground)",whiteSpace:"nowrap"}}>{p.qtd}/{p.min}</span></div>
            <Progress value={p.qtd} max={p.min} size="sm" tone={p.qtd===0?"danger":"warning"}/>
          </div>)}
        </div>
      </Card>
      <Card padding={16}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:4}}>
          <span style={{fontFamily:"var(--font-display)",fontSize:15,fontWeight:600,letterSpacing:"var(--tracking-heading)"}}>Últimas vendas</span>
          <Button variant="link" size="sm">Ver todas</Button>
        </div>
        {D.vendas.slice(0,4).map((v,i)=><div key={v.id} style={{display:"flex",alignItems:"center",gap:12,
          padding:"12px 0",borderTop:i?"1px solid var(--border)":"none"}}>
          <Avatar name={v.cliente} size={36} tone={v.t==="danger"?"neutral":"primary"}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:14,fontWeight:500,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{v.cliente}</div>
            <div style={{fontSize:12,color:"var(--muted-foreground)"}}>#{v.id} · {v.hora} · {v.pag}</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontFamily:"var(--font-mono)",fontSize:14,fontWeight:600,fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(v.total)}</div>
            <Badge tone={v.t} dot style={{marginTop:3}}>{v.st}</Badge>
          </div>
        </div>)}
      </Card>
    </div>
  </div>;
}

function MPdv(){
  const D=window.SC_DATA;
  const [cart,setCart]=React.useState([{...D.pecas[0],qty:2},{...D.pecas[4],qty:4}]);
  const [sheet,setSheet]=React.useState(null);
  const [q,setQ]=React.useState("");
  const list=D.pecas.filter(p=>p.nome.toLowerCase().includes(q.toLowerCase())||p.sku.toLowerCase().includes(q.toLowerCase()));
  const total=cart.reduce((s,x)=>s+x.preco*x.qty,0);
  const add=p=>setCart(c=>{const i=c.findIndex(x=>x.id===p.id);if(i>-1){const n=[...c];n[i]={...n[i],qty:n[i].qty+1};return n;}return[...c,{...p,qty:1}];});
  return <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--app-canvas)",minHeight:0}}>
    <div style={{padding:"12px 16px",display:"flex",gap:8,background:"var(--background)",borderBottom:"1px solid var(--border)"}}>
      <Input icon="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar peça ou código"/>
      <IconButton icon="barcode" label="Ler código de barras" variant="primary" size="lg"/>
    </div>
    <div style={{flex:1,overflowY:"auto",padding:"12px 16px",display:"flex",flexDirection:"column",gap:10}}>
      {list.length===0?<EmptyState icon="search-x" title="Nada encontrado" description="Verifique o código digitado."/>:null}
      {list.map(p=><Card key={p.id} padding={14} interactive onClick={()=>add(p)}
        style={{flexDirection:"row",alignItems:"center",gap:12}}>
        <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:42,height:42,flexShrink:0,
          borderRadius:"var(--radius-md)",background:"var(--content2)",color:"var(--muted-foreground)"}}><Icon name="package" size={20}/></span>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:14,fontWeight:500,lineHeight:1.3}}>{p.nome}</div>
          <div style={{fontFamily:"var(--font-mono)",fontSize:12,color:"var(--muted-foreground)",marginTop:2}}>{p.sku} · {p.qtd} un.</div>
        </div>
        <div style={{textAlign:"right",flexShrink:0}}>
          <div style={{fontFamily:"var(--font-mono)",fontSize:14,fontWeight:600,fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(p.preco)}</div>
          <Badge tone={p.t} style={{marginTop:4}}>{p.st}</Badge>
        </div>
      </Card>)}
    </div>
    <div style={{flexShrink:0,padding:"12px 16px",background:"var(--background)",borderTop:"1px solid var(--border)",
      display:"flex",alignItems:"center",gap:12,boxShadow:"var(--shadow-medium)"}}>
      <div style={{flex:1}}>
        <div style={{fontSize:12,color:"var(--muted-foreground)"}}>{cart.reduce((s,x)=>s+x.qty,0)} itens no carrinho</div>
        <div style={{fontFamily:"var(--font-display)",fontSize:22,fontWeight:600,letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(total)}</div>
      </div>
      <Button size="lg" icon="shopping-cart" onClick={()=>setSheet("cart")} disabled={!cart.length}>Ver carrinho</Button>
    </div>
    <Sheet open={sheet==="cart"} onClose={()=>setSheet(null)} title="Carrinho"
      footer={<Button variant="success" size="lg" icon="check" fullWidth onClick={()=>{setSheet(null);setCart([]);}}>Finalizar · {window.SC_BRL(total)}</Button>}>
      {cart.map(x=><div key={x.id} style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:14,fontWeight:500}}>{x.nome}</div>
          <div style={{fontFamily:"var(--font-mono)",fontSize:12,color:"var(--muted-foreground)"}}>{x.sku} · {window.SC_BRL(x.preco)}</div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:6}}>
          <IconButton icon="minus" label="Menos" variant="outline" size="sm" onClick={()=>setCart(c=>c.map(y=>y.id===x.id?{...y,qty:Math.max(1,y.qty-1)}:y))}/>
          <span style={{minWidth:22,textAlign:"center",fontFamily:"var(--font-mono)",fontVariantNumeric:"tabular-nums"}}>{x.qty}</span>
          <IconButton icon="plus" label="Mais" variant="outline" size="sm" onClick={()=>setCart(c=>c.map(y=>y.id===x.id?{...y,qty:y.qty+1}:y))}/>
        </div>
      </div>)}
      <Divider/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
        <span style={{fontSize:14,fontWeight:600}}>Total</span>
        <span style={{fontFamily:"var(--font-display)",fontSize:24,fontWeight:600,letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(total)}</span>
      </div>
    </Sheet>
  </div>;
}

function MEstoque(){
  const D=window.SC_DATA;
  const [cat,setCat]=React.useState("Todos");
  const cats=["Todos","Freios","Suspensão","Motor","Elétrica","Filtros"];
  const rows=D.pecas.filter(p=>cat==="Todos"||p.cat===cat);
  return <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--app-canvas)",minHeight:0}}>
    <div style={{padding:"12px 16px",background:"var(--background)",borderBottom:"1px solid var(--border)",display:"flex",flexDirection:"column",gap:10}}>
      <Input icon="search" placeholder="Buscar no estoque"/>
      <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:2}}>
        {cats.map(c=><Chip key={c} selected={cat===c} onClick={()=>setCat(c)} style={{flexShrink:0}}>{c}</Chip>)}
      </div>
    </div>
    <div style={{flex:1,overflowY:"auto",padding:16,display:"flex",flexDirection:"column",gap:10}}>
      {rows.map(p=><Card key={p.id} padding={14} interactive>
        <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:14,fontWeight:500,lineHeight:1.3}}>{p.nome}</div>
            <div style={{fontFamily:"var(--font-mono)",fontSize:12,color:"var(--muted-foreground)",marginTop:2}}>{p.sku} · {p.marca}</div>
          </div>
          <Badge tone={p.t} dot>{p.st}</Badge>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:14,marginTop:12}}>
          <div style={{flex:1}}><Progress value={p.qtd} max={Math.max(p.min*2,p.qtd)} size="sm" tone={p.qtd===0?"danger":(p.qtd<p.min?"warning":"success")}/></div>
          <span style={{fontFamily:"var(--font-mono)",fontSize:13,color:"var(--muted-foreground)",fontVariantNumeric:"tabular-nums"}}>{p.qtd} un.</span>
          <span style={{fontFamily:"var(--font-mono)",fontSize:14,fontWeight:600,fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(p.preco)}</span>
        </div>
      </Card>)}
    </div>
  </div>;
}

function MCaixa(){
  const D=window.SC_DATA;
  const ent=D.caixa.filter(m=>m.e).reduce((s,m)=>s+m.valor,0);
  const sai=D.caixa.filter(m=>!m.e).reduce((s,m)=>s+m.valor,0);
  const [sheet,setSheet]=React.useState(false);
  return <div style={{flex:1,overflowY:"auto",background:"var(--app-canvas)",position:"relative"}}>
    <div style={{padding:16,display:"flex",flexDirection:"column",gap:14}}>
      <Card padding={18}>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
          <span style={{width:8,height:8,borderRadius:99,background:"var(--success)"}}/>
          <span style={{fontSize:12,fontWeight:600,letterSpacing:"var(--tracking-caps)",textTransform:"uppercase",color:"var(--muted-foreground)"}}>Caixa 01 · aberto às 08:00</span>
        </div>
        <div style={{fontFamily:"var(--font-display)",fontSize:34,fontWeight:600,letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(ent-sai)}</div>
        <div style={{display:"flex",gap:20,marginTop:12}}>
          <div><div style={{fontSize:12,color:"var(--muted-foreground)"}}>Entradas</div>
            <div style={{fontFamily:"var(--font-mono)",fontSize:15,fontWeight:600,color:"var(--money-positive)",fontVariantNumeric:"tabular-nums"}}>+ {window.SC_BRL(ent)}</div></div>
          <div><div style={{fontSize:12,color:"var(--muted-foreground)"}}>Saídas</div>
            <div style={{fontFamily:"var(--font-mono)",fontSize:15,fontWeight:600,color:"var(--money-negative)",fontVariantNumeric:"tabular-nums"}}>− {window.SC_BRL(sai)}</div></div>
        </div>
        <div style={{display:"flex",gap:8,marginTop:16}}>
          <Button variant="outline" size="sm" icon="arrow-up-right" fullWidth onClick={()=>setSheet(true)}>Sangria</Button>
          <Button variant="outline" size="sm" icon="arrow-down-left" fullWidth>Suprimento</Button>
        </div>
      </Card>
      <div style={{fontSize:12,fontWeight:600,letterSpacing:"var(--tracking-caps)",textTransform:"uppercase",color:"var(--muted-foreground)",paddingLeft:2}}>Movimentações</div>
      <Card padding={0}>
        {D.caixa.slice().reverse().map((m,i)=><div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",borderTop:i?"1px solid var(--border)":"none"}}>
          <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:34,height:34,flexShrink:0,
            borderRadius:"var(--radius-full)",background:m.e?"var(--success-soft)":"var(--danger-soft)",
            color:m.e?"var(--success)":"var(--danger)"}}><Icon name={m.e?"arrow-down-left":"arrow-up-right"} size={16}/></span>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:14,fontWeight:500}}>{m.desc}</div>
            <div style={{fontSize:12,color:"var(--muted-foreground)"}}>{m.hora} · {m.forma}</div>
          </div>
          <span style={{fontFamily:"var(--font-mono)",fontSize:14,fontWeight:600,fontVariantNumeric:"tabular-nums",
            color:m.e?"var(--money-positive)":"var(--money-negative)"}}>{(m.e?"+ ":"− ")+window.SC_BRL(m.valor)}</span>
        </div>)}
      </Card>
    </div>
    <Sheet open={sheet} onClose={()=>setSheet(false)} title="Sangria de caixa"
      footer={<><Button variant="ghost" size="lg" fullWidth onClick={()=>setSheet(false)}>Cancelar</Button>
        <Button variant="destructive" size="lg" fullWidth icon="check" onClick={()=>setSheet(false)}>Confirmar</Button></>}>
      <Input mono suffix="BRL" defaultValue="500,00"/>
      <Chip>Depósito bancário</Chip>
    </Sheet>
  </div>;
}

function MMais(){
  const items=[["Vendas","receipt"],["Clientes","users"],["Fornecedores","truck"],["Relatórios","chart-column"],["Etiquetas e código de barras","barcode"],["Usuários e permissões","shield-check"],["Configurações","settings"],["Sair","log-out"]];
  return <div style={{flex:1,overflowY:"auto",background:"var(--app-canvas)",padding:16,display:"flex",flexDirection:"column",gap:14}}>
    <Card padding={16} style={{flexDirection:"row",alignItems:"center",gap:14}}>
      <Avatar name="Marcos Ribeiro" size={48}/>
      <div style={{flex:1}}>
        <div style={{fontFamily:"var(--font-display)",fontSize:16,fontWeight:600,letterSpacing:"var(--tracking-heading)"}}>Marcos Ribeiro</div>
        <div style={{fontSize:13,color:"var(--muted-foreground)"}}>Gerente · Loja Centro</div>
      </div>
      <IconButton icon="chevron-right" label="Ver perfil"/>
    </Card>
    <Card padding={0}>
      {items.map(([l,ic],i)=><button key={l} style={{display:"flex",alignItems:"center",gap:14,width:"100%",minHeight:52,
        padding:"0 16px",border:0,borderTop:i?"1px solid var(--border)":"none",background:"transparent",cursor:"pointer",
        fontFamily:"var(--font-sans)",fontSize:15,color:l==="Sair"?"var(--danger)":"var(--foreground)",textAlign:"left"}}>
        <Icon name={ic} size={19} color={l==="Sair"?"var(--danger)":"var(--muted-foreground)"}/>
        <span style={{flex:1}}>{l}</span>
        {l!=="Sair"?<Icon name="chevron-right" size={16} color="var(--zinc-400)"/>:null}
      </button>)}
    </Card>
    <div style={{textAlign:"center",fontSize:12,color:"var(--muted-foreground)",paddingTop:4}}>SysControl 3.4.1 · Sincronizado há 2 min</div>
  </div>;
}

function MobileApp({initial="painel",dark=false,onToggleTheme}){
  const [tab,setTab]=React.useState(initial);
  const T={painel:["Painel","Loja Centro · 06 ago",MPainel,"teal"],pdv:["Nova venda","Pedido #2042",MPdv,"light"],
    estoque:["Estoque","148 peças cadastradas",MEstoque,"light"],caixa:["Caixa","06 de agosto",MCaixa,"light"],mais:["Mais",null,MMais,"light"]};
  const [title,sub,Screen,tone]=T[tab];
  return <div style={{width:390,height:844,display:"flex",flexDirection:"column",overflow:"hidden",position:"relative",
    background:"var(--background)",borderRadius:44,border:"1px solid var(--border)",boxShadow:"var(--shadow-large)"}}>
    <StatusBar/>
    <AppBar title={title} subtitle={sub} tone={tab==="painel"?"teal":"light"}
      right={<div style={{display:"flex",gap:2}}>
        <IconButton icon={dark?"sun":"moon"} label={dark?"Tema claro":"Tema escuro"} onClick={onToggleTheme}
          style={tab==="painel"?{color:"var(--sidebar-foreground)"}:undefined}/>
        {tab==="painel"?<IconButton icon="bell" label="Notificações" style={{color:"var(--sidebar-foreground)"}}/>
          :<IconButton icon="ellipsis-vertical" label="Opções"/>}</div>}/>
    <Screen go={setTab}/>
    <TabBar active={tab} onChange={setTab}/>
  </div>;
}
Object.assign(window,{MobileApp,StatusBar,AppBar,TabBar,Sheet,MPainel,MPdv,MEstoque,MCaixa,MMais});
