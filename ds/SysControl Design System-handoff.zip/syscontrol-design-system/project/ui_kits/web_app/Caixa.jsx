const {Card,CardHeader,StatCard,DataTable,Badge,Button,IconButton,Divider,Modal,Field,Input,Select,Alert,Tabs,RadioGroup}=window.SysControlDesignSystem_02daf6;

function CaixaScreen(){
  const D=window.SC_DATA;
  const [modal,setModal]=React.useState(null);
  const ent=D.caixa.filter(m=>m.e).reduce((s,m)=>s+m.valor,0);
  const sai=D.caixa.filter(m=>!m.e).reduce((s,m)=>s+m.valor,0);
  const formas=[["Dinheiro",512.7+300-642],["Pix",4606.7],["Débito",179],["Crédito",389.8],["Boleto",5310]];
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Alert tone="info" title="Caixa 01 aberto desde 08:00 por Marcos Ribeiro"
      action={<Button variant="link" size="sm" onClick={()=>setModal("fechar")}>Fechar caixa</Button>}/>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16}}>
      <StatCard label="Saldo em caixa" value={window.SC_BRL(ent-sai)} icon="banknote" tone="primary"/>
      <StatCard label="Entradas" value={window.SC_BRL(ent)} unit={D.caixa.filter(m=>m.e).length+" lanç."} icon="arrow-down-left" tone="success"/>
      <StatCard label="Saídas" value={window.SC_BRL(sai)} unit={D.caixa.filter(m=>!m.e).length+" lanç."} icon="arrow-up-right" tone="danger"/>
      <StatCard label="Em dinheiro" value={window.SC_BRL(170.7)} unit="conferir" icon="wallet" tone="warning"/>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1.7fr 1fr",gap:16,alignItems:"start"}}>
      <Card padding={0}>
        <div style={{padding:"20px 20px 0"}}>
          <CardHeader title="Movimentações de hoje" description="Caixa 01 · 06 de agosto"
            action={<div style={{display:"flex",gap:8}}>
              <Button variant="outline" size="sm" icon="arrow-up-right" onClick={()=>setModal("sangria")}>Sangria</Button>
              <Button size="sm" icon="arrow-down-left" onClick={()=>setModal("suprimento")}>Suprimento</Button></div>}/>
        </div>
        <DataTable dense rows={D.caixa} columns={[
          {key:"hora",header:"Hora",mono:true,width:70},
          {key:"tipo",header:"Tipo",width:110,render:r=><Badge tone={r.tipo==="Venda"?"success":(r.e?"info":"warning")}>{r.tipo}</Badge>},
          {key:"desc",header:"Descrição",wrap:true},
          {key:"forma",header:"Forma",width:110},
          {key:"valor",header:"Valor",align:"right",mono:true,width:130,
            render:r=><span style={{color:r.e?"var(--money-positive)":"var(--money-negative)",fontWeight:"var(--weight-semibold)"}}>
              {(r.e?"+ ":"− ")+window.SC_BRL(r.valor)}</span>},
          {key:"a",header:"",align:"right",width:44,render:()=><IconButton icon="receipt-text" label="Ver comprovante" size="sm"/>}
        ]}/>
      </Card>
      <Card>
        <CardHeader title="Por forma de pagamento" description="Total recebido hoje"/>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {formas.map(([l,v])=><div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:"var(--text-body)"}}>{l}</span>
            <span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-body)",fontWeight:"var(--weight-semibold)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(v)}</span>
          </div>)}
          <Divider/>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
            <span style={{fontSize:"var(--text-body)",fontWeight:"var(--weight-semibold)"}}>Total</span>
            <span style={{fontFamily:"var(--font-display)",fontSize:"var(--text-h3)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(formas.reduce((s,x)=>s+x[1],0))}</span>
          </div>
        </div>
      </Card>
    </div>

    <Modal open={modal==="sangria"||modal==="suprimento"} onClose={()=>setModal(null)} size="sm"
      title={modal==="sangria"?"Sangria de caixa":"Suprimento de caixa"} description="Caixa 01 · Marcos Ribeiro"
      footer={<><Button variant="ghost" onClick={()=>setModal(null)}>Cancelar</Button>
        <Button variant={modal==="sangria"?"destructive":"success"} icon="check" onClick={()=>setModal(null)}>Confirmar</Button></>}>
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <Field label="Valor" required><Input mono suffix="BRL" defaultValue="500,00"/></Field>
        <Field label="Motivo" required><Select placeholder="Selecione" options={["Depósito bancário","Pagamento de fornecedor","Troco","Despesa operacional"]}/></Field>
        <Field label="Observação"><Input placeholder="Opcional"/></Field>
      </div>
    </Modal>

    <Modal open={modal==="fechar"} onClose={()=>setModal(null)} title="Fechamento de caixa" description="Caixa 01 · 06 de agosto · 08:00 → agora"
      footer={<><Button variant="ghost" onClick={()=>setModal(null)}>Cancelar</Button>
        <Button variant="success" icon="lock" onClick={()=>setModal(null)}>Fechar caixa</Button></>}>
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <Alert tone="warning" title="Confira o dinheiro em gaveta antes de fechar">O sistema espera {window.SC_BRL(170.7)} em espécie.</Alert>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
          <Field label="Valor contado em espécie" required><Input mono suffix="BRL" defaultValue="170,70"/></Field>
          <Field label="Diferença"><Input mono readOnly defaultValue="0,00" suffix="BRL"/></Field>
        </div>
        <Field label="Observações do fechamento"><Input placeholder="Opcional"/></Field>
      </div>
    </Modal>
  </div>;
}
Object.assign(window,{CaixaScreen});
