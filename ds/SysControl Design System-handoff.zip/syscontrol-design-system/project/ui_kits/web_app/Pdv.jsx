const {Card,CardHeader,Input,Button,IconButton,Badge,Chip,Divider,EmptyState,Modal,Field,Select,RadioGroup,DataTable,Toast}=window.SysControlDesignSystem_02daf6;

function PdvScreen(){
  const D=window.SC_DATA;
  const [q,setQ]=React.useState("");
  const [cat,setCat]=React.useState("Todos");
  const [cart,setCart]=React.useState([{...D.pecas[0],qty:2},{...D.pecas[4],qty:4}]);
  const [open,setOpen]=React.useState(false);
  const [toast,setToast]=React.useState(null);
  const cats=["Todos","Freios","Suspensão","Motor","Elétrica","Filtros"];
  const list=D.pecas.filter(p=>(cat==="Todos"||p.cat===cat)&&(p.nome.toLowerCase().includes(q.toLowerCase())||p.sku.toLowerCase().includes(q.toLowerCase())));
  const add=p=>setCart(c=>{const i=c.findIndex(x=>x.id===p.id);
    if(i>-1){const n=[...c];n[i]={...n[i],qty:n[i].qty+1};return n;} return [...c,{...p,qty:1}];});
  const bump=(id,d)=>setCart(c=>c.map(x=>x.id===id?{...x,qty:Math.max(1,x.qty+d)}:x));
  const drop=id=>setCart(c=>c.filter(x=>x.id!==id));
  const sub=cart.reduce((s,x)=>s+x.preco*x.qty,0);
  const desc=sub*0.05, total=sub-desc;
  return <div style={{display:"grid",gridTemplateColumns:"1fr 400px",gap:16,alignItems:"start"}}>
    <Card padding={0}>
      <div style={{padding:20,display:"flex",flexDirection:"column",gap:14}}>
        <div style={{display:"flex",gap:10}}>
          <Input icon="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar peça, código ou fabricante"/>
          <Button variant="outline" icon="barcode" style={{flexShrink:0}}>Ler código</Button>
        </div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {cats.map(c=><Chip key={c} selected={cat===c} onClick={()=>setCat(c)}>{c}</Chip>)}
        </div>
      </div>
      <Divider/>
      <div style={{maxHeight:430,overflowY:"auto"}}>
        {list.length===0
          ?<EmptyState icon="search-x" title="Nenhuma peça encontrada" description={'Nada corresponde a "'+q+'". Verifique o código ou tente outro termo.'}/>
          :<DataTable dense rows={list} onRowClick={add} columns={[
            {key:"sku",header:"Código",mono:true,width:96},
            {key:"nome",header:"Peça",wrap:true,render:r=><div style={{display:"flex",flexDirection:"column"}}>
              <span style={{fontWeight:"var(--weight-medium)"}}>{r.nome}</span>
              <span style={{fontSize:"var(--text-tiny)",color:"var(--muted-foreground)"}}>{r.marca} · {r.cat}</span></div>},
            {key:"qtd",header:"Estoque",align:"right",mono:true,width:80,
              render:r=><span style={{color:r.qtd===0?"var(--danger)":(r.qtd<r.min?"var(--warning-icon)":"var(--foreground)")}}>{r.qtd}</span>},
            {key:"preco",header:"Preço",align:"right",mono:true,width:100,render:r=>window.SC_BRL(r.preco)},
            {key:"a",header:"",align:"right",width:44,render:r=><IconButton icon="plus" label="Adicionar" variant="outline" size="sm"/>}
          ]}/>}
      </div>
    </Card>

    <Card padding={0} style={{position:"sticky",top:0}}>
      <div style={{padding:"18px 20px 14px",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:9}}>
          <span style={{fontFamily:"var(--font-display)",fontSize:"var(--text-medium)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-heading)"}}>Carrinho</span>
          <Badge tone="primary">{cart.reduce((s,x)=>s+x.qty,0)} itens</Badge>
        </div>
        <IconButton icon="trash-2" label="Limpar carrinho" variant="danger" size="sm" onClick={()=>setCart([])}/>
      </div>
      <div style={{padding:"14px 20px",display:"flex",flexDirection:"column",gap:12,maxHeight:300,overflowY:"auto"}}>
        {cart.length===0?<EmptyState compact icon="shopping-cart" title="Carrinho vazio" description="Selecione uma peça na lista ao lado."/>:null}
        {cart.map(x=><div key={x.id} style={{display:"flex",gap:10,alignItems:"flex-start"}}>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:"var(--text-body)",fontWeight:"var(--weight-medium)"}}>{x.nome}</div>
            <div style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-tiny)",color:"var(--muted-foreground)"}}>{x.sku} · {window.SC_BRL(x.preco)}</div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:4,flexShrink:0}}>
            <IconButton icon="minus" label="Menos" variant="outline" size="sm" onClick={()=>bump(x.id,-1)}/>
            <span style={{minWidth:24,textAlign:"center",fontFamily:"var(--font-mono)",fontSize:"var(--text-body)",fontVariantNumeric:"tabular-nums"}}>{x.qty}</span>
            <IconButton icon="plus" label="Mais" variant="outline" size="sm" onClick={()=>bump(x.id,1)}/>
          </div>
          <div style={{width:82,textAlign:"right",fontFamily:"var(--font-mono)",fontSize:"var(--text-body)",fontWeight:"var(--weight-semibold)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(x.preco*x.qty)}</div>
          <IconButton icon="x" label="Remover" size="sm" onClick={()=>drop(x.id)}/>
        </div>)}
      </div>
      <Divider/>
      <div style={{padding:"14px 20px",display:"flex",flexDirection:"column",gap:8}}>
        {[["Subtotal",window.SC_BRL(sub)],["Desconto 5%","− "+window.SC_BRL(desc)]].map(([l,v])=>
          <div key={l} style={{display:"flex",justifyContent:"space-between",fontSize:"var(--text-body)",color:"var(--muted-foreground)"}}>
            <span>{l}</span><span style={{fontFamily:"var(--font-mono)",fontVariantNumeric:"tabular-nums"}}>{v}</span></div>)}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",paddingTop:8,borderTop:"1px solid var(--border)"}}>
          <span style={{fontSize:"var(--text-body)",fontWeight:"var(--weight-semibold)"}}>Total</span>
          <span style={{fontFamily:"var(--font-display)",fontSize:"var(--text-h3)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-display)",fontVariantNumeric:"tabular-nums"}}>{window.SC_BRL(total)}</span>
        </div>
        <Button variant="success" size="lg" icon="check" fullWidth disabled={cart.length===0} onClick={()=>setOpen(true)}>Finalizar venda</Button>
        <Button variant="ghost" size="sm" icon="pause" fullWidth>Salvar orçamento</Button>
      </div>
    </Card>

    <Modal open={open} onClose={()=>setOpen(false)} title="Finalizar venda"
      description={"Pedido #2042 · "+cart.reduce((s,x)=>s+x.qty,0)+" itens · "+window.SC_BRL(total)}
      footer={<><Button variant="ghost" onClick={()=>setOpen(false)}>Cancelar</Button>
        <Button variant="success" icon="check" onClick={()=>{setOpen(false);setCart([]);setToast(true);}}>Confirmar pagamento</Button></>}>
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <Field label="Cliente"><Select placeholder="Consumidor final" options={D.clientes.map(c=>c.nome)}/></Field>
        <Field label="Forma de pagamento">
          <RadioGroup defaultValue="pix" options={[
            {value:"pix",label:"Pix",description:"Confirmação imediata"},
            {value:"credito",label:"Cartão de crédito",description:"Até 12x, taxa de 2,9%"},
            {value:"debito",label:"Cartão de débito"},
            {value:"dinheiro",label:"Dinheiro"}]}/>
        </Field>
        <Field label="Valor recebido" hint="Troco calculado automaticamente"><Input mono suffix="BRL" defaultValue={total.toFixed(2).replace(".",",")}/></Field>
      </div>
    </Modal>
    {toast?<div style={{position:"fixed",right:24,bottom:24,zIndex:80}}>
      <Toast title="Venda #2042 finalizada" description="Recibo enviado por WhatsApp" onClose={()=>setToast(null)}
        action={<Button variant="link" size="sm" onClick={()=>setToast(null)}>Desfazer</Button>}/></div>:null}
  </div>;
}
Object.assign(window,{PdvScreen});
