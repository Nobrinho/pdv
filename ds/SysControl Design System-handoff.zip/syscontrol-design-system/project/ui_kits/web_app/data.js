window.SC_DATA = {
  pecas:[
    {id:1,sku:"FR-2280",nome:"Pastilha de freio dianteira",marca:"Bosch",cat:"Freios",qtd:148,min:40,preco:189.9,custo:112.4,st:"Em estoque",t:"success"},
    {id:2,sku:"SU-1044",nome:"Amortecedor traseiro CG 160",marca:"Cofap",cat:"Suspensão",qtd:9,min:15,preco:312.0,custo:198.0,st:"Estoque baixo",t:"warning"},
    {id:3,sku:"MO-7715",nome:"Kit relação Titan 150",marca:"Riffel",cat:"Motor",qtd:0,min:12,preco:248.5,custo:161.0,st:"Esgotado",t:"danger"},
    {id:4,sku:"EL-3390",nome:"Bateria selada 12V 5Ah",marca:"Moura",cat:"Elétrica",qtd:37,min:20,preco:179.0,custo:104.9,st:"Em estoque",t:"success"},
    {id:5,sku:"FI-0121",nome:"Filtro de óleo Fiat Argo 1.0",marca:"Tecfil",cat:"Filtros",qtd:212,min:60,preco:34.9,custo:17.8,st:"Em estoque",t:"success"},
    {id:6,sku:"FR-9034",nome:"Disco de freio ventilado Onix",marca:"Fremax",cat:"Freios",qtd:26,min:18,preco:268.0,custo:172.0,st:"Em estoque",t:"success"},
    {id:7,sku:"MO-4408",nome:"Vela de ignição iridium NGK",marca:"NGK",cat:"Motor",qtd:11,min:24,preco:79.9,custo:41.2,st:"Estoque baixo",t:"warning"},
    {id:8,sku:"SU-6650",nome:"Bieleta dianteira HB20",marca:"Nakata",cat:"Suspensão",qtd:64,min:20,preco:96.5,custo:52.0,st:"Em estoque",t:"success"}
  ],
  vendas:[
    {id:"2041",cliente:"Oficina Dois Irmãos",itens:6,total:1842.30,pag:"Pix",vend:"Marcos Ribeiro",hora:"14:32",st:"Pago",t:"success"},
    {id:"2040",cliente:"Rafael Sampaio",itens:2,total:389.80,pag:"Crédito 3x",vend:"Ana Lima",hora:"14:05",st:"Pago",t:"success"},
    {id:"2039",cliente:"Moto Peças Vale",itens:14,total:5310.00,pag:"Boleto",vend:"Marcos Ribeiro",hora:"13:48",st:"Pendente",t:"warning"},
    {id:"2038",cliente:"Juliana Prado",itens:1,total:179.00,pag:"Débito",vend:"Ana Lima",hora:"12:57",st:"Pago",t:"success"},
    {id:"2037",cliente:"Auto Center Norte",itens:9,total:2764.40,pag:"Pix",vend:"Diego Farias",hora:"11:20",st:"Pago",t:"success"},
    {id:"2036",cliente:"Consumidor final",itens:3,total:512.70,pag:"Dinheiro",vend:"Ana Lima",hora:"10:44",st:"Cancelado",t:"danger"}
  ],
  caixa:[
    {hora:"08:00",tipo:"Abertura",desc:"Fundo de troco",forma:"Dinheiro",valor:300.00,e:1},
    {hora:"10:44",tipo:"Venda",desc:"Pedido #2036",forma:"Dinheiro",valor:512.70,e:1},
    {hora:"11:20",tipo:"Venda",desc:"Pedido #2037",forma:"Pix",valor:2764.40,e:1},
    {hora:"12:10",tipo:"Sangria",desc:"Depósito bancário",forma:"Dinheiro",valor:500.00,e:0},
    {hora:"12:57",tipo:"Venda",desc:"Pedido #2038",forma:"Débito",valor:179.00,e:1},
    {hora:"13:30",tipo:"Despesa",desc:"Frete transportadora",forma:"Dinheiro",valor:142.00,e:0},
    {hora:"14:32",tipo:"Venda",desc:"Pedido #2041",forma:"Pix",valor:1842.30,e:1}
  ],
  clientes:[
    {nome:"Oficina Dois Irmãos",doc:"12.884.301/0001-55",tipo:"Oficina",tel:"(11) 98812-4410",compras:47,total:68420.90,ult:"Hoje"},
    {nome:"Moto Peças Vale",doc:"08.117.442/0001-09",tipo:"Revenda",tel:"(11) 3388-2140",compras:112,total:214880.00,ult:"Hoje"},
    {nome:"Auto Center Norte",doc:"22.940.118/0001-72",tipo:"Oficina",tel:"(11) 99640-7712",compras:38,total:51230.40,ult:"Ontem"},
    {nome:"Rafael Sampaio",doc:"318.442.190-04",tipo:"Balcão",tel:"(11) 98120-3345",compras:6,total:2140.60,ult:"Hoje"},
    {nome:"Juliana Prado",doc:"402.110.887-31",tipo:"Balcão",tel:"(11) 99880-1204",compras:3,total:640.00,ult:"3 dias"}
  ],
  nav:[
    {key:"painel",label:"Painel",icon:"layout-dashboard"},
    {section:"Operação"},
    {key:"pdv",label:"PDV",icon:"shopping-cart"},
    {key:"vendas",label:"Vendas",icon:"receipt"},
    {key:"caixa",label:"Caixa",icon:"banknote"},
    {section:"Catálogo"},
    {key:"estoque",label:"Estoque",icon:"package",badge:12},
    {key:"clientes",label:"Clientes",icon:"users"},
    {key:"fornecedores",label:"Fornecedores",icon:"truck"},
    {section:"Gestão"},
    {key:"relatorios",label:"Relatórios",icon:"chart-column"},
    {key:"config",label:"Configurações",icon:"settings"}
  ]
};
window.SC_BRL = n => n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
window.SC_NUM = n => n.toLocaleString("pt-BR");
