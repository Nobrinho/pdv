const {Card,CardHeader,DataTable,Badge,Button,IconButton,Input,Select,Tabs,Pagination,Divider,Avatar,StatCard}=window.SysControlDesignSystem_02daf6;

function VendasScreen(){
  const D=window.SC_DATA;
  const [tab,setTab]=React.useState("todas");
  const rows=D.vendas.filter(v=>tab==="todas"||(tab==="pagas"&&v.st==="Pago")||(tab==="pendentes"&&v.st==="Pendente")||(tab==="canceladas"&&v.st==="Cancelado"));
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16}}>
      <StatCard label="Vendas hoje" value="63" unit="pedidos" delta={-4.1} deltaLabel="vs. ontem" icon="receipt"/>
      <StatCard label="Faturado" value={window.SC_BRL(14280.5)} delta={12.4} icon="banknote" tone="primary"/>
      <StatCard label="A receber" value={window.SC_BRL(5310)} unit="1 boleto" icon="clock" tone="warning"/>
      <StatCard label="Cancelamentos" value="1" unit="pedido" icon="circle-x" tone="danger"/>
    </div>
    <Card padding={0}>
      <div style={{padding:"16px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,flexWrap:"wrap"}}>
        <Tabs value={tab} onChange={setTab} items={[
          {key:"todas",label:"Todas",count:D.vendas.length},{key:"pagas",label:"Pagas",count:4},
          {key:"pendentes",label:"Pendentes",count:1},{key:"canceladas",label:"Canceladas",count:1}]}/>
        <div style={{display:"flex",gap:8}}>
          <Input icon="search" size="sm" placeholder="Pedido ou cliente" fullWidth={false} style={{width:230}}/>
          <Select size="sm" fullWidth={false} placeholder="Vendedor" options={["Marcos Ribeiro","Ana Lima","Diego Farias"]} style={{width:160}}/>
          <Button variant="outline" size="sm" icon="download">Exportar</Button>
        </div>
      </div>
      <Divider/>
      <DataTable rows={rows} columns={[
        {key:"id",header:"Pedido",mono:true,width:90,render:r=>"#"+r.id},
        {key:"hora",header:"Hora",mono:true,width:70},
        {key:"cliente",header:"Cliente",wrap:true},
        {key:"vend",header:"Vendedor",width:180,render:r=><span style={{display:"inline-flex",alignItems:"center",gap:8}}>
          <Avatar name={r.vend} size={24}/>{r.vend}</span>},
        {key:"pag",header:"Pagamento",width:120},
        {key:"itens",header:"Itens",align:"right",mono:true,width:70},
        {key:"total",header:"Total",align:"right",mono:true,width:130,render:r=>window.SC_BRL(r.total)},
        {key:"st",header:"Situação",width:130,render:r=><Badge tone={r.t} dot>{r.st}</Badge>},
        {key:"a",header:"",align:"right",width:80,render:()=><span style={{display:"inline-flex",gap:2}}>
          <IconButton icon="printer" label="Imprimir" size="sm"/><IconButton icon="more-horizontal" label="Ações" size="sm"/></span>}
      ]}/>
      <Divider/>
      <div style={{padding:"14px 20px"}}><Pagination page={1} pageCount={11} total={63} pageSize={6}/></div>
    </Card>
  </div>;
}

function ClientesScreen(){
  const D=window.SC_DATA;
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:16}}>
      <Tabs items={[{key:"todos",label:"Todos",count:D.clientes.length},{key:"oficinas",label:"Oficinas",count:2},{key:"balcao",label:"Balcão",count:2}]}/>
      <Button icon="user-plus">Novo cliente</Button>
    </div>
    <Card padding={0}>
      <div style={{padding:"16px 20px"}}><Input icon="search" size="sm" placeholder="Buscar por nome, CNPJ/CPF ou telefone"/></div>
      <Divider/>
      <DataTable rows={D.clientes} columns={[
        {key:"nome",header:"Cliente",wrap:true,render:r=><span style={{display:"inline-flex",alignItems:"center",gap:10}}>
          <Avatar name={r.nome} size={32} tone={r.tipo==="Balcão"?"neutral":"primary"}/>
          <span style={{display:"flex",flexDirection:"column"}}>
            <span style={{fontWeight:"var(--weight-medium)"}}>{r.nome}</span>
            <span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-tiny)",color:"var(--muted-foreground)"}}>{r.doc}</span></span></span>},
        {key:"tipo",header:"Tipo",width:110,render:r=><Badge tone={r.tipo==="Revenda"?"primary":"neutral"}>{r.tipo}</Badge>},
        {key:"tel",header:"Telefone",mono:true,width:150},
        {key:"compras",header:"Compras",align:"right",mono:true,width:90},
        {key:"total",header:"Total gasto",align:"right",mono:true,width:140,render:r=>window.SC_BRL(r.total)},
        {key:"ult",header:"Última compra",width:130},
        {key:"a",header:"",align:"right",width:44,render:()=><IconButton icon="more-horizontal" label="Ações" size="sm"/>}
      ]}/>
    </Card>
  </div>;
}
Object.assign(window,{VendasScreen,ClientesScreen});
