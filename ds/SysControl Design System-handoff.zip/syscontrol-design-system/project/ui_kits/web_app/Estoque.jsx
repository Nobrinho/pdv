const {Card,CardHeader,DataTable,Badge,Button,IconButton,Input,Select,Chip,Tabs,Pagination,Divider,Checkbox,Modal,Field,Textarea,Progress,EmptyState}=window.SysControlDesignSystem_02daf6;

function EstoqueScreen(){
  const D=window.SC_DATA;
  const [tab,setTab]=React.useState("todas");
  const [q,setQ]=React.useState("");
  const [sel,setSel]=React.useState([]);
  const [detail,setDetail]=React.useState(null);
  const base=D.pecas.filter(p=>tab==="todas"||(tab==="baixo"&&p.qtd<p.min&&p.qtd>0)||(tab==="zerado"&&p.qtd===0));
  const rows=base.filter(p=>p.nome.toLowerCase().includes(q.toLowerCase())||p.sku.toLowerCase().includes(q.toLowerCase()));
  const toggle=id=>setSel(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id]);
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}>
      <Tabs value={tab} onChange={setTab} items={[
        {key:"todas",label:"Todas",count:D.pecas.length},
        {key:"baixo",label:"Estoque baixo",count:D.pecas.filter(p=>p.qtd<p.min&&p.qtd>0).length},
        {key:"zerado",label:"Esgotadas",count:D.pecas.filter(p=>p.qtd===0).length}]}/>
      <div style={{display:"flex",gap:8}}>
        <Button variant="outline" icon="upload">Importar planilha</Button>
        <Button icon="plus">Nova peça</Button>
      </div>
    </div>
    <Card padding={0}>
      <div style={{padding:"16px 20px",display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
        <div style={{flex:1,minWidth:240}}><Input icon="search" size="sm" value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar por nome, código ou fabricante"/></div>
        <Select size="sm" fullWidth={false} placeholder="Categoria" options={["Freios","Suspensão","Motor","Elétrica","Filtros"]} style={{width:170}}/>
        <Select size="sm" fullWidth={false} placeholder="Fabricante" options={["Bosch","Cofap","NGK","Moura","Tecfil"]} style={{width:170}}/>
        <IconButton icon="sliders-horizontal" label="Mais filtros" variant="outline" size="sm"/>
        <IconButton icon="download" label="Exportar CSV" variant="outline" size="sm"/>
      </div>
      {sel.length>0?<div style={{padding:"10px 20px",background:"var(--primary-soft)",borderTop:"1px solid var(--primary-soft-border)",borderBottom:"1px solid var(--primary-soft-border)",display:"flex",alignItems:"center",gap:12}}>
        <span style={{fontSize:"var(--text-body)",fontWeight:"var(--weight-medium)",color:"var(--primary-soft-foreground)"}}>{sel.length} peças selecionadas</span>
        <Button variant="flat" size="sm" icon="tag">Ajustar preço</Button>
        <Button variant="flat" size="sm" icon="truck">Pedir ao fornecedor</Button>
        <Button variant="ghost" size="sm" onClick={()=>setSel([])} style={{marginLeft:"auto"}}>Limpar seleção</Button>
      </div>:<Divider/>}
      {rows.length===0
        ?<EmptyState icon="package-search" title="Nenhuma peça encontrada" description="Ajuste os filtros ou cadastre uma nova peça." action={<Button icon="plus">Nova peça</Button>}/>
        :<DataTable selectable rows={rows.map(r=>({...r,select:<Checkbox checked={sel.includes(r.id)} onChange={()=>toggle(r.id)}/>}))}
          onRowClick={setDetail} columns={[
          {key:"sku",header:"Código",mono:true,width:100},
          {key:"nome",header:"Peça",wrap:true,render:r=><div style={{display:"flex",flexDirection:"column"}}>
            <span style={{fontWeight:"var(--weight-medium)"}}>{r.nome}</span>
            <span style={{fontSize:"var(--text-tiny)",color:"var(--muted-foreground)"}}>{r.marca}</span></div>},
          {key:"cat",header:"Categoria",width:120},
          {key:"qtd",header:"Estoque",align:"right",mono:true,width:100,sortable:true,
            render:r=><div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
              <span style={{color:r.qtd===0?"var(--danger)":(r.qtd<r.min?"var(--warning-icon)":"var(--foreground)"),fontWeight:"var(--weight-semibold)"}}>{r.qtd}</span>
              <Progress value={r.qtd} max={Math.max(r.min*2,r.qtd)} size="sm" tone={r.qtd===0?"danger":(r.qtd<r.min?"warning":"success")} style={{width:56}}/></div>},
          {key:"custo",header:"Custo",align:"right",mono:true,width:100,render:r=>window.SC_BRL(r.custo)},
          {key:"preco",header:"Venda",align:"right",mono:true,width:100,sortable:true,render:r=>window.SC_BRL(r.preco)},
          {key:"st",header:"Situação",width:140,render:r=><Badge tone={r.t} dot>{r.st}</Badge>},
          {key:"a",header:"",align:"right",width:44,render:()=><IconButton icon="more-horizontal" label="Ações" size="sm"/>}
        ]}/>}
      <Divider/>
      <div style={{padding:"14px 20px"}}><Pagination page={1} pageCount={8} total={148} pageSize={rows.length||8}/></div>
    </Card>

    <Modal open={!!detail} onClose={()=>setDetail(null)} size="lg" title={detail?detail.nome:""}
      description={detail?detail.sku+" · "+detail.marca+" · "+detail.cat:""}
      footer={<><Button variant="ghost" onClick={()=>setDetail(null)}>Fechar</Button>
        <Button variant="outline" icon="truck">Pedir ao fornecedor</Button>
        <Button icon="check">Salvar alterações</Button></>}>
      {detail?<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <Field label="Preço de custo"><Input mono suffix="BRL" defaultValue={detail.custo.toFixed(2).replace(".",",")}/></Field>
        <Field label="Preço de venda"><Input mono suffix="BRL" defaultValue={detail.preco.toFixed(2).replace(".",",")}/></Field>
        <Field label="Quantidade em estoque"><Input mono suffix="un." defaultValue={String(detail.qtd)}/></Field>
        <Field label="Estoque mínimo" hint="Dispara o alerta de reposição"><Input mono suffix="un." defaultValue={String(detail.min)}/></Field>
        <Field label="Localização"><Select defaultValue="A-12" options={["A-12","B-04","C-21","Depósito"]}/></Field>
        <Field label="Fornecedor"><Select defaultValue={detail.marca} options={["Bosch","Cofap","NGK","Moura","Tecfil","Riffel","Fremax","Nakata"]}/></Field>
        <div style={{gridColumn:"span 2"}}><Field label="Aplicações" hint="Modelos compatíveis"><Textarea rows={2} defaultValue="Honda CG 160 (2016–2024), Honda Titan 160, Honda Start 160"/></Field></div>
      </div>:null}
    </Modal>
  </div>;
}
Object.assign(window,{EstoqueScreen});
