const {Card,CardHeader,StatCard,DataTable,Badge,Button,Progress,Alert,IconButton,Tabs}=window.SysControlDesignSystem_02daf6;

function Bars(){
  const d=[["Seg",62],["Ter",78],["Qua",54],["Qui",91],["Sex",100],["Sáb",73],["Dom",22]];
  return <div style={{display:"flex",alignItems:"flex-end",gap:14,height:150,paddingTop:8}}>
    {d.map(([l,v],i)=><div key={l} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
      <div style={{width:"100%",height:"100%",display:"flex",alignItems:"flex-end"}}>
        <div style={{width:"100%",height:v+"%",borderRadius:"var(--radius-sm) var(--radius-sm) 2px 2px",
          background:i===4?"var(--primary)":"var(--primary-soft-hover)",transition:"height var(--duration-slow) var(--ease-out)"}}/>
      </div>
      <span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",color:"var(--muted-foreground)"}}>{l}</span>
    </div>)}
  </div>;
}

function DashboardScreen({go}){
  const D=window.SC_DATA;
  const criticas=D.pecas.filter(p=>p.qtd<p.min);
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Alert tone="warning" title={criticas.length+" peças abaixo do estoque mínimo"}
      action={<Button variant="link" size="sm" onClick={()=>go("estoque")}>Ver lista</Button>}/>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16}}>
      <StatCard label="Faturamento hoje" value={window.SC_BRL(14280.5)} delta={12.4} deltaLabel="vs. ontem" icon="banknote" tone="primary"/>
      <StatCard label="Vendas" value="63" unit="pedidos" delta={-4.1} deltaLabel="vs. ontem" icon="receipt"/>
      <StatCard label="Ticket médio" value={window.SC_BRL(226.67)} delta={17.2} deltaLabel="vs. ontem" icon="trending-up" tone="success"/>
      <StatCard label="Estoque crítico" value={criticas.length} unit="itens" icon="triangle-alert" tone="warning"/>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1.7fr 1fr",gap:16,alignItems:"start"}}>
      <Card>
        <CardHeader title="Vendas da semana" description="Faturamento diário, últimos 7 dias"
          action={<Tabs variant="segmented" items={["Semana","Mês","Ano"]}/>}/>
        <Bars/>
      </Card>
      <Card>
        <CardHeader title="Reposição urgente" action={<IconButton icon="more-horizontal" label="Opções"/>}/>
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          {criticas.map(p=><div key={p.id} style={{display:"flex",flexDirection:"column",gap:6}}>
            <div style={{display:"flex",justifyContent:"space-between",gap:10,alignItems:"baseline"}}>
              <span style={{fontSize:"var(--text-body)",fontWeight:"var(--weight-medium)"}}>{p.nome}</span>
              <span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-small)",color:"var(--muted-foreground)",fontVariantNumeric:"tabular-nums",whiteSpace:"nowrap"}}>{p.qtd}/{p.min}</span>
            </div>
            <Progress value={p.qtd} max={p.min} tone={p.qtd===0?"danger":"warning"} size="sm"/>
          </div>)}
          <Button variant="outline" size="sm" icon="truck" fullWidth>Gerar pedido de compra</Button>
        </div>
      </Card>
    </div>
    <Card padding={0}>
      <div style={{padding:"20px 20px 0"}}>
        <CardHeader title="Últimas vendas" description="Atualizado há 2 min"
          action={<Button variant="outline" size="sm" iconEnd="arrow-right" onClick={()=>go("vendas")}>Ver todas</Button>}/>
      </div>
      <DataTable rows={D.vendas.slice(0,5)} onRowClick={()=>go("vendas")} columns={[
        {key:"id",header:"Pedido",mono:true,width:90,render:r=>"#"+r.id},
        {key:"cliente",header:"Cliente",wrap:true},
        {key:"vend",header:"Vendedor",width:150},
        {key:"pag",header:"Pagamento",width:120},
        {key:"itens",header:"Itens",align:"right",mono:true,width:70},
        {key:"total",header:"Total",align:"right",mono:true,width:120,render:r=>window.SC_BRL(r.total)},
        {key:"st",header:"Situação",width:130,render:r=><Badge tone={r.t} dot>{r.st}</Badge>}
      ]}/>
    </Card>
  </div>;
}
Object.assign(window,{DashboardScreen});
