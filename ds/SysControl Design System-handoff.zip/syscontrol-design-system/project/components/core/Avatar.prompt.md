Circular user mark for the topbar account menu, seller columns and activity rows.

```jsx
<Avatar name="Marcos Ribeiro" size="sm" />
```

Sizes 28/36/44px. Initials only — SysControl does not ship stock photography.
