import React from "react";
import { Icon } from "./Icon.jsx";

const SZ={sm:{box:32,glyph:16,r:"var(--radius-sm)"},md:{box:36,glyph:18,r:"var(--radius-md)"},lg:{box:40,glyph:20,r:"var(--radius-md)"}};
const V={
  ghost:{background:"transparent",color:"var(--muted-foreground)",border:"1px solid transparent",hoverBg:"var(--accent)",hoverFg:"var(--foreground)"},
  outline:{background:"var(--background)",color:"var(--foreground)",border:"1px solid var(--border)",hoverBg:"var(--accent)",hoverFg:"var(--foreground)"},
  primary:{background:"var(--primary)",color:"var(--primary-foreground)",border:"1px solid transparent",hoverBg:"var(--primary-hover)",hoverFg:"var(--primary-foreground)"},
  danger:{background:"transparent",color:"var(--danger)",border:"1px solid transparent",hoverBg:"var(--danger-soft)",hoverFg:"var(--danger)"}
};
export function IconButton({icon,label,variant="ghost",size="md",disabled=false,round=false,style,onClick,...rest}){
  const [h,setH]=React.useState(false);const [p,setP]=React.useState(false);
  const s=SZ[size]||SZ.md;const v=V[variant]||V.ghost;
  return <button type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick}
    onMouseEnter={()=>setH(true)} onMouseLeave={()=>{setH(false);setP(false);}}
    onMouseDown={()=>setP(true)} onMouseUp={()=>setP(false)}
    style={{display:"inline-flex",alignItems:"center",justifyContent:"center",boxSizing:"border-box",
      width:s.box,height:s.box,padding:0,borderRadius:round?"var(--radius-full)":s.r,
      background:h&&!disabled?v.hoverBg:v.background,color:h&&!disabled?v.hoverFg:v.color,border:v.border,
      cursor:disabled?"not-allowed":"pointer",opacity:disabled?"var(--disabled-opacity)":1,outline:"none",
      transition:"var(--transition-colors), var(--transition-transform)",
      transform:p&&!disabled?"scale(var(--press-scale))":"scale(1)",...style}} {...rest}>
    <Icon name={icon} size={s.glyph}/>
  </button>;
}
