import React from "react";
import { Icon } from "./Icon.jsx";
const TONE={
  neutral:{bg:"var(--neutral-soft)",fg:"var(--neutral-soft-foreground)",bd:"var(--neutral-soft-border)"},
  primary:{bg:"var(--primary-soft)",fg:"var(--primary-soft-foreground)",bd:"var(--primary-soft-border)"},
  success:{bg:"var(--success-soft)",fg:"var(--success-soft-foreground)",bd:"var(--success-soft-border)"},
  warning:{bg:"var(--warning-soft)",fg:"var(--warning-soft-foreground)",bd:"var(--warning-soft-border)"},
  danger:{bg:"var(--danger-soft)",fg:"var(--danger-soft-foreground)",bd:"var(--danger-soft-border)"},
  info:{bg:"var(--info-soft)",fg:"var(--info-soft-foreground)",bd:"var(--info-soft-border)"},
  solid:{bg:"var(--primary)",fg:"var(--primary-foreground)",bd:"transparent"}
};
export function Badge({children,tone="neutral",icon,dot=false,style,...rest}){
  const t=TONE[tone]||TONE.neutral;
  return <span style={{display:"inline-flex",alignItems:"center",gap:6,boxSizing:"border-box",
    height:22,padding:"0 8px",borderRadius:"var(--radius-full)",background:t.bg,color:t.fg,
    border:"1px solid "+t.bd,fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",
    fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-label)",whiteSpace:"nowrap",...style}} {...rest}>
    {dot?<span style={{width:6,height:6,borderRadius:"var(--radius-full)",background:"currentColor"}}/>:null}
    {icon?<Icon name={icon} size={12}/>:null}
    {children}
  </span>;
}
