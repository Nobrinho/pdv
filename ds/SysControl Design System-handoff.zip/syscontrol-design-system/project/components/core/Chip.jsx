import React from "react";
import { Icon } from "./Icon.jsx";
export function Chip({children,selected=false,icon,onRemove,onClick,style,...rest}){
  const [h,setH]=React.useState(false);
  const clickable=!!onClick;
  return <span onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{display:"inline-flex",alignItems:"center",gap:6,boxSizing:"border-box",height:28,
      padding:onRemove?"0 6px 0 10px":"0 12px",borderRadius:"var(--radius-full)",
      background:selected?"var(--primary)":(h&&clickable?"var(--accent)":"var(--content2)"),
      color:selected?"var(--primary-foreground)":"var(--foreground)",
      border:"1px solid "+(selected?"transparent":"var(--border)"),
      fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",fontWeight:"var(--weight-medium)",
      cursor:clickable?"pointer":"default",transition:"var(--transition-colors)",userSelect:"none",...style}} {...rest}>
    {icon?<Icon name={icon} size={14}/>:null}
    {children}
    {onRemove?<button type="button" onClick={e=>{e.stopPropagation();onRemove(e);}}
      style={{display:"inline-flex",border:0,background:"transparent",padding:2,cursor:"pointer",
        color:"inherit",opacity:0.7,borderRadius:"var(--radius-full)"}} aria-label="Remover">
      <Icon name="x" size={13}/></button>:null}
  </span>;
}
