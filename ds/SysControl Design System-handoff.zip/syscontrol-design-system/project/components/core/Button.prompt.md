The action control for every SysControl surface — one `primary` per view, everything else `outline` or `ghost`.

```jsx
<Button variant="primary" icon="plus">Nova venda</Button>
<Button variant="outline" size="sm" icon="download">Exportar</Button>
<Button variant="destructive" icon="trash-2">Cancelar venda</Button>
```

Variants: primary, secondary, outline, ghost, flat (soft teal tint), destructive, success, link.
Sizes sm/md/lg = 32/36/40px. `loading` replaces the leading icon with a spinner. Use `success` only for finalising a sale ("Finalizar venda").
