A 1px rule in `--border`. With `label` it becomes an uppercase section break inside long forms.

```jsx
<Divider />
<Divider label="Dados do cliente" />
<Divider orientation="vertical" style={{height:20}} />
```
