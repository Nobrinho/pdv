Icon-only square control — table row actions, topbar utilities, card overflow menus.

```jsx
<IconButton icon="more-horizontal" label="Mais ações" />
<IconButton icon="trash-2" label="Excluir" variant="danger" size="sm" />
```

Always pass `label`. Sizes 32/36/40px match Button. Use `round` only for avatar-adjacent controls.
