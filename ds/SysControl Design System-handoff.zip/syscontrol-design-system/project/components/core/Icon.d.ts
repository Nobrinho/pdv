import * as React from "react";
/** Renders a Lucide glyph (the icon set shadcn/ui ships with) at SysControl's stroke weight. */
export interface IconProps extends Omit<React.SVGProps<SVGSVGElement>,"name"|"color"> {
  /** Lucide icon name, kebab or Pascal — e.g. "shopping-cart", "Package". */
  name: string;
  /** Pixel size of the square glyph. @default 16 */
  size?: number;
  /** @default 2 */
  strokeWidth?: number;
  /** @default "currentColor" */
  color?: string;
}
export declare function Icon(props: IconProps): JSX.Element;
