Indeterminate loader for panels waiting on data.

```jsx
<Spinner label="Carregando estoque…" />
```

For table and card placeholders prefer `Skeleton`; use Spinner only for short, blocking waits.
