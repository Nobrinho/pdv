import React from "react";

export function Divider({orientation="horizontal",label,style,...rest}){
  if(label) return <div style={{display:"flex",alignItems:"center",gap:12,...style}} {...rest}>
    <span style={{flex:1,height:1,background:"var(--border)"}}/>
    <span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",fontWeight:"var(--weight-semibold)",
      letterSpacing:"var(--tracking-caps)",textTransform:"uppercase",color:"var(--muted-foreground)"}}>{label}</span>
    <span style={{flex:1,height:1,background:"var(--border)"}}/>
  </div>;
  const v=orientation==="vertical";
  return <span aria-hidden="true" style={{display:"block",flexShrink:0,
    width:v?"var(--border-width)":"100%",height:v?"100%":"var(--border-width)",
    background:"var(--border)",...style}} {...rest}/>;
}
