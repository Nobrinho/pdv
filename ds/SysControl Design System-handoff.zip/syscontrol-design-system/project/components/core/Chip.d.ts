import * as React from "react";
/** A selectable / removable filter token — HeroUI chip geometry (28px, full radius). */
export interface ChipProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"|"onClick"> {
  children?: React.ReactNode;
  /** @default false */
  selected?: boolean;
  /** Lucide icon name. */
  icon?: string;
  /** When set, renders a trailing × button. */
  onRemove?: (e: React.MouseEvent) => void;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function Chip(props: ChipProps): JSX.Element;
