import React from "react";

export function Spinner({size=20,label,style,...rest}){
  return <span role="status" aria-label={label||"Carregando"} style={{display:"inline-flex",alignItems:"center",gap:8,...style}} {...rest}>
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{animation:"sc-spinner 700ms linear infinite",display:"block"}}>
      <circle cx="12" cy="12" r="9" stroke="var(--border)" strokeWidth="2.5"/>
      <path d="M21 12a9 9 0 0 0-9-9" stroke="var(--primary)" strokeWidth="2.5" strokeLinecap="round"/>
    </svg>
    {label?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--muted-foreground)"}}>{label}</span>:null}
    <style>{"@keyframes sc-spinner{to{transform:rotate(360deg)}}"}</style>
  </span>;
}
