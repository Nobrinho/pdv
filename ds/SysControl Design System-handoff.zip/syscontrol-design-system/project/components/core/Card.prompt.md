The default panel — every block of content in SysControl lives in one.

```jsx
<Card>
  <CardHeader title="Vendas do dia" description="Atualizado há 2 min" action={<IconButton icon="more-horizontal" label="Opções" />} />
  …
  <CardFooter><Button variant="outline" size="sm">Ver tudo</Button></CardFooter>
</Card>
```

Never stack a shadow heavier than `--shadow-sm` on a card. Nested cards drop the border and use `--content2` instead.
