import * as React from "react";
/** A square icon-only control for toolbars, table row actions and the topbar. */
export interface IconButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>,"style"> {
  /** Lucide icon name. */
  icon: string;
  /** Accessible label — also the tooltip title. */
  label: string;
  /** @default "ghost" */
  variant?: "ghost" | "outline" | "primary" | "danger";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** @default false */
  round?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
