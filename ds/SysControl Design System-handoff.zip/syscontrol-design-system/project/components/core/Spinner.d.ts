import * as React from "react";
/** Indeterminate loading indicator — a 700ms linear teal arc. */
export interface SpinnerProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"> {
  /** Diameter in px. @default 20 */
  size?: number;
  /** Text shown to the right of the arc. */
  label?: string;
  style?: React.CSSProperties;
}
export declare function Spinner(props: SpinnerProps): JSX.Element;
