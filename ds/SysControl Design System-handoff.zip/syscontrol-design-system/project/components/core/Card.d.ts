import * as React from "react";
/**
 * The surface every SysControl panel sits on — 1px border, 14px radius, shadow-xs.
 * @startingPoint section="Core" subtitle="Bordered panel with header, body and footer" viewport="700x260"
 */
export interface CardProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  children?: React.ReactNode;
  /** Inner padding in px. @default 20 */
  padding?: number;
  /** Lifts the shadow on hover and switches the cursor. @default false */
  interactive?: boolean;
  style?: React.CSSProperties;
}
export interface CardHeaderProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"title"|"style"> {
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Buttons or an IconButton pinned to the right. */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export interface CardFooterProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
export declare function CardHeader(props: CardHeaderProps): JSX.Element;
export declare function CardFooter(props: CardFooterProps): JSX.Element;
