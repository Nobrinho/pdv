Status pill — order state, stock level, payment method. 22px tall, full radius, soft tinted background.

```jsx
<Badge tone="success" dot>Pago</Badge>
<Badge tone="warning" icon="triangle-alert">Estoque baixo</Badge>
```

Tone mapping in SysControl: success = pago/em estoque, warning = estoque baixo/pendente, danger = cancelado/esgotado, info = em separação, neutral = rascunho.
