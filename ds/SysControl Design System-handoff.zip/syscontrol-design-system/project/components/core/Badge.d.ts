import * as React from "react";
/** A compact status pill for order state, stock level and payment status. */
export interface BadgeProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"> {
  children?: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "primary" | "success" | "warning" | "danger" | "info" | "solid";
  /** Lucide icon name shown before the label. */
  icon?: string;
  /** Shows a 6px status dot instead of an icon. @default false */
  dot?: boolean;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
