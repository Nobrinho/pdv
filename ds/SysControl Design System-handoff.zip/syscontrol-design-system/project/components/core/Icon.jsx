import React from "react";

function toPascal(n){return String(n).split(/[-_\s]/).filter(Boolean).map(s=>s[0].toUpperCase()+s.slice(1)).join("");}
function nodes(spec){
  if(!spec) return null;
  if(Array.isArray(spec)&&spec[0]==="svg") return spec[2];
  return spec;
}
export function Icon({name,size=16,strokeWidth=2,color="currentColor",style,...rest}){
  const [,tick]=React.useState(0);
  React.useEffect(()=>{
    if(typeof window==="undefined")return;
    if(window.lucide&&window.lucide.icons)return;
    let n=0;const id=setInterval(()=>{n++;if((window.lucide&&window.lucide.icons)||n>40){clearInterval(id);tick(v=>v+1);}},100);
    return()=>clearInterval(id);
  },[]);
  const lib=(typeof window!=="undefined"&&window.lucide&&window.lucide.icons)||null;
  const spec=lib?(lib[toPascal(name)]||lib[name]):null;
  const kids=nodes(spec);
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={{display:"block",flexShrink:0,...style}} aria-hidden="true" {...rest}>
      {Array.isArray(kids)?kids.map(([tag,attrs],i)=>React.createElement(tag,{key:i,...attrs})):null}
    </svg>
  );
}
