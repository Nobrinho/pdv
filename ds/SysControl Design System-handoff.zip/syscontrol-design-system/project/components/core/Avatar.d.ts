import * as React from "react";
/** Circular user mark — image when available, otherwise up to two initials. */
export interface AvatarProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"> {
  /** Full name; the first two words supply the initials. */
  name?: string;
  src?: string;
  /** Named step or an explicit pixel diameter. @default "md" */
  size?: "sm" | "md" | "lg" | number;
  /** @default "primary" */
  tone?: "primary" | "neutral" | "success";
  style?: React.CSSProperties;
}
export declare function Avatar(props: AvatarProps): JSX.Element;
