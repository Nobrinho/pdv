import * as React from "react";
/**
 * SysControl's primary action control — shadcn/ui geometry (36px default height,
 * 8px radius, 14px medium text) with HeroUI's 0.97 press scale.
 * @startingPoint section="Core" subtitle="Action buttons in every variant and size" viewport="700x220"
 */
export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>,"style"> {
  children?: React.ReactNode;
  /** @default "primary" */
  variant?: "primary" | "secondary" | "outline" | "ghost" | "flat" | "destructive" | "success" | "link";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Lucide icon name rendered before the label. */
  icon?: string;
  /** Lucide icon name rendered after the label. */
  iconEnd?: string;
  /** @default false */
  fullWidth?: boolean;
  /** @default false */
  disabled?: boolean;
  /** Swaps the leading icon for a spinner and blocks interaction. @default false */
  loading?: boolean;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
