import * as React from "react";
/** A 1px rule. Optional centred uppercase label for splitting form sections. */
export interface DividerProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"> {
  /** @default "horizontal" */
  orientation?: "horizontal" | "vertical";
  /** Renders the rule as a labelled section break. */
  label?: string;
  style?: React.CSSProperties;
}
export declare function Divider(props: DividerProps): JSX.Element;
