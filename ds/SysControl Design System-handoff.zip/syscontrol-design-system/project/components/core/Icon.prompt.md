Renders a Lucide glyph — use it anywhere SysControl needs an icon; never hand-draw SVG.

```jsx
<Icon name="shopping-cart" size={16} />
```

Requires the Lucide UMD script on the page: `<script src="https://unpkg.com/lucide@0.469.0/dist/umd/lucide.js"></script>`.
Default size 16 sits inside 36px controls; use 18–20 in the sidebar, 14 in badges and table cells.
