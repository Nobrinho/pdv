import React from "react";
import { Icon } from "./Icon.jsx";

const SIZES={
  sm:{height:"var(--control-sm)",padding:"0 12px",fontSize:"var(--text-body)",gap:"6px",radius:"var(--radius-sm)",icon:14},
  md:{height:"var(--control-md)",padding:"0 16px",fontSize:"var(--text-body)",gap:"8px",radius:"var(--radius-md)",icon:16},
  lg:{height:"var(--control-lg)",padding:"0 24px",fontSize:"var(--text-medium)",gap:"8px",radius:"var(--radius-md)",icon:18}
};
const VARIANTS={
  primary:{background:"var(--primary)",color:"var(--primary-foreground)",border:"1px solid transparent",hover:{background:"var(--primary-hover)"}},
  secondary:{background:"var(--secondary)",color:"var(--secondary-foreground)",border:"1px solid transparent",hover:{background:"var(--secondary-hover)"}},
  outline:{background:"var(--background)",color:"var(--foreground)",border:"1px solid var(--border)",boxShadow:"var(--shadow-xs)",hover:{background:"var(--accent)"}},
  ghost:{background:"transparent",color:"var(--foreground)",border:"1px solid transparent",hover:{background:"var(--accent)"}},
  flat:{background:"var(--primary-soft)",color:"var(--primary-soft-foreground)",border:"1px solid transparent",hover:{background:"var(--primary-soft-hover)"}},
  destructive:{background:"var(--danger)",color:"var(--danger-foreground)",border:"1px solid transparent",hover:{background:"var(--danger-hover)"}},
  success:{background:"var(--success)",color:"var(--success-foreground)",border:"1px solid transparent",hover:{background:"var(--success-hover)"}},
  link:{background:"transparent",color:"var(--primary)",border:"1px solid transparent",hover:{textDecoration:"underline"}}
};

export function Button({children,variant="primary",size="md",icon,iconEnd,fullWidth=false,disabled=false,loading=false,type="button",style,onClick,...rest}){
  const [hover,setHover]=React.useState(false);
  const [press,setPress]=React.useState(false);
  const s=SIZES[size]||SIZES.md;
  const v=VARIANTS[variant]||VARIANTS.primary;
  const css={
    display:"inline-flex",alignItems:"center",justifyContent:"center",boxSizing:"border-box",
    height:s.height,padding:s.padding,gap:s.gap,fontSize:s.fontSize,lineHeight:1,
    fontFamily:"var(--font-sans)",fontWeight:"var(--weight-medium)",letterSpacing:"var(--tracking-label)",
    borderRadius:s.radius,whiteSpace:"nowrap",cursor:disabled||loading?"not-allowed":"pointer",
    width:fullWidth?"100%":"auto",outline:"none",appearance:"none",userSelect:"none",
    transition:"var(--transition-colors), var(--transition-transform)",
    transform:press&&!disabled?"scale(var(--press-scale))":"scale(1)",
    opacity:disabled?"var(--disabled-opacity)":1,
    ...v,...(hover&&!disabled&&!loading?v.hover:null),hover:undefined,...style
  };
  delete css.hover;
  return (
    <button type={type} disabled={disabled||loading} style={css} onClick={onClick}
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setHover(false);setPress(false);}}
      onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)} {...rest}>
      {loading?<Spin size={s.icon}/>:(icon?<Icon name={icon} size={s.icon}/>:null)}
      {children}
      {iconEnd?<Icon name={iconEnd} size={s.icon}/>:null}
    </button>
  );
}
function Spin({size}){
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{animation:"sc-spin 700ms linear infinite"}}>
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3"/>
    <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
    <style>{"@keyframes sc-spin{to{transform:rotate(360deg)}}"}</style>
  </svg>;
}
