import React from "react";

export function Card({children,padding=20,interactive=false,style,...rest}){
  const [h,setH]=React.useState(false);
  return <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{display:"flex",flexDirection:"column",boxSizing:"border-box",background:"var(--card)",
      color:"var(--card-foreground)",border:"1px solid var(--border)",borderRadius:"var(--radius-xl)",
      boxShadow:interactive&&h?"var(--shadow-sm)":"var(--shadow-xs)",padding,
      transition:"box-shadow var(--duration-base) var(--ease-standard), background var(--duration-base) var(--ease-standard)",
      cursor:interactive?"pointer":"default",...style}} {...rest}>{children}</div>;
}
export function CardHeader({title,description,action,style,...rest}){
  return <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:16,marginBottom:16,...style}} {...rest}>
    <div style={{display:"flex",flexDirection:"column",gap:2,minWidth:0}}>
      <div style={{fontFamily:"var(--font-display)",fontSize:"var(--text-medium)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-heading)",color:"var(--card-foreground)",lineHeight:1.3}}>{title}</div>
      {description?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--muted-foreground)",lineHeight:"var(--leading-body)"}}>{description}</div>:null}
    </div>
    {action?<div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>{action}</div>:null}
  </div>;
}
export function CardFooter({children,style,...rest}){
  return <div style={{display:"flex",alignItems:"center",gap:8,marginTop:16,paddingTop:16,borderTop:"1px solid var(--border)",...style}} {...rest}>{children}</div>;
}
