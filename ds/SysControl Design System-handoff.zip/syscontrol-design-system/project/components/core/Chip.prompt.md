Filter token above lists and tables — category, brand, applied search facet.

```jsx
<Chip selected onClick={...}>Todos</Chip>
<Chip icon="tag" onRemove={...}>Freios</Chip>
```

Selected chips fill with `--primary`. Removable chips get the tighter right padding automatically.
