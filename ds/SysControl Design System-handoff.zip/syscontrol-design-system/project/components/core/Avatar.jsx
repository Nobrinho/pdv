import React from "react";

const S={sm:28,md:36,lg:44};
export function Avatar({name="",src,size="md",tone="primary",style,...rest}){
  const px=typeof size==="number"?size:(S[size]||S.md);
  const initials=name.trim().split(/\s+/).slice(0,2).map(w=>w[0]).join("").toUpperCase();
  const tones={primary:["var(--avatar-primary)","var(--avatar-primary-foreground)"],neutral:["var(--avatar-neutral)","var(--avatar-neutral-foreground)"],success:["var(--avatar-success)","var(--avatar-success-foreground)"]};
  const [bg,fg]=tones[tone]||tones.primary;
  return <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",flexShrink:0,
    width:px,height:px,borderRadius:"var(--radius-full)",overflow:"hidden",background:bg,color:fg,
    fontFamily:"var(--font-sans)",fontSize:Math.round(px*0.36),fontWeight:"var(--weight-semibold)",
    letterSpacing:"var(--tracking-label)",...style}} {...rest}>
    {src?<img src={src} alt={name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:initials}
  </span>;
}
