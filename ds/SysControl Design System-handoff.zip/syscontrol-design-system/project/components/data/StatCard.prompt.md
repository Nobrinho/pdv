Dashboard KPI tile. Four across on desktop, two on tablet, scroll-snap row on mobile.

```jsx
<StatCard label="Faturamento hoje" value="R$ 14.280,50" delta={12.4} deltaLabel="vs. ontem" icon="banknote" tone="primary" />
```

Format the value yourself with `toLocaleString("pt-BR")` — the component does not format currency.
