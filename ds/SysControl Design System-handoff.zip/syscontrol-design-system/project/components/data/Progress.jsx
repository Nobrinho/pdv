import React from "react";

const TONES={primary:"var(--primary)",success:"var(--success)",warning:"var(--warning)",danger:"var(--danger)"};
export function Progress({value=0,max=100,tone="primary",label,showValue=false,size="md",style,...rest}){
  const pct=Math.max(0,Math.min(100,(value/max)*100));
  const h=size==="sm"?4:(size==="lg"?10:6);
  return <div style={{display:"flex",flexDirection:"column",gap:6,width:"100%",...style}} {...rest}>
    {label||showValue?<div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",
      fontFamily:"var(--font-sans)",fontSize:"var(--text-small)"}}>
      <span style={{color:"var(--foreground)"}}>{label}</span>
      {showValue?<span style={{color:"var(--muted-foreground)",fontVariantNumeric:"tabular-nums"}}>{Math.round(pct)}%</span>:null}
    </div>:null}
    <div style={{width:"100%",height:h,borderRadius:"var(--radius-full)",background:"var(--content3)",overflow:"hidden"}}>
      <div style={{width:pct+"%",height:"100%",borderRadius:"var(--radius-full)",
        background:TONES[tone]||TONES.primary,transition:"width var(--duration-slow) var(--ease-out)"}}/>
    </div>
  </div>;
}
