import * as React from "react";
/** Shimmering placeholder block for content that is still loading. */
export interface SkeletonProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"style"> {
  /** @default "100%" */
  width?: string | number;
  /** @default 14 */
  height?: string | number;
  radius?: string;
  /** Renders a circle of diameter `height`. @default false */
  circle?: boolean;
  style?: React.CSSProperties;
}
export declare function Skeleton(props: SkeletonProps): JSX.Element;
