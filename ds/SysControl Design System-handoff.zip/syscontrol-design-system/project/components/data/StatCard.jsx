import React from "react";
import { Icon } from "../core/Icon.jsx";
export function StatCard({label,value,unit,delta,deltaLabel,icon,tone="neutral",style,...rest}){
  const up=typeof delta==="number"&&delta>0;
  const down=typeof delta==="number"&&delta<0;
  const accents={neutral:"var(--neutral-soft)",primary:"var(--primary-soft)",success:"var(--success-soft)",warning:"var(--warning-soft)",danger:"var(--danger-soft)"};
  const glyph={neutral:"var(--muted-foreground)",primary:"var(--primary)",success:"var(--success)",warning:"var(--warning-icon)",danger:"var(--danger)"};
  return <div style={{display:"flex",flexDirection:"column",gap:10,boxSizing:"border-box",padding:20,
    background:"var(--card)",border:"1px solid var(--border)",borderRadius:"var(--radius-xl)",
    boxShadow:"var(--shadow-xs)",...style}} {...rest}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12}}>
      <span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",fontWeight:"var(--weight-semibold)",
        letterSpacing:"var(--tracking-caps)",textTransform:"uppercase",color:"var(--muted-foreground)"}}>{label}</span>
      {icon?<span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:32,height:32,
        borderRadius:"var(--radius-md)",background:accents[tone]||accents.neutral,color:glyph[tone]||glyph.neutral}}>
        <Icon name={icon} size={16}/></span>:null}
    </div>
    <div style={{display:"flex",alignItems:"baseline",gap:6}}>
      <span style={{fontFamily:"var(--font-display)",fontSize:"var(--text-h2)",lineHeight:1,
        fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-display)",color:"var(--foreground)",
        fontVariantNumeric:"tabular-nums"}}>{value}</span>
      {unit?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--muted-foreground)"}}>{unit}</span>:null}
    </div>
    {(delta!==undefined&&delta!==null)||deltaLabel?<div style={{display:"flex",alignItems:"center",gap:6,
      fontFamily:"var(--font-sans)",fontSize:"var(--text-small)"}}>
      {typeof delta==="number"?<span style={{display:"inline-flex",alignItems:"center",gap:3,
        color:up?"var(--money-positive)":(down?"var(--money-negative)":"var(--muted-foreground)"),
        fontWeight:"var(--weight-semibold)",fontVariantNumeric:"tabular-nums"}}>
        <Icon name={up?"trending-up":(down?"trending-down":"minus")} size={14}/>
        {(up?"+":"")+delta.toLocaleString("pt-BR",{maximumFractionDigits:1})+"%"}</span>:null}
      {deltaLabel?<span style={{color:"var(--muted-foreground)"}}>{deltaLabel}</span>:null}
    </div>:null}
  </div>;
}
