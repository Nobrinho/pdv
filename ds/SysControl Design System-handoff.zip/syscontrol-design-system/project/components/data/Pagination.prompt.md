Sits directly under a DataTable, inside the same Card, separated by a Divider.

```jsx
<Pagination page={2} pageCount={8} total={148} pageSize={20} onChange={setPage} />
```

Shows a sliding window of five page numbers.
