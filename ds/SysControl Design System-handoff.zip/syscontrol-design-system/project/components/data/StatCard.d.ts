import * as React from "react";
/**
 * Headline metric tile for the dashboard and caixa summary strip.
 * @startingPoint section="Data" subtitle="KPI tile with delta and icon" viewport="700x180"
 */
export interface StatCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  /** Uppercase caption above the number. */
  label: React.ReactNode;
  /** Pre-formatted value — format currency with pt-BR before passing it in. */
  value: React.ReactNode;
  /** Small muted unit after the value, e.g. "itens". */
  unit?: React.ReactNode;
  /** Percentage change; positive renders green with an up arrow. */
  delta?: number;
  /** Context for the delta, e.g. "vs. ontem". */
  deltaLabel?: React.ReactNode;
  /** Lucide icon shown in the tinted 32px square. */
  icon?: string;
  /** Tints the icon square. @default "neutral" */
  tone?: "neutral" | "primary" | "success" | "warning" | "danger";
  style?: React.CSSProperties;
}
export declare function StatCard(props: StatCardProps): JSX.Element;
