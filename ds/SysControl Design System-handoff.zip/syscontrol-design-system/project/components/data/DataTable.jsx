import React from "react";
import { Icon } from "../core/Icon.jsx";
export function DataTable({columns=[],rows=[],selectable=false,onRowClick,dense=false,emptyLabel="Nenhum registro",style,...rest}){
  const [hover,setHover]=React.useState(-1);
  const pad=dense?"8px 12px":"12px 12px";
  return <div style={{width:"100%",overflowX:"auto",...style}} {...rest}>
    <table style={{width:"100%",borderCollapse:"collapse",fontFamily:"var(--font-sans)",fontSize:"var(--text-body)"}}>
      <thead>
        <tr>
          {selectable?<th style={{width:40,padding:pad,borderBottom:"1px solid var(--border)",background:"var(--content2)"}}/>:null}
          {columns.map(c=><th key={c.key} style={{padding:pad,textAlign:c.align||"left",whiteSpace:"nowrap",
            width:c.width,background:"var(--content2)",borderBottom:"1px solid var(--border)",
            fontSize:"var(--text-tiny)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-caps)",
            textTransform:"uppercase",color:"var(--muted-foreground)"}}>
            <span style={{display:"inline-flex",alignItems:"center",gap:4,justifyContent:c.align==="right"?"flex-end":"flex-start"}}>
              {c.header}{c.sortable?<Icon name="chevrons-up-down" size={12}/>:null}</span>
          </th>)}
        </tr>
      </thead>
      <tbody>
        {rows.length===0?<tr><td colSpan={columns.length+(selectable?1:0)}
          style={{padding:"40px 12px",textAlign:"center",color:"var(--muted-foreground)"}}>{emptyLabel}</td></tr>:null}
        {rows.map((r,i)=><tr key={r.id??i} onClick={()=>onRowClick&&onRowClick(r,i)}
          onMouseEnter={()=>setHover(i)} onMouseLeave={()=>setHover(-1)}
          style={{background:hover===i?"var(--hover-surface)":"transparent",cursor:onRowClick?"pointer":"default",
            transition:"background var(--duration-fast) var(--ease-standard)"}}>
          {selectable?<td style={{padding:pad,borderBottom:"1px solid var(--border)"}}>{r.select}</td>:null}
          {columns.map(c=><td key={c.key} style={{padding:pad,textAlign:c.align||"left",
            borderBottom:"1px solid var(--border)",color:"var(--foreground)",verticalAlign:"middle",
            fontFamily:c.mono?"var(--font-mono)":"inherit",fontVariantNumeric:c.mono?"tabular-nums":"normal",
            whiteSpace:c.wrap?"normal":"nowrap"}}>
            {c.render?c.render(r,i):r[c.key]}</td>)}
        </tr>)}
      </tbody>
    </table>
  </div>;
}
