import * as React from "react";
/** Centred placeholder for empty tables, empty carts and zero search results. */
export interface EmptyStateProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"title"|"style"> {
  /** Lucide icon in the 48px grey disc. @default "inbox" */
  icon?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Usually a single primary Button. */
  action?: React.ReactNode;
  /** Halves the vertical padding — for panels and modals. @default false */
  compact?: boolean;
  style?: React.CSSProperties;
}
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
