Every list in SysControl. Columns are declarative; put Badges and IconButtons in `render`.

```jsx
<DataTable
  columns={[
    {key:"sku",header:"Código",mono:true},
    {key:"nome",header:"Peça",wrap:true},
    {key:"qtd",header:"Estoque",align:"right",mono:true,sortable:true},
    {key:"status",header:"Situação",render:r=><Badge tone={r.tone} dot>{r.status}</Badge>}
  ]}
  rows={rows} onRowClick={openPart} />
```

Set `mono` on numeric columns so decimals line up. Use `dense` inside modals and the PDV cart.
