import * as React from "react";
/**
 * The workhorse list view — estoque, vendas, clientes, movimentações de caixa.
 * Header is uppercase 12px on `--content2`; rows separate with a 1px `--border` and tint on hover.
 * @startingPoint section="Data" subtitle="Sortable data table with status cells" viewport="700x340"
 */
export interface DataTableColumn {
  key: string;
  header: React.ReactNode;
  /** @default "left" */
  align?: "left" | "right" | "center";
  /** CSS width for the column. */
  width?: string | number;
  /** Renders the cell in the tabular mono face — use for SKU, quantity and money. */
  mono?: boolean;
  /** Allows the cell to wrap instead of staying on one line. */
  wrap?: boolean;
  /** Shows a sort affordance in the header. */
  sortable?: boolean;
  /** Custom cell renderer; receives the row and its index. */
  render?: (row: any, index: number) => React.ReactNode;
}
export interface DataTableProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  columns?: DataTableColumn[];
  rows?: any[];
  /** Adds a leading 40px column that renders each row's `select` node. @default false */
  selectable?: boolean;
  onRowClick?: (row: any, index: number) => void;
  /** Tightens row padding from 12px to 8px. @default false */
  dense?: boolean;
  emptyLabel?: string;
  style?: React.CSSProperties;
}
export declare function DataTable(props: DataTableProps): JSX.Element;
