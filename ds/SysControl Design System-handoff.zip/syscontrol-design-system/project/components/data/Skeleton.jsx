import React from "react";

export function Skeleton({width="100%",height=14,radius="var(--radius-sm)",circle=false,style,...rest}){
  const d=circle?(typeof height==="number"?height:20):null;
  return <span style={{display:"block",width:circle?d:width,height:circle?d:height,
    borderRadius:circle?"var(--radius-full)":radius,background:"var(--content2)",
    backgroundImage:"linear-gradient(90deg,var(--skeleton-from) 0%,var(--skeleton-to) 50%,var(--skeleton-from) 100%)",
    backgroundSize:"200% 100%",animation:"sc-shimmer 1.4s ease infinite",...style}} {...rest}>
    <style>{"@keyframes sc-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}"}</style>
  </span>;
}
