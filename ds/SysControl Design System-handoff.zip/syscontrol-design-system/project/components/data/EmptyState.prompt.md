Fills an empty region. Always name the next action.

```jsx
<EmptyState icon="shopping-cart" title="Carrinho vazio"
  description="Busque uma peça pelo código ou leia o código de barras para começar."
  action={<Button icon="plus">Adicionar peça</Button>} />
```
