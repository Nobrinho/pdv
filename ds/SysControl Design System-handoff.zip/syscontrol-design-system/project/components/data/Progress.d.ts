import * as React from "react";
/** Horizontal bar — stock level against reorder point, monthly target, import progress. */
export interface ProgressProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  /** @default 0 */
  value?: number;
  /** @default 100 */
  max?: number;
  /** @default "primary" */
  tone?: "primary" | "success" | "warning" | "danger";
  label?: React.ReactNode;
  /** Shows the rounded percentage on the right of the label row. @default false */
  showValue?: boolean;
  /** Track height 4 / 6 / 10px. @default "md" */
  size?: "sm" | "md" | "lg";
  style?: React.CSSProperties;
}
export declare function Progress(props: ProgressProps): JSX.Element;
