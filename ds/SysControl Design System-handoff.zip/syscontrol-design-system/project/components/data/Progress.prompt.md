Bar meter. In estoque views, tone the bar by level: success ≥ 60%, warning 20–59%, danger < 20%.

```jsx
<Progress label="Meta do mês" value={68} showValue />
<Progress value={12} tone="danger" size="sm" />
```
