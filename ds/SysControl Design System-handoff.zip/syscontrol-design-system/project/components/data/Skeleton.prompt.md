Loading placeholder — mirror the shape of the content it stands in for.

```jsx
<Skeleton width={180} /> <Skeleton circle height={36} />
```

Three to five rows is enough; never fill the whole table.
