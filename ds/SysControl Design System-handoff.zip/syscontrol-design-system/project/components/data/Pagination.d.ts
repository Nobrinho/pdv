import * as React from "react";
/** Table footer pager with a pt-BR range summary on the left. */
export interface PaginationProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"onChange"|"style"> {
  /** 1-indexed. @default 1 */
  page?: number;
  /** @default 1 */
  pageCount?: number;
  onChange?: (page: number) => void;
  /** Total record count — drives the "Mostrando 1–20 de 148" summary. */
  total?: number;
  /** Rows per page; required for the range summary. */
  pageSize?: number;
  style?: React.CSSProperties;
}
export declare function Pagination(props: PaginationProps): JSX.Element;
