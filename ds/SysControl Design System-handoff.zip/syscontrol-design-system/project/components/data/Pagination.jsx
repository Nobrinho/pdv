import React from "react";
import { Icon } from "../core/Icon.jsx";
function PageBtn({children,active,disabled,onClick,label}){
  const [h,setH]=React.useState(false);
  return <button type="button" aria-label={label} disabled={disabled} onClick={onClick}
    onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{minWidth:32,height:32,padding:"0 8px",display:"inline-flex",alignItems:"center",justifyContent:"center",
      borderRadius:"var(--radius-sm)",border:"1px solid "+(active?"var(--primary)":"var(--border)"),
      background:active?"var(--primary)":(h&&!disabled?"var(--accent)":"var(--background)"),
      color:active?"var(--primary-foreground)":"var(--foreground)",fontFamily:"var(--font-sans)",
      fontSize:"var(--text-body)",fontWeight:"var(--weight-medium)",fontVariantNumeric:"tabular-nums",
      cursor:disabled?"not-allowed":"pointer",opacity:disabled?"var(--disabled-opacity)":1,
      transition:"var(--transition-colors)"}}>{children}</button>;
}
export function Pagination({page=1,pageCount=1,onChange,total,pageSize,style,...rest}){
  const go=p=>{if(p>=1&&p<=pageCount&&p!==page&&onChange)onChange(p);};
  const pages=[];
  const from=Math.max(1,Math.min(page-2,pageCount-4));
  for(let i=from;i<=Math.min(pageCount,from+4);i++)pages.push(i);
  const first=total!=null&&pageSize?(page-1)*pageSize+1:null;
  const last=total!=null&&pageSize?Math.min(total,page*pageSize):null;
  return <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap",...style}} {...rest}>
    <span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--muted-foreground)",fontVariantNumeric:"tabular-nums"}}>
      {total!=null?(pageSize?`Mostrando ${first}–${last} de ${total}`:`${total} registros`):null}</span>
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <PageBtn label="Anterior" disabled={page<=1} onClick={()=>go(page-1)}><Icon name="chevron-left" size={16}/></PageBtn>
      {pages.map(p=><PageBtn key={p} active={p===page} onClick={()=>go(p)}>{p}</PageBtn>)}
      <PageBtn label="Próxima" disabled={page>=pageCount} onClick={()=>go(page+1)}><Icon name="chevron-right" size={16}/></PageBtn>
    </div>
  </div>;
}
