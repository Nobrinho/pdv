import React from "react";
import { Icon } from "../core/Icon.jsx";
export function EmptyState({icon="inbox",title,description,action,compact=false,style,...rest}){
  return <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
    textAlign:"center",gap:8,padding:compact?"32px 20px":"56px 24px",...style}} {...rest}>
    <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:48,height:48,
      borderRadius:"var(--radius-full)",background:"var(--content2)",color:"var(--muted-foreground)",marginBottom:4}}>
      <Icon name={icon} size={22}/></span>
    <div style={{fontFamily:"var(--font-display)",fontSize:"var(--text-medium)",fontWeight:"var(--weight-semibold)",
      letterSpacing:"var(--tracking-heading)",color:"var(--foreground)"}}>{title}</div>
    {description?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--muted-foreground)",
      maxWidth:380,lineHeight:"var(--leading-body)"}}>{description}</div>:null}
    {action?<div style={{marginTop:8}}>{action}</div>:null}
  </div>;
}
