import * as React from "react";
/** Label + control + hint/error wrapper. Every form control in SysControl sits inside one. */
export interface FieldProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"style"> {
  label?: React.ReactNode;
  /** Muted helper text; hidden while `error` is set. */
  hint?: React.ReactNode;
  /** Red message that replaces the hint. */
  error?: React.ReactNode;
  /** Appends a red asterisk to the label. @default false */
  required?: boolean;
  htmlFor?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Field(props: FieldProps): JSX.Element;
