Exclusive choice with room for per-option explanation.

```jsx
<RadioGroup defaultValue="pix" options={[
  {value:"pix",label:"Pix",description:"Confirmação imediata"},
  {value:"credito",label:"Cartão de crédito",description:"Até 12x"},
  {value:"dinheiro",label:"Dinheiro"}
]} />
```

Six or more options belong in a `Select`.
