Wraps any control with its label, hint and error. 6px gap, 14px medium label.

```jsx
<Field label="Código da peça" hint="SKU ou código do fabricante" required>
  <Input placeholder="Ex.: FR-2280" />
</Field>
```

`error` replaces `hint`; pair it with `invalid` on the control.
