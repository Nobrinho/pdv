Multi-select and boolean settings. Works controlled or uncontrolled.

```jsx
<Checkbox label="Aplicar desconto no total" />
<Checkbox indeterminate />   {/* table select-all header */}
```
