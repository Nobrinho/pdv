import React from "react";

export function Textarea({rows=4,invalid=false,disabled=false,style,...rest}){
  const [focus,setFocus]=React.useState(false);
  return <textarea rows={rows} disabled={disabled} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
    style={{width:"100%",boxSizing:"border-box",padding:"10px 12px",resize:"vertical",
      fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",lineHeight:"var(--leading-body)",
      color:"var(--foreground)",background:disabled?"var(--muted)":"var(--background)",
      border:"1px solid "+(invalid?"var(--danger)":(focus?"var(--ring)":"var(--input)")),
      borderRadius:"var(--radius-md)",outline:"none",
      boxShadow:focus?"0 0 0 var(--ring-width) var(--ring-shadow)":"var(--shadow-xs)",
      transition:"border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
      opacity:disabled?"var(--disabled-opacity)":1,...style}} {...rest}/>;
}
