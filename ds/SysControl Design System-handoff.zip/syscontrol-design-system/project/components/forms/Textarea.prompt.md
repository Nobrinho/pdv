Multi-line text — observações on a sale, descrição on a part.

```jsx
<Field label="Observações"><Textarea rows={3} placeholder="Opcional" /></Field>
```
