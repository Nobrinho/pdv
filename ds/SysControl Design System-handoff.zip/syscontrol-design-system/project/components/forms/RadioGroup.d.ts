import * as React from "react";
/** Exclusive choice from 2–5 options — payment method, discount type, report period. */
export interface RadioOption { value: string; label: string; description?: string }
export interface RadioGroupProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"onChange"|"defaultValue"|"style"> {
  options?: Array<string | RadioOption>;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  /** @default "vertical" */
  orientation?: "vertical" | "horizontal";
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function RadioGroup(props: RadioGroupProps): JSX.Element;
