import React from "react";

export function Switch({checked,defaultChecked,onChange,label,disabled=false,style,...rest}){
  const [inner,setInner]=React.useState(!!defaultChecked);
  const on=checked===undefined?inner:checked;
  const toggle=()=>{if(disabled)return;if(checked===undefined)setInner(!on);onChange&&onChange(!on);};
  return <label style={{display:"inline-flex",alignItems:"center",gap:10,cursor:disabled?"not-allowed":"pointer",
    opacity:disabled?"var(--disabled-opacity)":1,...style}} {...rest}>
    <span role="switch" aria-checked={on} onClick={toggle} style={{position:"relative",display:"inline-block",
      width:40,height:22,flexShrink:0,borderRadius:"var(--radius-full)",
      background:on?"var(--primary)":"var(--switch-track)",transition:"background var(--duration-slow) var(--ease-standard)"}}>
      <span style={{position:"absolute",top:2,left:on?20:2,width:18,height:18,borderRadius:"var(--radius-full)",
        background:"var(--switch-thumb)",boxShadow:"var(--shadow-sm)",transition:"left var(--duration-base) var(--ease-out)"}}/>
    </span>
    {label?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--foreground)"}}>{label}</span>:null}
  </label>;
}
