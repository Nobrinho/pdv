import * as React from "react";
/** Native dropdown with SysControl chrome and a Lucide chevron. */
export interface SelectOption { value: string; label: string }
export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>,"size"|"style"|"children"> {
  /** Plain strings or {value,label} pairs. */
  options?: Array<string | SelectOption>;
  /** Rendered as a disabled-looking first option with an empty value. */
  placeholder?: string;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** @default false */
  invalid?: boolean;
  /** @default true */
  fullWidth?: boolean;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;
