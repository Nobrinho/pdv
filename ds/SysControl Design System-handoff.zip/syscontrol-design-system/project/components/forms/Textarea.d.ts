import * as React from "react";
/** Multi-line text control — same border, radius and focus ring as Input. */
export interface TextareaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>,"style"> {
  /** @default 4 */
  rows?: number;
  /** @default false */
  invalid?: boolean;
  style?: React.CSSProperties;
}
export declare function Textarea(props: TextareaProps): JSX.Element;
