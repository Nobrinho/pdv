import * as React from "react";
/** 18px square checkbox with an optional label and description. Fills with `--primary` when on. */
export interface CheckboxProps extends Omit<React.HTMLAttributes<HTMLLabelElement>,"onChange"|"style"> {
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: React.ReactNode;
  description?: React.ReactNode;
  /** Renders a dash instead of the tick — for "select all" headers. @default false */
  indeterminate?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Checkbox(props: CheckboxProps): JSX.Element;
