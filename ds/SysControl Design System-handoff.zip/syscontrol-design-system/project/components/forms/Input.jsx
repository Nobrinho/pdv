import React from "react";
import { Icon } from "../core/Icon.jsx";
const H={sm:"var(--control-sm)",md:"var(--control-md)",lg:"var(--control-lg)"};
export function Input({value,defaultValue,onChange,placeholder,type="text",icon,suffix,size="md",
  invalid=false,disabled=false,readOnly=false,mono=false,fullWidth=true,style,inputStyle,...rest}){
  const [focus,setFocus]=React.useState(false);
  return <div style={{position:"relative",display:"flex",alignItems:"center",boxSizing:"border-box",
    width:fullWidth?"100%":"auto",height:H[size]||H.md,
    background:disabled?"var(--muted)":"var(--background)",
    border:"1px solid "+(invalid?"var(--danger)":(focus?"var(--ring)":"var(--input)")),
    borderRadius:"var(--radius-md)",boxShadow:focus?(invalid?"0 0 0 var(--ring-width) var(--ring-shadow-danger)":"0 0 0 var(--ring-width) var(--ring-shadow)"):"var(--shadow-xs)",
    transition:"border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
    opacity:disabled?"var(--disabled-opacity)":1,paddingLeft:icon?10:12,paddingRight:suffix?10:12,gap:8,...style}}>
    {icon?<Icon name={icon} size={16} color="var(--muted-foreground)"/>:null}
    <input type={type} value={value} defaultValue={defaultValue} onChange={onChange} placeholder={placeholder}
      disabled={disabled} readOnly={readOnly} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
      style={{flex:1,minWidth:0,border:0,outline:"none",background:"transparent",padding:0,
        fontFamily:mono?"var(--font-mono)":"var(--font-sans)",fontSize:"var(--text-body)",
        fontVariantNumeric:mono?"tabular-nums":"normal",color:"var(--foreground)",height:"100%"}} {...rest}/>
    {suffix?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--muted-foreground)",whiteSpace:"nowrap"}}>{suffix}</span>:null}
  </div>;
}
