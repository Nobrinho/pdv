Immediate-effect toggle — never inside a form that has a Save button (use Checkbox there).

```jsx
<Switch defaultChecked label="Alertar quando o estoque ficar baixo" />
```
