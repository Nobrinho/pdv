Text control for every form and the global search.

```jsx
<Input icon="search" placeholder="Buscar peça, código ou cliente" />
<Input mono suffix="BRL" defaultValue="189,90" />
<Input invalid defaultValue="" placeholder="Obrigatório" />
```

Set `mono` on anything numeric (SKU, preço, quantidade) so columns align. Focus draws a 3px teal ring at 25%.
