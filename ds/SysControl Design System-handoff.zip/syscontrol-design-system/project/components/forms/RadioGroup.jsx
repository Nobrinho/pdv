import React from "react";

export function RadioGroup({options=[],value,defaultValue,onChange,name,orientation="vertical",disabled=false,style,...rest}){
  const [inner,setInner]=React.useState(defaultValue);
  const sel=value===undefined?inner:value;
  const pick=v=>{if(disabled)return;if(value===undefined)setInner(v);onChange&&onChange(v);};
  return <div role="radiogroup" style={{display:"flex",flexDirection:orientation==="horizontal"?"row":"column",
    gap:orientation==="horizontal"?20:10,opacity:disabled?"var(--disabled-opacity)":1,...style}} {...rest}>
    {options.map(o=>{const v=typeof o==="string"?o:o.value;const l=typeof o==="string"?o:o.label;
      const d=typeof o==="string"?null:o.description;const on=sel===v;
      return <label key={v} onClick={()=>pick(v)} style={{display:"inline-flex",alignItems:d?"flex-start":"center",
        gap:10,cursor:disabled?"not-allowed":"pointer"}}>
        <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",flexShrink:0,
          width:18,height:18,marginTop:d?2:0,borderRadius:"var(--radius-full)",background:"var(--background)",
          border:"1px solid "+(on?"var(--primary)":"var(--input)"),boxShadow:"var(--shadow-xs)",
          transition:"var(--transition-colors)"}}>
          {on?<span style={{width:8,height:8,borderRadius:"var(--radius-full)",background:"var(--primary)"}}/>:null}
        </span>
        <span style={{display:"flex",flexDirection:"column",gap:1}}>
          <span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--foreground)"}}>{l}</span>
          {d?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--muted-foreground)"}}>{d}</span>:null}
        </span>
      </label>;})}
  </div>;
}
