Dropdown for closed lists — categoria, forma de pagamento, fornecedor, vendedor.

```jsx
<Select placeholder="Categoria" options={["Freios","Suspensão","Motor","Elétrica"]} />
```

For open-ended lookup (buscar peça) use `Input icon="search"` instead.
