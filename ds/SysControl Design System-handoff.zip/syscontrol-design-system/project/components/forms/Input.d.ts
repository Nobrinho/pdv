import * as React from "react";
/**
 * Single-line text control — shadcn/ui geometry (36px, 8px radius, 3px focus ring).
 * @startingPoint section="Forms" subtitle="Text, search, money and quantity inputs" viewport="700x300"
 */
export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>,"size"|"style"> {
  /** Lucide icon rendered inside the left edge. */
  icon?: string;
  /** Static trailing text — a unit, currency code or "un.". */
  suffix?: React.ReactNode;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Red border and red focus ring. @default false */
  invalid?: boolean;
  /** Switches to the tabular mono face — use for SKU, price and quantity. @default false */
  mono?: boolean;
  /** @default true */
  fullWidth?: boolean;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
