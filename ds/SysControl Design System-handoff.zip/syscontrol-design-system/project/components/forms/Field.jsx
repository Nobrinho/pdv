import React from "react";

export function Field({label,hint,error,required=false,htmlFor,children,style,...rest}){
  return <div style={{display:"flex",flexDirection:"column",gap:6,...style}} {...rest}>
    {label?<label htmlFor={htmlFor} style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
      fontWeight:"var(--weight-medium)",color:"var(--foreground)",letterSpacing:"var(--tracking-label)"}}>
      {label}{required?<span style={{color:"var(--danger)",marginLeft:3}}>*</span>:null}</label>:null}
    {children}
    {error?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--danger)"}}>{error}</span>
      :(hint?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--muted-foreground)"}}>{hint}</span>:null)}
  </div>;
}
