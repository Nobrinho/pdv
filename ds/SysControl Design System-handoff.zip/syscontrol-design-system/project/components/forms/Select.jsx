import React from "react";
import { Icon } from "../core/Icon.jsx";
const H={sm:"var(--control-sm)",md:"var(--control-md)",lg:"var(--control-lg)"};
export function Select({options=[],value,defaultValue,onChange,placeholder,size="md",invalid=false,disabled=false,fullWidth=true,style,...rest}){
  const [focus,setFocus]=React.useState(false);
  return <div style={{position:"relative",display:"flex",alignItems:"center",boxSizing:"border-box",
    width:fullWidth?"100%":"auto",height:H[size]||H.md,
    background:disabled?"var(--muted)":"var(--background)",
    border:"1px solid "+(invalid?"var(--danger)":(focus?"var(--ring)":"var(--input)")),
    borderRadius:"var(--radius-md)",
    boxShadow:focus?"0 0 0 var(--ring-width) var(--ring-shadow)":"var(--shadow-xs)",
    transition:"border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
    opacity:disabled?"var(--disabled-opacity)":1,...style}}>
    <select value={value} defaultValue={defaultValue} onChange={onChange} disabled={disabled}
      onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
      style={{appearance:"none",WebkitAppearance:"none",width:"100%",height:"100%",border:0,outline:"none",
        background:"transparent",padding:"0 32px 0 12px",fontFamily:"var(--font-sans)",
        fontSize:"var(--text-body)",color:value===""&&placeholder?"var(--muted-foreground)":"var(--foreground)",
        cursor:disabled?"not-allowed":"pointer"}} {...rest}>
      {placeholder?<option value="">{placeholder}</option>:null}
      {options.map(o=>{const v=typeof o==="string"?o:o.value;const l=typeof o==="string"?o:o.label;
        return <option key={v} value={v}>{l}</option>;})}
    </select>
    <span style={{position:"absolute",right:10,pointerEvents:"none",display:"flex"}}>
      <Icon name="chevron-down" size={16} color="var(--muted-foreground)"/></span>
  </div>;
}
