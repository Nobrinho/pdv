import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Checkbox({checked,defaultChecked,onChange,label,description,disabled=false,indeterminate=false,style,...rest}){
  const [inner,setInner]=React.useState(!!defaultChecked);
  const on=checked===undefined?inner:checked;
  const toggle=()=>{if(disabled)return;if(checked===undefined)setInner(!on);onChange&&onChange(!on);};
  return <label style={{display:"inline-flex",alignItems:description?"flex-start":"center",gap:10,
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?"var(--disabled-opacity)":1,...style}} {...rest}>
    <span onClick={toggle} style={{display:"inline-flex",alignItems:"center",justifyContent:"center",flexShrink:0,
      width:18,height:18,marginTop:description?2:0,borderRadius:"var(--radius-xs)",
      background:on||indeterminate?"var(--primary)":"var(--background)",
      border:"1px solid "+(on||indeterminate?"var(--primary)":"var(--input)"),
      boxShadow:on||indeterminate?"none":"var(--shadow-xs)",color:"var(--primary-foreground)",
      transition:"var(--transition-colors)"}}>
      {indeterminate?<Icon name="minus" size={12} strokeWidth={3}/>:(on?<Icon name="check" size={12} strokeWidth={3}/>:null)}
    </span>
    {label||description?<span style={{display:"flex",flexDirection:"column",gap:1}}>
      {label?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",color:"var(--foreground)"}}>{label}</span>:null}
      {description?<span style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",color:"var(--muted-foreground)"}}>{description}</span>:null}
    </span>:null}
  </label>;
}
