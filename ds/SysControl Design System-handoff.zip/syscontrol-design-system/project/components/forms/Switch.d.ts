import * as React from "react";
/** 40×22 toggle for settings that take effect immediately. */
export interface SwitchProps extends Omit<React.HTMLAttributes<HTMLLabelElement>,"onChange"|"style"> {
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: React.ReactNode;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Switch(props: SwitchProps): JSX.Element;
