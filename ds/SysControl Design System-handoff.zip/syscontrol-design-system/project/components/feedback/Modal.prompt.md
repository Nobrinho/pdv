Dialog for focused tasks — finalizar venda, sangria de caixa, editar peça.

```jsx
<Modal open={open} onClose={close} title="Finalizar venda" description="Pedido #2041 · 6 itens"
  footer={<><Button variant="ghost" onClick={close}>Cancelar</Button><Button variant="success" icon="check">Confirmar</Button></>}>
  …
</Modal>
```

Destructive confirms use `size="sm"` and a `destructive` primary.
