import * as React from "react";
/** Inline banner for stock warnings, closed-register notices and validation summaries. */
export interface AlertProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"title"|"style"> {
  /** @default "info" */
  tone?: "info" | "success" | "warning" | "danger";
  title?: React.ReactNode;
  children?: React.ReactNode;
  /** Usually a small ghost or link Button. */
  action?: React.ReactNode;
  /** When set, renders a dismiss ×. */
  onClose?: () => void;
  style?: React.CSSProperties;
}
export declare function Alert(props: AlertProps): JSX.Element;
