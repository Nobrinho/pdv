import React from "react";
import { Icon } from "../core/Icon.jsx";
const T={info:{ic:"info",c:"var(--info)"},success:{ic:"circle-check",c:"var(--success)"},
  warning:{ic:"triangle-alert",c:"var(--warning-icon)"},danger:{ic:"circle-alert",c:"var(--danger)"}};
export function Toast({tone="success",title,description,onClose,action,style,...rest}){
  const t=T[tone]||T.success;
  return <div role="status" style={{display:"flex",alignItems:"flex-start",gap:10,boxSizing:"border-box",
    minWidth:280,maxWidth:400,padding:"12px 14px",background:"var(--card)",border:"1px solid var(--border)",
    borderRadius:"var(--radius-lg)",boxShadow:"var(--shadow-medium)",...style}} {...rest}>
    <span style={{display:"flex",marginTop:1,color:t.c}}><Icon name={t.ic} size={17}/></span>
    <div style={{flex:1,minWidth:0,display:"flex",flexDirection:"column",gap:2}}>
      <div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",fontWeight:"var(--weight-semibold)",
        color:"var(--foreground)"}}>{title}</div>
      {description?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",
        color:"var(--muted-foreground)",lineHeight:"var(--leading-body)"}}>{description}</div>:null}
      {action?<div style={{marginTop:4}}>{action}</div>:null}
    </div>
    {onClose?<button type="button" onClick={onClose} aria-label="Fechar"
      style={{border:0,background:"transparent",cursor:"pointer",color:"var(--muted-foreground)",padding:2,display:"flex"}}>
      <Icon name="x" size={14}/></button>:null}
  </div>;
}
