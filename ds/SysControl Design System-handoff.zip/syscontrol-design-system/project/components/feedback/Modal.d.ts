import * as React from "react";
/** Centred dialog on a blurred 50% scrim. Footer actions are right-aligned on a `--content2` bar. */
export interface ModalProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"title"|"style"> {
  /** @default false */
  open?: boolean;
  /** Called by the scrim, the × and Escape-equivalent affordances. */
  onClose?: () => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  /** Right-aligned action row; usually a ghost cancel plus a primary confirm. */
  footer?: React.ReactNode;
  /** Max width 420 / 560 / 760 / 960px. @default "md" */
  size?: "sm" | "md" | "lg" | "xl";
  style?: React.CSSProperties;
}
export declare function Modal(props: ModalProps): JSX.Element;
