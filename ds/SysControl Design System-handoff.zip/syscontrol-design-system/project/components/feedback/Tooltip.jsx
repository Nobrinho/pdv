import React from "react";

export function Tooltip({content,placement="top",children,style,...rest}){
  const [open,setOpen]=React.useState(false);
  const pos={top:{bottom:"calc(100% + 6px)",left:"50%",transform:"translateX(-50%)"},
    bottom:{top:"calc(100% + 6px)",left:"50%",transform:"translateX(-50%)"},
    left:{right:"calc(100% + 6px)",top:"50%",transform:"translateY(-50%)"},
    right:{left:"calc(100% + 6px)",top:"50%",transform:"translateY(-50%)"}}[placement]||{};
  return <span style={{position:"relative",display:"inline-flex",...style}}
    onMouseEnter={()=>setOpen(true)} onMouseLeave={()=>setOpen(false)} {...rest}>
    {children}
    {open?<span role="tooltip" style={{position:"absolute",zIndex:70,whiteSpace:"nowrap",
      padding:"5px 9px",borderRadius:"var(--radius-sm)",background:"var(--tooltip)",color:"var(--tooltip-foreground)",
      fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",fontWeight:"var(--weight-medium)",
      boxShadow:"var(--shadow-medium)",pointerEvents:"none",...pos}}>{content}</span>:null}
  </span>;
}
