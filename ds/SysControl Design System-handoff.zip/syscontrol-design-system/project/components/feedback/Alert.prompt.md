Inline banner. Icon is chosen by tone — do not override it.

```jsx
<Alert tone="warning" title="12 peças abaixo do estoque mínimo"
  action={<Button variant="link" size="sm">Ver lista</Button>} />
```

Place at the top of the content column, above the page's cards, never floating.
