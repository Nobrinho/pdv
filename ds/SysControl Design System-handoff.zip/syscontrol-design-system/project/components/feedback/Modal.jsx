import React from "react";
import { Icon } from "../core/Icon.jsx";
const W={sm:420,md:560,lg:760,xl:960};
export function Modal({open=false,onClose,title,description,children,footer,size="md",style,...rest}){
  if(!open) return null;
  return <div role="dialog" aria-modal="true" onClick={onClose}
    style={{position:"fixed",inset:0,zIndex:60,display:"flex",alignItems:"center",justifyContent:"center",
      padding:24,background:"var(--overlay)",backdropFilter:"blur(2px)",
      animation:"sc-fade var(--duration-base) var(--ease-out)"}}>
    <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:W[size]||W.md,maxHeight:"88vh",
      display:"flex",flexDirection:"column",background:"var(--card)",color:"var(--card-foreground)",
      border:"1px solid var(--border)",borderRadius:"var(--radius-xl)",boxShadow:"var(--shadow-large)",
      overflow:"hidden",animation:"sc-pop var(--duration-base) var(--ease-out)",...style}} {...rest}>
      <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:16,
        padding:"18px 20px 14px",borderBottom:"1px solid var(--border)"}}>
        <div style={{display:"flex",flexDirection:"column",gap:2,minWidth:0}}>
          <div style={{fontFamily:"var(--font-display)",fontSize:"var(--text-large)",
            fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-heading)"}}>{title}</div>
          {description?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
            color:"var(--muted-foreground)"}}>{description}</div>:null}
        </div>
        <button type="button" onClick={onClose} aria-label="Fechar"
          style={{border:0,background:"transparent",cursor:"pointer",color:"var(--muted-foreground)",padding:4,display:"flex",borderRadius:"var(--radius-sm)"}}>
          <Icon name="x" size={18}/></button>
      </div>
      <div style={{padding:20,overflowY:"auto",flex:1}}>{children}</div>
      {footer?<div style={{display:"flex",alignItems:"center",justifyContent:"flex-end",gap:8,
        padding:"14px 20px",borderTop:"1px solid var(--border)",background:"var(--content2)"}}>{footer}</div>:null}
      <style>{"@keyframes sc-fade{from{opacity:0}to{opacity:1}}@keyframes sc-pop{from{opacity:0;transform:translateY(8px) scale(.985)}to{opacity:1;transform:none}}"}</style>
    </div>
  </div>;
}
