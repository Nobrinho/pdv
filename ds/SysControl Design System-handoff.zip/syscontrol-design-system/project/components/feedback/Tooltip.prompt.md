Hover label. Keep it to a short phrase — never a sentence with punctuation.

```jsx
<Tooltip content="Estoque em 3 filiais"><Icon name="info" size={14} /></Tooltip>
```
