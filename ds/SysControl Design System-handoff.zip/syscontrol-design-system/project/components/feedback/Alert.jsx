import React from "react";
import { Icon } from "../core/Icon.jsx";
const T={
  info:{bg:"var(--info-soft)",bd:"var(--info-soft-border)",fg:"var(--info-soft-foreground)",ic:"info",icon_c:"var(--info)"},
  success:{bg:"var(--success-soft)",bd:"var(--success-soft-border)",fg:"var(--success-soft-foreground)",ic:"circle-check",icon_c:"var(--success)"},
  warning:{bg:"var(--warning-soft)",bd:"var(--warning-soft-border)",fg:"var(--warning-soft-foreground)",ic:"triangle-alert",icon_c:"var(--warning-icon)"},
  danger:{bg:"var(--danger-soft)",bd:"var(--danger-soft-border)",fg:"var(--danger-soft-foreground)",ic:"circle-alert",icon_c:"var(--danger)"}
};
export function Alert({tone="info",title,children,action,onClose,style,...rest}){
  const t=T[tone]||T.info;
  return <div role="status" style={{display:"flex",alignItems:"flex-start",gap:12,boxSizing:"border-box",
    padding:"12px 14px",background:t.bg,border:"1px solid "+t.bd,borderRadius:"var(--radius-lg)",...style}} {...rest}>
    <span style={{display:"flex",marginTop:1,color:t.icon_c}}><Icon name={t.ic} size={17}/></span>
    <div style={{flex:1,minWidth:0,display:"flex",flexDirection:"column",gap:2}}>
      {title?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
        fontWeight:"var(--weight-semibold)",color:t.fg}}>{title}</div>:null}
      {children?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
        lineHeight:"var(--leading-body)",color:t.fg,opacity:0.9}}>{children}</div>:null}
      {action?<div style={{marginTop:6}}>{action}</div>:null}
    </div>
    {onClose?<button type="button" onClick={onClose} aria-label="Fechar"
      style={{border:0,background:"transparent",cursor:"pointer",color:t.fg,opacity:0.6,padding:2,display:"flex"}}>
      <Icon name="x" size={15}/></button>:null}
  </div>;
}
