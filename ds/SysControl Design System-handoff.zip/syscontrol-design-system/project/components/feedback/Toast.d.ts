import * as React from "react";
/** Transient confirmation card, stacked bottom-right at 24px from the viewport edges. */
export interface ToastProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"title"|"style"> {
  /** @default "success" */
  tone?: "info" | "success" | "warning" | "danger";
  title: React.ReactNode;
  description?: React.ReactNode;
  /** An "Desfazer" link Button, when the action is reversible. */
  action?: React.ReactNode;
  onClose?: () => void;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
