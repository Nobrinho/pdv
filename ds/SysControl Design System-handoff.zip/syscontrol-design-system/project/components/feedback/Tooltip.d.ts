import * as React from "react";
/** Dark 12px label on hover — for icon-only controls and truncated cells. */
export interface TooltipProps extends Omit<React.HTMLAttributes<HTMLSpanElement>,"content"|"style"> {
  content: React.ReactNode;
  /** @default "top" */
  placement?: "top" | "bottom" | "left" | "right";
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
