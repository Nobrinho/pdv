Confirms an action that already happened. Never asks a question.

```jsx
<Toast title="Venda #2041 finalizada" description="Recibo enviado por WhatsApp" onClose={dismiss} />
```

Stack bottom-right, 8px apart, auto-dismiss after 5s. Errors that need a decision use `Modal`, not Toast.
