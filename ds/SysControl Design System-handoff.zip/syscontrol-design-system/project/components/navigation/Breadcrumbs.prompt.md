Trail for detail pages that sit two or more levels deep.

```jsx
<Breadcrumbs items={["Estoque","Freios","Pastilha dianteira FR-2280"]} />
```

Two levels or fewer — use `Topbar breadcrumb` instead.
