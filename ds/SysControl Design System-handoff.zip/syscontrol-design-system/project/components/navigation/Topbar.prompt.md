Sits above the content column, beside the Sidebar.

```jsx
<Topbar breadcrumb="Operação / PDV" title="Ponto de venda"
  search={<Input icon="search" placeholder="Buscar peça, código ou cliente" size="sm" />}
  actions={<><TopbarStatus label="Caixa" value="Aberto · R$ 3.410" tone="success" />
            <IconButton icon="bell" label="Notificações" /><Avatar name="Marcos Ribeiro" size="sm" /></>} />
```
