import * as React from "react";
/** Ancestor trail above a detail page title. */
export interface BreadcrumbItem { label: string; href?: string }
export interface BreadcrumbsProps extends Omit<React.HTMLAttributes<HTMLElement>,"style"> {
  /** Plain strings or {label,href}; the last entry renders as the current page. */
  items?: Array<string | BreadcrumbItem>;
  onNavigate?: (item: string | BreadcrumbItem, index: number) => void;
  style?: React.CSSProperties;
}
export declare function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;
