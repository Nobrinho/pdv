import * as React from "react";
/**
 * The persistent left rail of the SysControl web app — deep teal, 248px, collapsible to 64px.
 * @startingPoint section="Navigation" subtitle="App sidebar with sections and active state" viewport="700x460"
 */
export interface SidebarItem {
  /** Unique id compared against `active`. */
  key?: string;
  label?: string;
  /** Lucide icon name. */
  icon?: string;
  /** Small count pill on the right. */
  badge?: string | number;
  /** When set, the entry renders as an uppercase section caption instead of a link. */
  section?: string;
}
export interface SidebarProps extends Omit<React.HTMLAttributes<HTMLElement>,"style"> {
  /** Wordmark next to the mark. @default "SysControl" */
  brand?: string;
  items?: SidebarItem[];
  /** `key` of the current item. */
  active?: string;
  onSelect?: (key: string) => void;
  /** Node pinned to the bottom — usually the account row. */
  footer?: React.ReactNode;
  /** Icon-only 64px rail. @default false */
  collapsed?: boolean;
  style?: React.CSSProperties;
}
export declare function Sidebar(props: SidebarProps): JSX.Element;
