Page-level: `underline` (teal 2px rule). In-card filter: `segmented` (grey track, white pill).

```jsx
<Tabs items={[{key:"todas",label:"Todas",count:148},{key:"baixo",label:"Estoque baixo",count:12}]} />
<Tabs variant="segmented" items={["Hoje","Semana","Mês"]} />
```
