Primary navigation for the desktop app. Deep-teal rail; the app canvas beside it is `--app-canvas`.

```jsx
<Sidebar active="estoque" onSelect={go} items={[
  {key:"painel",label:"Painel",icon:"layout-dashboard"},
  {section:"Operação"},
  {key:"pdv",label:"PDV",icon:"shopping-cart"},
  {key:"estoque",label:"Estoque",icon:"package",badge:12}
]} footer={<AccountRow/>} />
```

Sections are entries with only a `section` key. Badges are counts that need attention, not totals.
