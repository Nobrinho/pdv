import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Breadcrumbs({items=[],onNavigate,style,...rest}){
  return <nav aria-label="Trilha" style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap",
    fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",...style}} {...rest}>
    {items.map((it,i)=>{const last=i===items.length-1;const label=typeof it==="string"?it:it.label;
      return <React.Fragment key={i}>
        {last?<span style={{color:"var(--foreground)",fontWeight:"var(--weight-medium)"}}>{label}</span>
          :<button type="button" onClick={()=>onNavigate&&onNavigate(it,i)}
            style={{border:0,background:"transparent",padding:0,cursor:"pointer",color:"var(--muted-foreground)",
              fontFamily:"inherit",fontSize:"inherit"}}>{label}</button>}
        {last?null:<Icon name="chevron-right" size={13} color="var(--icon-muted)"/>}
      </React.Fragment>;})}
  </nav>;
}
