import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Sidebar({brand="SysControl",items=[],active,onSelect,footer,collapsed=false,style,...rest}){
  return <nav style={{display:"flex",flexDirection:"column",flexShrink:0,boxSizing:"border-box",
    width:collapsed?"var(--sidebar-w-collapsed)":"var(--sidebar-w)",height:"100%",
    background:"var(--sidebar)",color:"var(--sidebar-foreground)",
    borderRight:"1px solid var(--sidebar-border)",
    transition:"width var(--duration-slow) var(--ease-out)",overflow:"hidden",...style}} {...rest}>
    <div style={{display:"flex",alignItems:"center",gap:10,height:"var(--topbar-h)",flexShrink:0,
      padding:collapsed?"0 20px":"0 18px",borderBottom:"1px solid var(--sidebar-border)"}}>
      <span style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:24,height:24,
        flexShrink:0,borderRadius:"var(--radius-sm)",background:"var(--sidebar-mark)",color:"var(--sidebar-mark-foreground)"}}>
        <Icon name="wrench" size={14} strokeWidth={2.4}/></span>
      {!collapsed?<span style={{fontFamily:"var(--font-display)",fontSize:"var(--text-medium)",
        fontWeight:"var(--weight-bold)",letterSpacing:"var(--tracking-heading)",color:"var(--sidebar-brand)",whiteSpace:"nowrap"}}>{brand}</span>:null}
    </div>
    <div style={{flex:1,overflowY:"auto",padding:"12px 10px",display:"flex",flexDirection:"column",gap:2}}>
      {items.map((it,i)=>it.section
        ?<div key={"s"+i} style={{padding:collapsed?"14px 0 6px":"14px 10px 6px",fontFamily:"var(--font-sans)",
          fontSize:"var(--text-tiny)",fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-caps)",
          textTransform:"uppercase",color:"var(--sidebar-muted)",whiteSpace:"nowrap",opacity:collapsed?0:1}}>{it.section}</div>
        :<NavItem key={it.key} item={it} active={active===it.key} collapsed={collapsed} onSelect={onSelect}/>)}
    </div>
    {footer?<div style={{flexShrink:0,padding:12,borderTop:"1px solid var(--sidebar-border)"}}>{footer}</div>:null}
  </nav>;
}
function NavItem({item,active,collapsed,onSelect}){
  const [h,setH]=React.useState(false);
  return <button type="button" title={collapsed?item.label:undefined} onClick={()=>onSelect&&onSelect(item.key)}
    onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{display:"flex",alignItems:"center",gap:11,width:"100%",boxSizing:"border-box",height:38,
      padding:collapsed?"0 12px":"0 10px",border:0,borderRadius:"var(--radius-md)",cursor:"pointer",
      background:active?"var(--sidebar-active)":(h?"var(--sidebar-hover)":"transparent"),
      color:active?"var(--sidebar-active-foreground)":"var(--sidebar-foreground)",
      fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
      fontWeight:active?"var(--weight-semibold)":"var(--weight-medium)",textAlign:"left",
      transition:"var(--transition-colors)",whiteSpace:"nowrap"}}>
    <Icon name={item.icon} size={18} strokeWidth={active?2.2:1.9}/>
    {!collapsed?<span style={{flex:1,overflow:"hidden",textOverflow:"ellipsis"}}>{item.label}</span>:null}
    {!collapsed&&item.badge?<span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-tiny)",
      fontVariantNumeric:"tabular-nums",padding:"1px 6px",borderRadius:"var(--radius-full)",
      background:"var(--sidebar-badge)",color:"var(--sidebar-badge-foreground)",fontWeight:"var(--weight-semibold)"}}>{item.badge}</span>:null}
  </button>;
}
