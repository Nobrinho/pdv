import * as React from "react";
/** Switches views within a page — underline for page-level, segmented for in-card filters. */
export interface TabItem { key?: string; label?: string; icon?: string; count?: number }
export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>,"onChange"|"defaultValue"|"style"> {
  /** Plain strings or {key,label,icon,count}. */
  items?: Array<string | TabItem>;
  value?: string;
  defaultValue?: string;
  onChange?: (key: string) => void;
  /** @default "underline" */
  variant?: "underline" | "segmented";
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
