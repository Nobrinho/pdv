import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Topbar({title,breadcrumb,search,actions,children,style,...rest}){
  return <header style={{display:"flex",alignItems:"center",gap:16,flexShrink:0,boxSizing:"border-box",
    height:"var(--topbar-h)",padding:"0 24px",background:"var(--topbar)",
    borderBottom:"1px solid var(--topbar-border)",...style}} {...rest}>
    <div style={{display:"flex",flexDirection:"column",gap:0,flexShrink:0}}>
      {breadcrumb?<div style={{fontFamily:"var(--font-sans)",fontSize:"var(--text-tiny)",
        color:"var(--muted-foreground)",letterSpacing:"var(--tracking-label)",whiteSpace:"nowrap"}}>{breadcrumb}</div>:null}
      {title?<div style={{fontFamily:"var(--font-display)",fontSize:"var(--text-medium)",
        fontWeight:"var(--weight-semibold)",letterSpacing:"var(--tracking-heading)",color:"var(--foreground)",
        whiteSpace:"nowrap"}}>{title}</div>:null}
    </div>
    {search?<div style={{flex:"1 1 0",minWidth:0,maxWidth:420,marginLeft:8}}>{search}</div>:<div style={{flex:"1 1 0",minWidth:0}}/>}
    {children}
    {actions?<div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>{actions}</div>:null}
  </header>;
}
export function TopbarStatus({label,value,tone="neutral"}){
  const c={neutral:"var(--muted-foreground)",success:"var(--success)",warning:"var(--warning-icon)",danger:"var(--danger)"}[tone];
  return <div style={{display:"flex",alignItems:"center",gap:8,padding:"0 14px",borderLeft:"1px solid var(--border)",height:28}}>
    <span style={{width:7,height:7,borderRadius:"var(--radius-full)",background:c,flexShrink:0}}/>
    <div style={{display:"flex",flexDirection:"column",lineHeight:1.15}}>
      <span style={{fontFamily:"var(--font-sans)",fontSize:10,letterSpacing:"var(--tracking-caps)",
        textTransform:"uppercase",color:"var(--muted-foreground)"}}>{label}</span>
      <span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-small)",fontWeight:"var(--weight-semibold)",
        color:"var(--foreground)",fontVariantNumeric:"tabular-nums"}}>{value}</span>
    </div>
  </div>;
}
