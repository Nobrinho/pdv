import * as React from "react";
/** 56px app header — page title, global search and the account cluster. */
export interface TopbarProps extends Omit<React.HTMLAttributes<HTMLElement>,"title"|"style"> {
  title?: React.ReactNode;
  /** Tiny muted line above the title, e.g. "Estoque / Peças". */
  breadcrumb?: React.ReactNode;
  /** An `Input icon="search"` node; capped at 420px. */
  search?: React.ReactNode;
  /** Right-aligned cluster — IconButtons, Avatar, primary action. */
  actions?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
/** Small labelled readout for the topbar — open register, connection state, today's total. */
export interface TopbarStatusProps {
  label: React.ReactNode;
  value: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "success" | "warning" | "danger";
}
export declare function Topbar(props: TopbarProps): JSX.Element;
export declare function TopbarStatus(props: TopbarStatusProps): JSX.Element;
