import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Tabs({items=[],value,defaultValue,onChange,variant="underline",style,...rest}){
  const [inner,setInner]=React.useState(defaultValue??(items[0]&&(items[0].key||items[0])));
  const sel=value===undefined?inner:value;
  const pick=k=>{if(value===undefined)setInner(k);onChange&&onChange(k);};
  const seg=variant==="segmented";
  return <div role="tablist" style={{display:"inline-flex",alignItems:"center",
    gap:seg?2:4,padding:seg?3:0,borderRadius:seg?"var(--radius-md)":0,
    background:seg?"var(--content2)":"transparent",
    borderBottom:seg?"none":"1px solid var(--border)",...style}} {...rest}>
    {items.map(it=>{const k=it.key||it;const on=sel===k;
      return <button key={k} role="tab" aria-selected={on} onClick={()=>pick(k)}
        style={{display:"inline-flex",alignItems:"center",gap:6,border:0,cursor:"pointer",
          height:seg?30:36,padding:seg?"0 12px":"0 10px",
          background:seg?(on?"var(--background)":"transparent"):"transparent",
          borderRadius:seg?"var(--radius-sm)":0,
          boxShadow:seg&&on?"var(--shadow-xs)":"none",
          borderBottom:seg?"none":"2px solid "+(on?"var(--primary)":"transparent"),
          marginBottom:seg?0:-1,
          color:on?(seg?"var(--foreground)":"var(--primary)"):"var(--muted-foreground)",
          fontFamily:"var(--font-sans)",fontSize:"var(--text-body)",
          fontWeight:on?"var(--weight-semibold)":"var(--weight-medium)",whiteSpace:"nowrap",
          transition:"var(--transition-colors)"}}>
        {it.icon?<Icon name={it.icon} size={15}/>:null}
        {it.label||k}
        {it.count!=null?<span style={{fontFamily:"var(--font-mono)",fontSize:"var(--text-tiny)",
          fontVariantNumeric:"tabular-nums",padding:"1px 6px",borderRadius:"var(--radius-full)",
          background:on?"var(--primary-soft)":"var(--content2)",color:on?"var(--primary-soft-foreground)":"var(--muted-foreground)"}}>{it.count}</span>:null}
      </button>;})}
  </div>;
}
