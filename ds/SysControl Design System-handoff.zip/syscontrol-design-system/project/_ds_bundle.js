/* @ds-bundle: {"format":4,"namespace":"SysControlDesignSystem_02daf6","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"CardFooter","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Spinner","sourcePath":"components/core/Spinner.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"EmptyState","sourcePath":"components/data/EmptyState.jsx"},{"name":"Pagination","sourcePath":"components/data/Pagination.jsx"},{"name":"Progress","sourcePath":"components/data/Progress.jsx"},{"name":"Skeleton","sourcePath":"components/data/Skeleton.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/RadioGroup.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Topbar","sourcePath":"components/navigation/Topbar.jsx"},{"name":"TopbarStatus","sourcePath":"components/navigation/Topbar.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"29566c09f43d","components/core/Badge.jsx":"8015c077152f","components/core/Button.jsx":"61abd6697f1c","components/core/Card.jsx":"75f4014763d0","components/core/Chip.jsx":"cdc4506acd35","components/core/Divider.jsx":"98ce970d3726","components/core/Icon.jsx":"dbda8519a99a","components/core/IconButton.jsx":"eb5a121c7ad4","components/core/Spinner.jsx":"5724713fa153","components/data/DataTable.jsx":"fa6794dc7a4f","components/data/EmptyState.jsx":"4305c7d74840","components/data/Pagination.jsx":"9beb283bf644","components/data/Progress.jsx":"3430c883598d","components/data/Skeleton.jsx":"a5fd30fedec7","components/data/StatCard.jsx":"369271ef79ab","components/feedback/Alert.jsx":"c08f4591599d","components/feedback/Modal.jsx":"e0ab2e62e23a","components/feedback/Toast.jsx":"e01e354cc8a3","components/feedback/Tooltip.jsx":"31f6b180ed8f","components/forms/Checkbox.jsx":"39bb9fc6ca60","components/forms/Field.jsx":"3040ae4741b7","components/forms/Input.jsx":"cf3859bc7982","components/forms/RadioGroup.jsx":"552645ccef5a","components/forms/Select.jsx":"225be2eef0e2","components/forms/Switch.jsx":"b1ed5d76779f","components/forms/Textarea.jsx":"186504063629","components/navigation/Breadcrumbs.jsx":"7ee6c25fc90c","components/navigation/Sidebar.jsx":"1d0d737fbc84","components/navigation/Tabs.jsx":"d90dedd30f0d","components/navigation/Topbar.jsx":"ea3b635b31dc","ui_kits/mobile_app/Screens.jsx":"6bf4aa594d7a","ui_kits/web_app/Caixa.jsx":"1420dcab8776","ui_kits/web_app/Dashboard.jsx":"91f6c1a8d1a7","ui_kits/web_app/Estoque.jsx":"5db05f0b9ba3","ui_kits/web_app/Pdv.jsx":"34db29476f56","ui_kits/web_app/Vendas.jsx":"8edfa87d12ce","ui_kits/web_app/data.js":"167eb25b1f2f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SysControlDesignSystem_02daf6 = window.SysControlDesignSystem_02daf6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const S = {
  sm: 28,
  md: 36,
  lg: 44
};
function Avatar({
  name = "",
  src,
  size = "md",
  tone = "primary",
  style,
  ...rest
}) {
  const px = typeof size === "number" ? size : S[size] || S.md;
  const initials = name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  const tones = {
    primary: ["var(--avatar-primary)", "var(--avatar-primary-foreground)"],
    neutral: ["var(--avatar-neutral)", "var(--avatar-neutral-foreground)"],
    success: ["var(--avatar-success)", "var(--avatar-success-foreground)"]
  };
  const [bg, fg] = tones[tone] || tones.primary;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      width: px,
      height: px,
      borderRadius: "var(--radius-full)",
      overflow: "hidden",
      background: bg,
      color: fg,
      fontFamily: "var(--font-sans)",
      fontSize: Math.round(px * 0.36),
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-label)",
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  padding = 20,
  interactive = false,
  style,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: "flex",
      flexDirection: "column",
      boxSizing: "border-box",
      background: "var(--card)",
      color: "var(--card-foreground)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius-xl)",
      boxShadow: interactive && h ? "var(--shadow-sm)" : "var(--shadow-xs)",
      padding,
      transition: "box-shadow var(--duration-base) var(--ease-standard), background var(--duration-base) var(--ease-standard)",
      cursor: interactive ? "pointer" : "default",
      ...style
    }
  }, rest), children);
}
function CardHeader({
  title,
  description,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 16,
      marginBottom: 16,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-medium)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-heading)",
      color: "var(--card-foreground)",
      lineHeight: 1.3
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)",
      lineHeight: "var(--leading-body)"
    }
  }, description) : null), action ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexShrink: 0
    }
  }, action) : null);
}
function CardFooter({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: 16,
      paddingTop: 16,
      borderTop: "1px solid var(--border)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card, CardHeader, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Divider({
  orientation = "horizontal",
  label,
  style,
  ...rest
}) {
  if (label) return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--border)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--border)"
    }
  }));
  const v = orientation === "vertical";
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      display: "block",
      flexShrink: 0,
      width: v ? "var(--border-width)" : "100%",
      height: v ? "100%" : "var(--border-width)",
      background: "var(--border)",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function toPascal(n) {
  return String(n).split(/[-_\s]/).filter(Boolean).map(s => s[0].toUpperCase() + s.slice(1)).join("");
}
function nodes(spec) {
  if (!spec) return null;
  if (Array.isArray(spec) && spec[0] === "svg") return spec[2];
  return spec;
}
function Icon({
  name,
  size = 16,
  strokeWidth = 2,
  color = "currentColor",
  style,
  ...rest
}) {
  const [, tick] = React.useState(0);
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.lucide && window.lucide.icons) return;
    let n = 0;
    const id = setInterval(() => {
      n++;
      if (window.lucide && window.lucide.icons || n > 40) {
        clearInterval(id);
        tick(v => v + 1);
      }
    }, 100);
    return () => clearInterval(id);
  }, []);
  const lib = typeof window !== "undefined" && window.lucide && window.lucide.icons || null;
  const spec = lib ? lib[toPascal(name)] || lib[name] : null;
  const kids = nodes(spec);
  return /*#__PURE__*/React.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: "block",
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, rest), Array.isArray(kids) ? kids.map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })) : null);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE = {
  neutral: {
    bg: "var(--neutral-soft)",
    fg: "var(--neutral-soft-foreground)",
    bd: "var(--neutral-soft-border)"
  },
  primary: {
    bg: "var(--primary-soft)",
    fg: "var(--primary-soft-foreground)",
    bd: "var(--primary-soft-border)"
  },
  success: {
    bg: "var(--success-soft)",
    fg: "var(--success-soft-foreground)",
    bd: "var(--success-soft-border)"
  },
  warning: {
    bg: "var(--warning-soft)",
    fg: "var(--warning-soft-foreground)",
    bd: "var(--warning-soft-border)"
  },
  danger: {
    bg: "var(--danger-soft)",
    fg: "var(--danger-soft-foreground)",
    bd: "var(--danger-soft-border)"
  },
  info: {
    bg: "var(--info-soft)",
    fg: "var(--info-soft-foreground)",
    bd: "var(--info-soft-border)"
  },
  solid: {
    bg: "var(--primary)",
    fg: "var(--primary-foreground)",
    bd: "transparent"
  }
};
function Badge({
  children,
  tone = "neutral",
  icon,
  dot = false,
  style,
  ...rest
}) {
  const t = TONE[tone] || TONE.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      boxSizing: "border-box",
      height: 22,
      padding: "0 8px",
      borderRadius: "var(--radius-full)",
      background: t.bg,
      color: t.fg,
      border: "1px solid " + t.bd,
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-label)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "var(--radius-full)",
      background: "currentColor"
    }
  }) : null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 12
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    height: "var(--control-sm)",
    padding: "0 12px",
    fontSize: "var(--text-body)",
    gap: "6px",
    radius: "var(--radius-sm)",
    icon: 14
  },
  md: {
    height: "var(--control-md)",
    padding: "0 16px",
    fontSize: "var(--text-body)",
    gap: "8px",
    radius: "var(--radius-md)",
    icon: 16
  },
  lg: {
    height: "var(--control-lg)",
    padding: "0 24px",
    fontSize: "var(--text-medium)",
    gap: "8px",
    radius: "var(--radius-md)",
    icon: 18
  }
};
const VARIANTS = {
  primary: {
    background: "var(--primary)",
    color: "var(--primary-foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--primary-hover)"
    }
  },
  secondary: {
    background: "var(--secondary)",
    color: "var(--secondary-foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--secondary-hover)"
    }
  },
  outline: {
    background: "var(--background)",
    color: "var(--foreground)",
    border: "1px solid var(--border)",
    boxShadow: "var(--shadow-xs)",
    hover: {
      background: "var(--accent)"
    }
  },
  ghost: {
    background: "transparent",
    color: "var(--foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--accent)"
    }
  },
  flat: {
    background: "var(--primary-soft)",
    color: "var(--primary-soft-foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--primary-soft-hover)"
    }
  },
  destructive: {
    background: "var(--danger)",
    color: "var(--danger-foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--danger-hover)"
    }
  },
  success: {
    background: "var(--success)",
    color: "var(--success-foreground)",
    border: "1px solid transparent",
    hover: {
      background: "var(--success-hover)"
    }
  },
  link: {
    background: "transparent",
    color: "var(--primary)",
    border: "1px solid transparent",
    hover: {
      textDecoration: "underline"
    }
  }
};
function Button({
  children,
  variant = "primary",
  size = "md",
  icon,
  iconEnd,
  fullWidth = false,
  disabled = false,
  loading = false,
  type = "button",
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const css = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    boxSizing: "border-box",
    height: s.height,
    padding: s.padding,
    gap: s.gap,
    fontSize: s.fontSize,
    lineHeight: 1,
    fontFamily: "var(--font-sans)",
    fontWeight: "var(--weight-medium)",
    letterSpacing: "var(--tracking-label)",
    borderRadius: s.radius,
    whiteSpace: "nowrap",
    cursor: disabled || loading ? "not-allowed" : "pointer",
    width: fullWidth ? "100%" : "auto",
    outline: "none",
    appearance: "none",
    userSelect: "none",
    transition: "var(--transition-colors), var(--transition-transform)",
    transform: press && !disabled ? "scale(var(--press-scale))" : "scale(1)",
    opacity: disabled ? "var(--disabled-opacity)" : 1,
    ...v,
    ...(hover && !disabled && !loading ? v.hover : null),
    hover: undefined,
    ...style
  };
  delete css.hover;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled || loading,
    style: css,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false)
  }, rest), loading ? /*#__PURE__*/React.createElement(Spin, {
    size: s.icon
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }) : null, children, iconEnd ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconEnd,
    size: s.icon
  }) : null);
}
function Spin({
  size
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    style: {
      animation: "sc-spin 700ms linear infinite"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9",
    stroke: "currentColor",
    strokeOpacity: "0.25",
    strokeWidth: "3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M21 12a9 9 0 0 0-9-9",
    stroke: "currentColor",
    strokeWidth: "3",
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("style", null, "@keyframes sc-spin{to{transform:rotate(360deg)}}"));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Chip({
  children,
  selected = false,
  icon,
  onRemove,
  onClick,
  style,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      boxSizing: "border-box",
      height: 28,
      padding: onRemove ? "0 6px 0 10px" : "0 12px",
      borderRadius: "var(--radius-full)",
      background: selected ? "var(--primary)" : h && clickable ? "var(--accent)" : "var(--content2)",
      color: selected ? "var(--primary-foreground)" : "var(--foreground)",
      border: "1px solid " + (selected ? "transparent" : "var(--border)"),
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)",
      cursor: clickable ? "pointer" : "default",
      transition: "var(--transition-colors)",
      userSelect: "none",
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }) : null, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: "inline-flex",
      border: 0,
      background: "transparent",
      padding: 2,
      cursor: "pointer",
      color: "inherit",
      opacity: 0.7,
      borderRadius: "var(--radius-full)"
    },
    "aria-label": "Remover"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })) : null);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SZ = {
  sm: {
    box: 32,
    glyph: 16,
    r: "var(--radius-sm)"
  },
  md: {
    box: 36,
    glyph: 18,
    r: "var(--radius-md)"
  },
  lg: {
    box: 40,
    glyph: 20,
    r: "var(--radius-md)"
  }
};
const V = {
  ghost: {
    background: "transparent",
    color: "var(--muted-foreground)",
    border: "1px solid transparent",
    hoverBg: "var(--accent)",
    hoverFg: "var(--foreground)"
  },
  outline: {
    background: "var(--background)",
    color: "var(--foreground)",
    border: "1px solid var(--border)",
    hoverBg: "var(--accent)",
    hoverFg: "var(--foreground)"
  },
  primary: {
    background: "var(--primary)",
    color: "var(--primary-foreground)",
    border: "1px solid transparent",
    hoverBg: "var(--primary-hover)",
    hoverFg: "var(--primary-foreground)"
  },
  danger: {
    background: "transparent",
    color: "var(--danger)",
    border: "1px solid transparent",
    hoverBg: "var(--danger-soft)",
    hoverFg: "var(--danger)"
  }
};
function IconButton({
  icon,
  label,
  variant = "ghost",
  size = "md",
  disabled = false,
  round = false,
  style,
  onClick,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  const [p, setP] = React.useState(false);
  const s = SZ[size] || SZ.md;
  const v = V[variant] || V.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setP(false);
    },
    onMouseDown: () => setP(true),
    onMouseUp: () => setP(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      boxSizing: "border-box",
      width: s.box,
      height: s.box,
      padding: 0,
      borderRadius: round ? "var(--radius-full)" : s.r,
      background: h && !disabled ? v.hoverBg : v.background,
      color: h && !disabled ? v.hoverFg : v.color,
      border: v.border,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      outline: "none",
      transition: "var(--transition-colors), var(--transition-transform)",
      transform: p && !disabled ? "scale(var(--press-scale))" : "scale(1)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.glyph
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Spinner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Spinner({
  size = 20,
  label,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "status",
    "aria-label": label || "Carregando",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    style: {
      animation: "sc-spinner 700ms linear infinite",
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9",
    stroke: "var(--border)",
    strokeWidth: "2.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M21 12a9 9 0 0 0-9-9",
    stroke: "var(--primary)",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("style", null, "@keyframes sc-spinner{to{transform:rotate(360deg)}}"));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function DataTable({
  columns = [],
  rows = [],
  selectable = false,
  onRowClick,
  dense = false,
  emptyLabel = "Nenhum registro",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(-1);
  const pad = dense ? "8px 12px" : "12px 12px";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: "100%",
      overflowX: "auto",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, selectable ? /*#__PURE__*/React.createElement("th", {
    style: {
      width: 40,
      padding: pad,
      borderBottom: "1px solid var(--border)",
      background: "var(--content2)"
    }
  }) : null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      padding: pad,
      textAlign: c.align || "left",
      whiteSpace: "nowrap",
      width: c.width,
      background: "var(--content2)",
      borderBottom: "1px solid var(--border)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      justifyContent: c.align === "right" ? "flex-end" : "flex-start"
    }
  }, c.header, c.sortable ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevrons-up-down",
    size: 12
  }) : null))))), /*#__PURE__*/React.createElement("tbody", null, rows.length === 0 ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: columns.length + (selectable ? 1 : 0),
    style: {
      padding: "40px 12px",
      textAlign: "center",
      color: "var(--muted-foreground)"
    }
  }, emptyLabel)) : null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: r.id ?? i,
    onClick: () => onRowClick && onRowClick(r, i),
    onMouseEnter: () => setHover(i),
    onMouseLeave: () => setHover(-1),
    style: {
      background: hover === i ? "var(--hover-surface)" : "transparent",
      cursor: onRowClick ? "pointer" : "default",
      transition: "background var(--duration-fast) var(--ease-standard)"
    }
  }, selectable ? /*#__PURE__*/React.createElement("td", {
    style: {
      padding: pad,
      borderBottom: "1px solid var(--border)"
    }
  }, r.select) : null, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      padding: pad,
      textAlign: c.align || "left",
      borderBottom: "1px solid var(--border)",
      color: "var(--foreground)",
      verticalAlign: "middle",
      fontFamily: c.mono ? "var(--font-mono)" : "inherit",
      fontVariantNumeric: c.mono ? "tabular-nums" : "normal",
      whiteSpace: c.wrap ? "normal" : "nowrap"
    }
  }, c.render ? c.render(r, i) : r[c.key])))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function EmptyState({
  icon = "inbox",
  title,
  description,
  action,
  compact = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      gap: 8,
      padding: compact ? "32px 20px" : "56px 24px",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 48,
      height: 48,
      borderRadius: "var(--radius-full)",
      background: "var(--content2)",
      color: "var(--muted-foreground)",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-medium)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-heading)",
      color: "var(--foreground)"
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)",
      maxWidth: 380,
      lineHeight: "var(--leading-body)"
    }
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/data/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PageBtn({
  children,
  active,
  disabled,
  onClick,
  label
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      minWidth: 32,
      height: 32,
      padding: "0 8px",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--radius-sm)",
      border: "1px solid " + (active ? "var(--primary)" : "var(--border)"),
      background: active ? "var(--primary)" : h && !disabled ? "var(--accent)" : "var(--background)",
      color: active ? "var(--primary-foreground)" : "var(--foreground)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)",
      fontVariantNumeric: "tabular-nums",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      transition: "var(--transition-colors)"
    }
  }, children);
}
function Pagination({
  page = 1,
  pageCount = 1,
  onChange,
  total,
  pageSize,
  style,
  ...rest
}) {
  const go = p => {
    if (p >= 1 && p <= pageCount && p !== page && onChange) onChange(p);
  };
  const pages = [];
  const from = Math.max(1, Math.min(page - 2, pageCount - 4));
  for (let i = from; i <= Math.min(pageCount, from + 4); i++) pages.push(i);
  const first = total != null && pageSize ? (page - 1) * pageSize + 1 : null;
  const last = total != null && pageSize ? Math.min(total, page * pageSize) : null;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      flexWrap: "wrap",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, total != null ? pageSize ? `Mostrando ${first}–${last} de ${total}` : `${total} registros` : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(PageBtn, {
    label: "Anterior",
    disabled: page <= 1,
    onClick: () => go(page - 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 16
  })), pages.map(p => /*#__PURE__*/React.createElement(PageBtn, {
    key: p,
    active: p === page,
    onClick: () => go(p)
  }, p)), /*#__PURE__*/React.createElement(PageBtn, {
    label: "Pr\xF3xima",
    disabled: page >= pageCount,
    onClick: () => go(page + 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 16
  }))));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/data/Progress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  primary: "var(--primary)",
  success: "var(--success)",
  warning: "var(--warning)",
  danger: "var(--danger)"
};
function Progress({
  value = 0,
  max = 100,
  tone = "primary",
  label,
  showValue = false,
  size = "md",
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const h = size === "sm" ? 4 : size === "lg" ? 10 : 6;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      width: "100%",
      ...style
    }
  }, rest), label || showValue ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--foreground)"
    }
  }, label), showValue ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted-foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, Math.round(pct), "%") : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      height: h,
      borderRadius: "var(--radius-full)",
      background: "var(--content3)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: pct + "%",
      height: "100%",
      borderRadius: "var(--radius-full)",
      background: TONES[tone] || TONES.primary,
      transition: "width var(--duration-slow) var(--ease-out)"
    }
  })));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Progress.jsx", error: String((e && e.message) || e) }); }

// components/data/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Skeleton({
  width = "100%",
  height = 14,
  radius = "var(--radius-sm)",
  circle = false,
  style,
  ...rest
}) {
  const d = circle ? typeof height === "number" ? height : 20 : null;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "block",
      width: circle ? d : width,
      height: circle ? d : height,
      borderRadius: circle ? "var(--radius-full)" : radius,
      background: "var(--content2)",
      backgroundImage: "linear-gradient(90deg,var(--skeleton-from) 0%,var(--skeleton-to) 50%,var(--skeleton-from) 100%)",
      backgroundSize: "200% 100%",
      animation: "sc-shimmer 1.4s ease infinite",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("style", null, "@keyframes sc-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}"));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatCard({
  label,
  value,
  unit,
  delta,
  deltaLabel,
  icon,
  tone = "neutral",
  style,
  ...rest
}) {
  const up = typeof delta === "number" && delta > 0;
  const down = typeof delta === "number" && delta < 0;
  const accents = {
    neutral: "var(--neutral-soft)",
    primary: "var(--primary-soft)",
    success: "var(--success-soft)",
    warning: "var(--warning-soft)",
    danger: "var(--danger-soft)"
  };
  const glyph = {
    neutral: "var(--muted-foreground)",
    primary: "var(--primary)",
    success: "var(--success)",
    warning: "var(--warning-icon)",
    danger: "var(--danger)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      boxSizing: "border-box",
      padding: 20,
      background: "var(--card)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-xs)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, label), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 32,
      height: 32,
      borderRadius: "var(--radius-md)",
      background: accents[tone] || accents.neutral,
      color: glyph[tone] || glyph.neutral
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  })) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h2)",
      lineHeight: 1,
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, value), unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)"
    }
  }, unit) : null), delta !== undefined && delta !== null || deltaLabel ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)"
    }
  }, typeof delta === "number" ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      color: up ? "var(--money-positive)" : down ? "var(--money-negative)" : "var(--muted-foreground)",
      fontWeight: "var(--weight-semibold)",
      fontVariantNumeric: "tabular-nums"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: up ? "trending-up" : down ? "trending-down" : "minus",
    size: 14
  }), (up ? "+" : "") + delta.toLocaleString("pt-BR", {
    maximumFractionDigits: 1
  }) + "%") : null, deltaLabel ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted-foreground)"
    }
  }, deltaLabel) : null) : null);
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const T = {
  info: {
    bg: "var(--info-soft)",
    bd: "var(--info-soft-border)",
    fg: "var(--info-soft-foreground)",
    ic: "info",
    icon_c: "var(--info)"
  },
  success: {
    bg: "var(--success-soft)",
    bd: "var(--success-soft-border)",
    fg: "var(--success-soft-foreground)",
    ic: "circle-check",
    icon_c: "var(--success)"
  },
  warning: {
    bg: "var(--warning-soft)",
    bd: "var(--warning-soft-border)",
    fg: "var(--warning-soft-foreground)",
    ic: "triangle-alert",
    icon_c: "var(--warning-icon)"
  },
  danger: {
    bg: "var(--danger-soft)",
    bd: "var(--danger-soft-border)",
    fg: "var(--danger-soft-foreground)",
    ic: "circle-alert",
    icon_c: "var(--danger)"
  }
};
function Alert({
  tone = "info",
  title,
  children,
  action,
  onClose,
  style,
  ...rest
}) {
  const t = T[tone] || T.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      boxSizing: "border-box",
      padding: "12px 14px",
      background: t.bg,
      border: "1px solid " + t.bd,
      borderRadius: "var(--radius-lg)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      marginTop: 1,
      color: t.icon_c
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.ic,
    size: 17
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)",
      color: t.fg
    }
  }, title) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      lineHeight: "var(--leading-body)",
      color: t.fg,
      opacity: 0.9
    }
  }, children) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, action) : null), onClose ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Fechar",
    style: {
      border: 0,
      background: "transparent",
      cursor: "pointer",
      color: t.fg,
      opacity: 0.6,
      padding: 2,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 15
  })) : null);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const W = {
  sm: 420,
  md: 560,
  lg: 760,
  xl: 960
};
function Modal({
  open = false,
  onClose,
  title,
  description,
  children,
  footer,
  size = "md",
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 60,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      background: "var(--overlay)",
      backdropFilter: "blur(2px)",
      animation: "sc-fade var(--duration-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    onClick: e => e.stopPropagation(),
    style: {
      width: "100%",
      maxWidth: W[size] || W.md,
      maxHeight: "88vh",
      display: "flex",
      flexDirection: "column",
      background: "var(--card)",
      color: "var(--card-foreground)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-large)",
      overflow: "hidden",
      animation: "sc-pop var(--duration-base) var(--ease-out)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 16,
      padding: "18px 20px 14px",
      borderBottom: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-large)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-heading)"
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)"
    }
  }, description) : null), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Fechar",
    style: {
      border: 0,
      background: "transparent",
      cursor: "pointer",
      color: "var(--muted-foreground)",
      padding: 4,
      display: "flex",
      borderRadius: "var(--radius-sm)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      overflowY: "auto",
      flex: 1
    }
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: 8,
      padding: "14px 20px",
      borderTop: "1px solid var(--border)",
      background: "var(--content2)"
    }
  }, footer) : null, /*#__PURE__*/React.createElement("style", null, "@keyframes sc-fade{from{opacity:0}to{opacity:1}}@keyframes sc-pop{from{opacity:0;transform:translateY(8px) scale(.985)}to{opacity:1;transform:none}}")));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const T = {
  info: {
    ic: "info",
    c: "var(--info)"
  },
  success: {
    ic: "circle-check",
    c: "var(--success)"
  },
  warning: {
    ic: "triangle-alert",
    c: "var(--warning-icon)"
  },
  danger: {
    ic: "circle-alert",
    c: "var(--danger)"
  }
};
function Toast({
  tone = "success",
  title,
  description,
  onClose,
  action,
  style,
  ...rest
}) {
  const t = T[tone] || T.success;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 10,
      boxSizing: "border-box",
      minWidth: 280,
      maxWidth: 400,
      padding: "12px 14px",
      background: "var(--card)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-medium)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      marginTop: 1,
      color: t.c
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.ic,
    size: 17
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--foreground)"
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)",
      lineHeight: "var(--leading-body)"
    }
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, action) : null), onClose ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Fechar",
    style: {
      border: 0,
      background: "transparent",
      cursor: "pointer",
      color: "var(--muted-foreground)",
      padding: 2,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14
  })) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  content,
  placement = "top",
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[placement] || {};
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false)
  }, rest), children, open ? /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      zIndex: 70,
      whiteSpace: "nowrap",
      padding: "5px 9px",
      borderRadius: "var(--radius-sm)",
      background: "var(--tooltip)",
      color: "var(--tooltip-foreground)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-medium)",
      boxShadow: "var(--shadow-medium)",
      pointerEvents: "none",
      ...pos
    }
  }, content) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked,
  defaultChecked,
  onChange,
  label,
  description,
  disabled = false,
  indeterminate = false,
  style,
  ...rest
}) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked === undefined ? inner : checked;
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInner(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: description ? "flex-start" : "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: toggle,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      width: 18,
      height: 18,
      marginTop: description ? 2 : 0,
      borderRadius: "var(--radius-xs)",
      background: on || indeterminate ? "var(--primary)" : "var(--background)",
      border: "1px solid " + (on || indeterminate ? "var(--primary)" : "var(--input)"),
      boxShadow: on || indeterminate ? "none" : "var(--shadow-xs)",
      color: "var(--primary-foreground)",
      transition: "var(--transition-colors)"
    }
  }, indeterminate ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "minus",
    size: 12,
    strokeWidth: 3
  }) : on ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 12,
    strokeWidth: 3
  }) : null), label || description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--foreground)"
    }
  }, label) : null, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)"
    }
  }, description) : null) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Field({
  label,
  hint,
  error,
  required = false,
  htmlFor,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: htmlFor,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)",
      color: "var(--foreground)",
      letterSpacing: "var(--tracking-label)"
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)",
      marginLeft: 3
    }
  }, "*") : null) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--danger)"
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const H = {
  sm: "var(--control-sm)",
  md: "var(--control-md)",
  lg: "var(--control-lg)"
};
function Input({
  value,
  defaultValue,
  onChange,
  placeholder,
  type = "text",
  icon,
  suffix,
  size = "md",
  invalid = false,
  disabled = false,
  readOnly = false,
  mono = false,
  fullWidth = true,
  style,
  inputStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      boxSizing: "border-box",
      width: fullWidth ? "100%" : "auto",
      height: H[size] || H.md,
      background: disabled ? "var(--muted)" : "var(--background)",
      border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--ring)" : "var(--input)"),
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? invalid ? "0 0 0 var(--ring-width) var(--ring-shadow-danger)" : "0 0 0 var(--ring-width) var(--ring-shadow)" : "var(--shadow-xs)",
      transition: "border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      paddingLeft: icon ? 10 : 12,
      paddingRight: suffix ? 10 : 12,
      gap: 8,
      ...style
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: "var(--muted-foreground)"
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    readOnly: readOnly,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: "none",
      background: "transparent",
      padding: 0,
      fontFamily: mono ? "var(--font-mono)" : "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontVariantNumeric: mono ? "tabular-nums" : "normal",
      color: "var(--foreground)",
      height: "100%"
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)",
      whiteSpace: "nowrap"
    }
  }, suffix) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function RadioGroup({
  options = [],
  value,
  defaultValue,
  onChange,
  name,
  orientation = "vertical",
  disabled = false,
  style,
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const sel = value === undefined ? inner : value;
  const pick = v => {
    if (disabled) return;
    if (value === undefined) setInner(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "radiogroup",
    style: {
      display: "flex",
      flexDirection: orientation === "horizontal" ? "row" : "column",
      gap: orientation === "horizontal" ? 20 : 10,
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      ...style
    }
  }, rest), options.map(o => {
    const v = typeof o === "string" ? o : o.value;
    const l = typeof o === "string" ? o : o.label;
    const d = typeof o === "string" ? null : o.description;
    const on = sel === v;
    return /*#__PURE__*/React.createElement("label", {
      key: v,
      onClick: () => pick(v),
      style: {
        display: "inline-flex",
        alignItems: d ? "flex-start" : "center",
        gap: 10,
        cursor: disabled ? "not-allowed" : "pointer"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        width: 18,
        height: 18,
        marginTop: d ? 2 : 0,
        borderRadius: "var(--radius-full)",
        background: "var(--background)",
        border: "1px solid " + (on ? "var(--primary)" : "var(--input)"),
        boxShadow: "var(--shadow-xs)",
        transition: "var(--transition-colors)"
      }
    }, on ? /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: "var(--radius-full)",
        background: "var(--primary)"
      }
    }) : null), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-body)",
        color: "var(--foreground)"
      }
    }, l), d ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-small)",
        color: "var(--muted-foreground)"
      }
    }, d) : null));
  }));
}
Object.assign(__ds_scope, { RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const H = {
  sm: "var(--control-sm)",
  md: "var(--control-md)",
  lg: "var(--control-lg)"
};
function Select({
  options = [],
  value,
  defaultValue,
  onChange,
  placeholder,
  size = "md",
  invalid = false,
  disabled = false,
  fullWidth = true,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      boxSizing: "border-box",
      width: fullWidth ? "100%" : "auto",
      height: H[size] || H.md,
      background: disabled ? "var(--muted)" : "var(--background)",
      border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--ring)" : "var(--input)"),
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "0 0 0 var(--ring-width) var(--ring-shadow)" : "var(--shadow-xs)",
      transition: "border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: "100%",
      height: "100%",
      border: 0,
      outline: "none",
      background: "transparent",
      padding: "0 32px 0 12px",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: value === "" && placeholder ? "var(--muted-foreground)" : "var(--foreground)",
      cursor: disabled ? "not-allowed" : "pointer"
    }
  }, rest), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const v = typeof o === "string" ? o : o.value;
    const l = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 10,
      pointerEvents: "none",
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--muted-foreground)"
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked,
  defaultChecked,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked === undefined ? inner : checked;
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInner(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": on,
    onClick: toggle,
    style: {
      position: "relative",
      display: "inline-block",
      width: 40,
      height: 22,
      flexShrink: 0,
      borderRadius: "var(--radius-full)",
      background: on ? "var(--primary)" : "var(--switch-track)",
      transition: "background var(--duration-slow) var(--ease-standard)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: on ? 20 : 2,
      width: 18,
      height: 18,
      borderRadius: "var(--radius-full)",
      background: "var(--switch-thumb)",
      boxShadow: "var(--shadow-sm)",
      transition: "left var(--duration-base) var(--ease-out)"
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      color: "var(--foreground)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  rows = 4,
  invalid = false,
  disabled = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      boxSizing: "border-box",
      padding: "10px 12px",
      resize: "vertical",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      lineHeight: "var(--leading-body)",
      color: "var(--foreground)",
      background: disabled ? "var(--muted)" : "var(--background)",
      border: "1px solid " + (invalid ? "var(--danger)" : focus ? "var(--ring)" : "var(--input)"),
      borderRadius: "var(--radius-md)",
      outline: "none",
      boxShadow: focus ? "0 0 0 var(--ring-width) var(--ring-shadow)" : "var(--shadow-xs)",
      transition: "border-color var(--duration-base) var(--ease-standard), box-shadow var(--duration-base) var(--ease-standard)",
      opacity: disabled ? "var(--disabled-opacity)" : 1,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumbs({
  items = [],
  onNavigate,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Trilha",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flexWrap: "wrap",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      ...style
    }
  }, rest), items.map((it, i) => {
    const last = i === items.length - 1;
    const label = typeof it === "string" ? it : it.label;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, last ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--foreground)",
        fontWeight: "var(--weight-medium)"
      }
    }, label) : /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => onNavigate && onNavigate(it, i),
      style: {
        border: 0,
        background: "transparent",
        padding: 0,
        cursor: "pointer",
        color: "var(--muted-foreground)",
        fontFamily: "inherit",
        fontSize: "inherit"
      }
    }, label), last ? null : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: 13,
      color: "var(--icon-muted)"
    }));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Sidebar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Sidebar({
  brand = "SysControl",
  items = [],
  active,
  onSelect,
  footer,
  collapsed = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      flexShrink: 0,
      boxSizing: "border-box",
      width: collapsed ? "var(--sidebar-w-collapsed)" : "var(--sidebar-w)",
      height: "100%",
      background: "var(--sidebar)",
      color: "var(--sidebar-foreground)",
      borderRight: "1px solid var(--sidebar-border)",
      transition: "width var(--duration-slow) var(--ease-out)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      height: "var(--topbar-h)",
      flexShrink: 0,
      padding: collapsed ? "0 20px" : "0 18px",
      borderBottom: "1px solid var(--sidebar-border)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 24,
      height: 24,
      flexShrink: 0,
      borderRadius: "var(--radius-sm)",
      background: "var(--sidebar-mark)",
      color: "var(--sidebar-mark-foreground)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "wrench",
    size: 14,
    strokeWidth: 2.4
  })), !collapsed ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-medium)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-heading)",
      color: "var(--sidebar-brand)",
      whiteSpace: "nowrap"
    }
  }, brand) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "12px 10px",
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, items.map((it, i) => it.section ? /*#__PURE__*/React.createElement("div", {
    key: "s" + i,
    style: {
      padding: collapsed ? "14px 0 6px" : "14px 10px 6px",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--sidebar-muted)",
      whiteSpace: "nowrap",
      opacity: collapsed ? 0 : 1
    }
  }, it.section) : /*#__PURE__*/React.createElement(NavItem, {
    key: it.key,
    item: it,
    active: active === it.key,
    collapsed: collapsed,
    onSelect: onSelect
  }))), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      padding: 12,
      borderTop: "1px solid var(--sidebar-border)"
    }
  }, footer) : null);
}
function NavItem({
  item,
  active,
  collapsed,
  onSelect
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    title: collapsed ? item.label : undefined,
    onClick: () => onSelect && onSelect(item.key),
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      width: "100%",
      boxSizing: "border-box",
      height: 38,
      padding: collapsed ? "0 12px" : "0 10px",
      border: 0,
      borderRadius: "var(--radius-md)",
      cursor: "pointer",
      background: active ? "var(--sidebar-active)" : h ? "var(--sidebar-hover)" : "transparent",
      color: active ? "var(--sidebar-active-foreground)" : "var(--sidebar-foreground)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-body)",
      fontWeight: active ? "var(--weight-semibold)" : "var(--weight-medium)",
      textAlign: "left",
      transition: "var(--transition-colors)",
      whiteSpace: "nowrap"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: item.icon,
    size: 18,
    strokeWidth: active ? 2.2 : 1.9
  }), !collapsed ? /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, item.label) : null, !collapsed && item.badge ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-tiny)",
      fontVariantNumeric: "tabular-nums",
      padding: "1px 6px",
      borderRadius: "var(--radius-full)",
      background: "var(--sidebar-badge)",
      color: "var(--sidebar-badge-foreground)",
      fontWeight: "var(--weight-semibold)"
    }
  }, item.badge) : null);
}
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Sidebar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  variant = "underline",
  style,
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (items[0] && (items[0].key || items[0])));
  const sel = value === undefined ? inner : value;
  const pick = k => {
    if (value === undefined) setInner(k);
    onChange && onChange(k);
  };
  const seg = variant === "segmented";
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: seg ? 2 : 4,
      padding: seg ? 3 : 0,
      borderRadius: seg ? "var(--radius-md)" : 0,
      background: seg ? "var(--content2)" : "transparent",
      borderBottom: seg ? "none" : "1px solid var(--border)",
      ...style
    }
  }, rest), items.map(it => {
    const k = it.key || it;
    const on = sel === k;
    return /*#__PURE__*/React.createElement("button", {
      key: k,
      role: "tab",
      "aria-selected": on,
      onClick: () => pick(k),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        border: 0,
        cursor: "pointer",
        height: seg ? 30 : 36,
        padding: seg ? "0 12px" : "0 10px",
        background: seg ? on ? "var(--background)" : "transparent" : "transparent",
        borderRadius: seg ? "var(--radius-sm)" : 0,
        boxShadow: seg && on ? "var(--shadow-xs)" : "none",
        borderBottom: seg ? "none" : "2px solid " + (on ? "var(--primary)" : "transparent"),
        marginBottom: seg ? 0 : -1,
        color: on ? seg ? "var(--foreground)" : "var(--primary)" : "var(--muted-foreground)",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-body)",
        fontWeight: on ? "var(--weight-semibold)" : "var(--weight-medium)",
        whiteSpace: "nowrap",
        transition: "var(--transition-colors)"
      }
    }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 15
    }) : null, it.label || k, it.count != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-tiny)",
        fontVariantNumeric: "tabular-nums",
        padding: "1px 6px",
        borderRadius: "var(--radius-full)",
        background: on ? "var(--primary-soft)" : "var(--content2)",
        color: on ? "var(--primary-soft-foreground)" : "var(--muted-foreground)"
      }
    }, it.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Topbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Topbar({
  title,
  breadcrumb,
  search,
  actions,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      flexShrink: 0,
      boxSizing: "border-box",
      height: "var(--topbar-h)",
      padding: "0 24px",
      background: "var(--topbar)",
      borderBottom: "1px solid var(--topbar-border)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 0,
      flexShrink: 0
    }
  }, breadcrumb ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      color: "var(--muted-foreground)",
      letterSpacing: "var(--tracking-label)",
      whiteSpace: "nowrap"
    }
  }, breadcrumb) : null, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-medium)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-heading)",
      color: "var(--foreground)",
      whiteSpace: "nowrap"
    }
  }, title) : null), search ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 0",
      minWidth: 0,
      maxWidth: 420,
      marginLeft: 8
    }
  }, search) : /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 0",
      minWidth: 0
    }
  }), children, actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexShrink: 0
    }
  }, actions) : null);
}
function TopbarStatus({
  label,
  value,
  tone = "neutral"
}) {
  const c = {
    neutral: "var(--muted-foreground)",
    success: "var(--success)",
    warning: "var(--warning-icon)",
    danger: "var(--danger)"
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "0 14px",
      borderLeft: "1px solid var(--border)",
      height: 28
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "var(--radius-full)",
      background: c,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      lineHeight: 1.15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 10,
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-small)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, value)));
}
Object.assign(__ds_scope, { Topbar, TopbarStatus });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Topbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Screens.jsx
try { (() => {
const {
  Card,
  Badge,
  Button,
  IconButton,
  Input,
  Icon,
  Avatar,
  Divider,
  Progress,
  EmptyState,
  Chip,
  StatCard,
  Tabs
} = window.SysControlDesignSystem_02daf6;

/* ---------- chrome ---------- */
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      height: 44,
      padding: "0 22px",
      flexShrink: 0,
      background: "var(--sidebar)",
      color: "var(--sidebar-brand)",
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      fontWeight: 600,
      letterSpacing: "0.01em"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: "tabular-nums"
    }
  }, "14:32"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5,
      opacity: .9
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "signal",
    size: 14
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 14
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery-full",
    size: 16
  })));
}
function AppBar({
  title,
  subtitle,
  left,
  right,
  tone = "teal"
}) {
  const dark = tone === "teal";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      height: 56,
      padding: "0 16px",
      flexShrink: 0,
      background: dark ? "var(--sidebar)" : "var(--background)",
      borderBottom: dark ? "none" : "1px solid var(--border)"
    }
  }, left, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 17,
      fontWeight: 600,
      letterSpacing: "var(--tracking-heading)",
      color: dark ? "var(--sidebar-brand)" : "var(--foreground)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: dark ? "var(--sidebar-muted)" : "var(--muted-foreground)"
    }
  }, subtitle) : null), right);
}
function TabBar({
  active,
  onChange
}) {
  const tabs = [["painel", "Painel", "layout-dashboard"], ["pdv", "Vender", "shopping-cart"], ["estoque", "Estoque", "package"], ["caixa", "Caixa", "banknote"], ["mais", "Mais", "menu"]];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexShrink: 0,
      background: "var(--background)",
      borderTop: "1px solid var(--border)",
      padding: "6px 4px 22px"
    }
  }, tabs.map(([k, l, ic]) => {
    const on = active === k;
    return /*#__PURE__*/React.createElement("button", {
      key: k,
      onClick: () => onChange(k),
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 3,
        minHeight: 48,
        border: 0,
        background: "transparent",
        cursor: "pointer",
        color: on ? "var(--primary)" : "var(--muted-foreground)",
        fontFamily: "var(--font-sans)",
        fontSize: 11,
        fontWeight: on ? 600 : 500,
        transition: "var(--transition-colors)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: ic,
      size: 21,
      strokeWidth: on ? 2.2 : 1.8
    }), l);
  }));
}
function Sheet({
  open,
  onClose,
  title,
  children,
  footer
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 40,
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      background: "var(--overlay)",
      animation: "m-fade 150ms ease"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--card)",
      borderRadius: "var(--radius-2xl) var(--radius-2xl) 0 0",
      padding: "10px 16px 24px",
      boxShadow: "var(--shadow-large)",
      animation: "m-up 200ms cubic-bezier(0.16,1,0.3,1)",
      maxHeight: "82%",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 38,
      height: 4,
      borderRadius: 99,
      background: "var(--content3)",
      margin: "0 auto 14px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: "var(--tracking-heading)",
      marginBottom: 14
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: "auto",
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 16,
      display: "flex",
      gap: 8
    }
  }, footer) : null, /*#__PURE__*/React.createElement("style", null, "@keyframes m-fade{from{opacity:0}to{opacity:1}}@keyframes m-up{from{transform:translateY(100%)}to{transform:none}}")));
}

/* ---------- screens ---------- */
function MPainel({
  go
}) {
  const D = window.SC_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      background: "var(--app-canvas)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--sidebar)",
      padding: "4px 16px 26px",
      color: "var(--sidebar-brand)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--sidebar-muted)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Faturamento hoje"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 38,
      fontWeight: 600,
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums",
      marginTop: 4
    }
  }, window.SC_BRL(14280.5)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginTop: 6,
      fontSize: 13,
      color: "var(--primary-soft-foreground)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trending-up",
    size: 15
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "+12,4%"), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .75
    }
  }, "vs. ontem"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 14,
      marginTop: -14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Vendas",
    value: "63",
    unit: "pedidos",
    icon: "receipt",
    padding: 16
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Cr\xEDtico",
    value: "3",
    unit: "itens",
    icon: "triangle-alert",
    tone: "warning"
  })), /*#__PURE__*/React.createElement(Card, {
    padding: 16
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 15,
      fontWeight: 600,
      letterSpacing: "var(--tracking-heading)"
    }
  }, "Reposi\xE7\xE3o urgente"), /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    size: "sm",
    onClick: () => go("estoque")
  }, "Ver tudo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, D.pecas.filter(p => p.qtd < p.min).map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 8,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, p.nome), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--muted-foreground)",
      whiteSpace: "nowrap"
    }
  }, p.qtd, "/", p.min)), /*#__PURE__*/React.createElement(Progress, {
    value: p.qtd,
    max: p.min,
    size: "sm",
    tone: p.qtd === 0 ? "danger" : "warning"
  }))))), /*#__PURE__*/React.createElement(Card, {
    padding: 16
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 15,
      fontWeight: 600,
      letterSpacing: "var(--tracking-heading)"
    }
  }, "\xDAltimas vendas"), /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    size: "sm"
  }, "Ver todas")), D.vendas.slice(0, 4).map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: v.id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "12px 0",
      borderTop: i ? "1px solid var(--border)" : "none"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: v.cliente,
    size: 36,
    tone: v.t === "danger" ? "neutral" : "primary"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, v.cliente), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, "#", v.id, " \xB7 ", v.hora, " \xB7 ", v.pag)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      fontWeight: 600,
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(v.total)), /*#__PURE__*/React.createElement(Badge, {
    tone: v.t,
    dot: true,
    style: {
      marginTop: 3
    }
  }, v.st)))))));
}
function MPdv() {
  const D = window.SC_DATA;
  const [cart, setCart] = React.useState([{
    ...D.pecas[0],
    qty: 2
  }, {
    ...D.pecas[4],
    qty: 4
  }]);
  const [sheet, setSheet] = React.useState(null);
  const [q, setQ] = React.useState("");
  const list = D.pecas.filter(p => p.nome.toLowerCase().includes(q.toLowerCase()) || p.sku.toLowerCase().includes(q.toLowerCase()));
  const total = cart.reduce((s, x) => s + x.preco * x.qty, 0);
  const add = p => setCart(c => {
    const i = c.findIndex(x => x.id === p.id);
    if (i > -1) {
      const n = [...c];
      n[i] = {
        ...n[i],
        qty: n[i].qty + 1
      };
      return n;
    }
    return [...c, {
      ...p,
      qty: 1
    }];
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      background: "var(--app-canvas)",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 16px",
      display: "flex",
      gap: 8,
      background: "var(--background)",
      borderBottom: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar pe\xE7a ou c\xF3digo"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "barcode",
    label: "Ler c\xF3digo de barras",
    variant: "primary",
    size: "lg"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "12px 16px",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, list.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "search-x",
    title: "Nada encontrado",
    description: "Verifique o c\xF3digo digitado."
  }) : null, list.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.id,
    padding: 14,
    interactive: true,
    onClick: () => add(p),
    style: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 42,
      height: 42,
      flexShrink: 0,
      borderRadius: "var(--radius-md)",
      background: "var(--content2)",
      color: "var(--muted-foreground)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "package",
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      lineHeight: 1.3
    }
  }, p.nome), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--muted-foreground)",
      marginTop: 2
    }
  }, p.sku, " \xB7 ", p.qtd, " un.")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      fontWeight: 600,
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(p.preco)), /*#__PURE__*/React.createElement(Badge, {
    tone: p.t,
    style: {
      marginTop: 4
    }
  }, p.st))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      padding: "12px 16px",
      background: "var(--background)",
      borderTop: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      gap: 12,
      boxShadow: "var(--shadow-medium)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, cart.reduce((s, x) => s + x.qty, 0), " itens no carrinho"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      fontWeight: 600,
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(total))), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    icon: "shopping-cart",
    onClick: () => setSheet("cart"),
    disabled: !cart.length
  }, "Ver carrinho")), /*#__PURE__*/React.createElement(Sheet, {
    open: sheet === "cart",
    onClose: () => setSheet(null),
    title: "Carrinho",
    footer: /*#__PURE__*/React.createElement(Button, {
      variant: "success",
      size: "lg",
      icon: "check",
      fullWidth: true,
      onClick: () => {
        setSheet(null);
        setCart([]);
      }
    }, "Finalizar \xB7 ", window.SC_BRL(total))
  }, cart.map(x => /*#__PURE__*/React.createElement("div", {
    key: x.id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500
    }
  }, x.nome), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, x.sku, " \xB7 ", window.SC_BRL(x.preco))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "minus",
    label: "Menos",
    variant: "outline",
    size: "sm",
    onClick: () => setCart(c => c.map(y => y.id === x.id ? {
      ...y,
      qty: Math.max(1, y.qty - 1)
    } : y))
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 22,
      textAlign: "center",
      fontFamily: "var(--font-mono)",
      fontVariantNumeric: "tabular-nums"
    }
  }, x.qty), /*#__PURE__*/React.createElement(IconButton, {
    icon: "plus",
    label: "Mais",
    variant: "outline",
    size: "sm",
    onClick: () => setCart(c => c.map(y => y.id === x.id ? {
      ...y,
      qty: y.qty + 1
    } : y))
  })))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, "Total"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 24,
      fontWeight: 600,
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(total)))));
}
function MEstoque() {
  const D = window.SC_DATA;
  const [cat, setCat] = React.useState("Todos");
  const cats = ["Todos", "Freios", "Suspensão", "Motor", "Elétrica", "Filtros"];
  const rows = D.pecas.filter(p => cat === "Todos" || p.cat === cat);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      background: "var(--app-canvas)",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 16px",
      background: "var(--background)",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    placeholder: "Buscar no estoque"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      overflowX: "auto",
      paddingBottom: 2
    }
  }, cats.map(c => /*#__PURE__*/React.createElement(Chip, {
    key: c,
    selected: cat === c,
    onClick: () => setCat(c),
    style: {
      flexShrink: 0
    }
  }, c)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, rows.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.id,
    padding: 14,
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      lineHeight: 1.3
    }
  }, p.nome), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--muted-foreground)",
      marginTop: 2
    }
  }, p.sku, " \xB7 ", p.marca)), /*#__PURE__*/React.createElement(Badge, {
    tone: p.t,
    dot: true
  }, p.st)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Progress, {
    value: p.qtd,
    max: Math.max(p.min * 2, p.qtd),
    size: "sm",
    tone: p.qtd === 0 ? "danger" : p.qtd < p.min ? "warning" : "success"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--muted-foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, p.qtd, " un."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      fontWeight: 600,
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(p.preco)))))));
}
function MCaixa() {
  const D = window.SC_DATA;
  const ent = D.caixa.filter(m => m.e).reduce((s, m) => s + m.valor, 0);
  const sai = D.caixa.filter(m => !m.e).reduce((s, m) => s + m.valor, 0);
  const [sheet, setSheet] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      background: "var(--app-canvas)",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 18
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 99,
      background: "var(--success)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, "Caixa 01 \xB7 aberto \xE0s 08:00")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 34,
      fontWeight: 600,
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(ent - sai)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, "Entradas"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 15,
      fontWeight: 600,
      color: "var(--money-positive)",
      fontVariantNumeric: "tabular-nums"
    }
  }, "+ ", window.SC_BRL(ent))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, "Sa\xEDdas"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 15,
      fontWeight: 600,
      color: "var(--money-negative)",
      fontVariantNumeric: "tabular-nums"
    }
  }, "\u2212 ", window.SC_BRL(sai)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    icon: "arrow-up-right",
    fullWidth: true,
    onClick: () => setSheet(true)
  }, "Sangria"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    icon: "arrow-down-left",
    fullWidth: true
  }, "Suprimento"))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--muted-foreground)",
      paddingLeft: 2
    }
  }, "Movimenta\xE7\xF5es"), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, D.caixa.slice().reverse().map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "13px 16px",
      borderTop: i ? "1px solid var(--border)" : "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 34,
      height: 34,
      flexShrink: 0,
      borderRadius: "var(--radius-full)",
      background: m.e ? "var(--success-soft)" : "var(--danger-soft)",
      color: m.e ? "var(--success)" : "var(--danger)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: m.e ? "arrow-down-left" : "arrow-up-right",
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500
    }
  }, m.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--muted-foreground)"
    }
  }, m.hora, " \xB7 ", m.forma)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      fontWeight: 600,
      fontVariantNumeric: "tabular-nums",
      color: m.e ? "var(--money-positive)" : "var(--money-negative)"
    }
  }, (m.e ? "+ " : "− ") + window.SC_BRL(m.valor)))))), /*#__PURE__*/React.createElement(Sheet, {
    open: sheet,
    onClose: () => setSheet(false),
    title: "Sangria de caixa",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "lg",
      fullWidth: true,
      onClick: () => setSheet(false)
    }, "Cancelar"), /*#__PURE__*/React.createElement(Button, {
      variant: "destructive",
      size: "lg",
      fullWidth: true,
      icon: "check",
      onClick: () => setSheet(false)
    }, "Confirmar"))
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: "500,00"
  }), /*#__PURE__*/React.createElement(Chip, null, "Dep\xF3sito banc\xE1rio")));
}
function MMais() {
  const items = [["Vendas", "receipt"], ["Clientes", "users"], ["Fornecedores", "truck"], ["Relatórios", "chart-column"], ["Etiquetas e código de barras", "barcode"], ["Usuários e permissões", "shield-check"], ["Configurações", "settings"], ["Sair", "log-out"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      background: "var(--app-canvas)",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 16,
    style: {
      flexDirection: "row",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Marcos Ribeiro",
    size: 48
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 16,
      fontWeight: 600,
      letterSpacing: "var(--tracking-heading)"
    }
  }, "Marcos Ribeiro"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--muted-foreground)"
    }
  }, "Gerente \xB7 Loja Centro")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "chevron-right",
    label: "Ver perfil"
  })), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, items.map(([l, ic], i) => /*#__PURE__*/React.createElement("button", {
    key: l,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      width: "100%",
      minHeight: 52,
      padding: "0 16px",
      border: 0,
      borderTop: i ? "1px solid var(--border)" : "none",
      background: "transparent",
      cursor: "pointer",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: l === "Sair" ? "var(--danger)" : "var(--foreground)",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 19,
    color: l === "Sair" ? "var(--danger)" : "var(--muted-foreground)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, l), l !== "Sair" ? /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 16,
    color: "var(--zinc-400)"
  }) : null))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      fontSize: 12,
      color: "var(--muted-foreground)",
      paddingTop: 4
    }
  }, "SysControl 3.4.1 \xB7 Sincronizado h\xE1 2 min"));
}
function MobileApp({
  initial = "painel",
  dark = false,
  onToggleTheme
}) {
  const [tab, setTab] = React.useState(initial);
  const T = {
    painel: ["Painel", "Loja Centro · 06 ago", MPainel, "teal"],
    pdv: ["Nova venda", "Pedido #2042", MPdv, "light"],
    estoque: ["Estoque", "148 peças cadastradas", MEstoque, "light"],
    caixa: ["Caixa", "06 de agosto", MCaixa, "light"],
    mais: ["Mais", null, MMais, "light"]
  };
  const [title, sub, Screen, tone] = T[tab];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      position: "relative",
      background: "var(--background)",
      borderRadius: 44,
      border: "1px solid var(--border)",
      boxShadow: "var(--shadow-large)"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement(AppBar, {
    title: title,
    subtitle: sub,
    tone: tab === "painel" ? "teal" : "light",
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 2
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: dark ? "sun" : "moon",
      label: dark ? "Tema claro" : "Tema escuro",
      onClick: onToggleTheme,
      style: tab === "painel" ? {
        color: "var(--sidebar-foreground)"
      } : undefined
    }), tab === "painel" ? /*#__PURE__*/React.createElement(IconButton, {
      icon: "bell",
      label: "Notifica\xE7\xF5es",
      style: {
        color: "var(--sidebar-foreground)"
      }
    }) : /*#__PURE__*/React.createElement(IconButton, {
      icon: "ellipsis-vertical",
      label: "Op\xE7\xF5es"
    }))
  }), /*#__PURE__*/React.createElement(Screen, {
    go: setTab
  }), /*#__PURE__*/React.createElement(TabBar, {
    active: tab,
    onChange: setTab
  }));
}
Object.assign(window, {
  MobileApp,
  StatusBar,
  AppBar,
  TabBar,
  Sheet,
  MPainel,
  MPdv,
  MEstoque,
  MCaixa,
  MMais
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Caixa.jsx
try { (() => {
const {
  Card,
  CardHeader,
  StatCard,
  DataTable,
  Badge,
  Button,
  IconButton,
  Divider,
  Modal,
  Field,
  Input,
  Select,
  Alert,
  Tabs,
  RadioGroup
} = window.SysControlDesignSystem_02daf6;
function CaixaScreen() {
  const D = window.SC_DATA;
  const [modal, setModal] = React.useState(null);
  const ent = D.caixa.filter(m => m.e).reduce((s, m) => s + m.valor, 0);
  const sai = D.caixa.filter(m => !m.e).reduce((s, m) => s + m.valor, 0);
  const formas = [["Dinheiro", 512.7 + 300 - 642], ["Pix", 4606.7], ["Débito", 179], ["Crédito", 389.8], ["Boleto", 5310]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Caixa 01 aberto desde 08:00 por Marcos Ribeiro",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "link",
      size: "sm",
      onClick: () => setModal("fechar")
    }, "Fechar caixa")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Saldo em caixa",
    value: window.SC_BRL(ent - sai),
    icon: "banknote",
    tone: "primary"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Entradas",
    value: window.SC_BRL(ent),
    unit: D.caixa.filter(m => m.e).length + " lanç.",
    icon: "arrow-down-left",
    tone: "success"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Sa\xEDdas",
    value: window.SC_BRL(sai),
    unit: D.caixa.filter(m => !m.e).length + " lanç.",
    icon: "arrow-up-right",
    tone: "danger"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Em dinheiro",
    value: window.SC_BRL(170.7),
    unit: "conferir",
    icon: "wallet",
    tone: "warning"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.7fr 1fr",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 20px 0"
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Movimenta\xE7\xF5es de hoje",
    description: "Caixa 01 \xB7 06 de agosto",
    action: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "sm",
      icon: "arrow-up-right",
      onClick: () => setModal("sangria")
    }, "Sangria"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      icon: "arrow-down-left",
      onClick: () => setModal("suprimento")
    }, "Suprimento"))
  })), /*#__PURE__*/React.createElement(DataTable, {
    dense: true,
    rows: D.caixa,
    columns: [{
      key: "hora",
      header: "Hora",
      mono: true,
      width: 70
    }, {
      key: "tipo",
      header: "Tipo",
      width: 110,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.tipo === "Venda" ? "success" : r.e ? "info" : "warning"
      }, r.tipo)
    }, {
      key: "desc",
      header: "Descrição",
      wrap: true
    }, {
      key: "forma",
      header: "Forma",
      width: 110
    }, {
      key: "valor",
      header: "Valor",
      align: "right",
      mono: true,
      width: 130,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.e ? "var(--money-positive)" : "var(--money-negative)",
          fontWeight: "var(--weight-semibold)"
        }
      }, (r.e ? "+ " : "− ") + window.SC_BRL(r.valor))
    }, {
      key: "a",
      header: "",
      align: "right",
      width: 44,
      render: () => /*#__PURE__*/React.createElement(IconButton, {
        icon: "receipt-text",
        label: "Ver comprovante",
        size: "sm"
      })
    }]
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Por forma de pagamento",
    description: "Total recebido hoje"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, formas.map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-body)"
    }
  }, l), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(v)))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)"
    }
  }, "Total"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h3)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(formas.reduce((s, x) => s + x[1], 0))))))), /*#__PURE__*/React.createElement(Modal, {
    open: modal === "sangria" || modal === "suprimento",
    onClose: () => setModal(null),
    size: "sm",
    title: modal === "sangria" ? "Sangria de caixa" : "Suprimento de caixa",
    description: "Caixa 01 \xB7 Marcos Ribeiro",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setModal(null)
    }, "Cancelar"), /*#__PURE__*/React.createElement(Button, {
      variant: modal === "sangria" ? "destructive" : "success",
      icon: "check",
      onClick: () => setModal(null)
    }, "Confirmar"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Valor",
    required: true
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: "500,00"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Motivo",
    required: true
  }, /*#__PURE__*/React.createElement(Select, {
    placeholder: "Selecione",
    options: ["Depósito bancário", "Pagamento de fornecedor", "Troco", "Despesa operacional"]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Observa\xE7\xE3o"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Opcional"
  })))), /*#__PURE__*/React.createElement(Modal, {
    open: modal === "fechar",
    onClose: () => setModal(null),
    title: "Fechamento de caixa",
    description: "Caixa 01 \xB7 06 de agosto \xB7 08:00 \u2192 agora",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setModal(null)
    }, "Cancelar"), /*#__PURE__*/React.createElement(Button, {
      variant: "success",
      icon: "lock",
      onClick: () => setModal(null)
    }, "Fechar caixa"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "Confira o dinheiro em gaveta antes de fechar"
  }, "O sistema espera ", window.SC_BRL(170.7), " em esp\xE9cie."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Valor contado em esp\xE9cie",
    required: true
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: "170,70"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Diferen\xE7a"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    readOnly: true,
    defaultValue: "0,00",
    suffix: "BRL"
  }))), /*#__PURE__*/React.createElement(Field, {
    label: "Observa\xE7\xF5es do fechamento"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Opcional"
  })))));
}
Object.assign(window, {
  CaixaScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Caixa.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Dashboard.jsx
try { (() => {
const {
  Card,
  CardHeader,
  StatCard,
  DataTable,
  Badge,
  Button,
  Progress,
  Alert,
  IconButton,
  Tabs
} = window.SysControlDesignSystem_02daf6;
function Bars() {
  const d = [["Seg", 62], ["Ter", 78], ["Qua", 54], ["Qui", 91], ["Sex", 100], ["Sáb", 73], ["Dom", 22]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 14,
      height: 150,
      paddingTop: 8
    }
  }, d.map(([l, v], i) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      height: v + "%",
      borderRadius: "var(--radius-sm) var(--radius-sm) 2px 2px",
      background: i === 4 ? "var(--primary)" : "var(--primary-soft-hover)",
      transition: "height var(--duration-slow) var(--ease-out)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-tiny)",
      color: "var(--muted-foreground)"
    }
  }, l))));
}
function DashboardScreen({
  go
}) {
  const D = window.SC_DATA;
  const criticas = D.pecas.filter(p => p.qtd < p.min);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: criticas.length + " peças abaixo do estoque mínimo",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "link",
      size: "sm",
      onClick: () => go("estoque")
    }, "Ver lista")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Faturamento hoje",
    value: window.SC_BRL(14280.5),
    delta: 12.4,
    deltaLabel: "vs. ontem",
    icon: "banknote",
    tone: "primary"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Vendas",
    value: "63",
    unit: "pedidos",
    delta: -4.1,
    deltaLabel: "vs. ontem",
    icon: "receipt"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Ticket m\xE9dio",
    value: window.SC_BRL(226.67),
    delta: 17.2,
    deltaLabel: "vs. ontem",
    icon: "trending-up",
    tone: "success"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Estoque cr\xEDtico",
    value: criticas.length,
    unit: "itens",
    icon: "triangle-alert",
    tone: "warning"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.7fr 1fr",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Vendas da semana",
    description: "Faturamento di\xE1rio, \xFAltimos 7 dias",
    action: /*#__PURE__*/React.createElement(Tabs, {
      variant: "segmented",
      items: ["Semana", "Mês", "Ano"]
    })
  }), /*#__PURE__*/React.createElement(Bars, null)), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Reposi\xE7\xE3o urgente",
    action: /*#__PURE__*/React.createElement(IconButton, {
      icon: "more-horizontal",
      label: "Op\xE7\xF5es"
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, criticas.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 10,
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)"
    }
  }, p.nome), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-small)",
      color: "var(--muted-foreground)",
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap"
    }
  }, p.qtd, "/", p.min)), /*#__PURE__*/React.createElement(Progress, {
    value: p.qtd,
    max: p.min,
    tone: p.qtd === 0 ? "danger" : "warning",
    size: "sm"
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    icon: "truck",
    fullWidth: true
  }, "Gerar pedido de compra")))), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 20px 0"
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "\xDAltimas vendas",
    description: "Atualizado h\xE1 2 min",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "sm",
      iconEnd: "arrow-right",
      onClick: () => go("vendas")
    }, "Ver todas")
  })), /*#__PURE__*/React.createElement(DataTable, {
    rows: D.vendas.slice(0, 5),
    onRowClick: () => go("vendas"),
    columns: [{
      key: "id",
      header: "Pedido",
      mono: true,
      width: 90,
      render: r => "#" + r.id
    }, {
      key: "cliente",
      header: "Cliente",
      wrap: true
    }, {
      key: "vend",
      header: "Vendedor",
      width: 150
    }, {
      key: "pag",
      header: "Pagamento",
      width: 120
    }, {
      key: "itens",
      header: "Itens",
      align: "right",
      mono: true,
      width: 70
    }, {
      key: "total",
      header: "Total",
      align: "right",
      mono: true,
      width: 120,
      render: r => window.SC_BRL(r.total)
    }, {
      key: "st",
      header: "Situação",
      width: 130,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.t,
        dot: true
      }, r.st)
    }]
  })));
}
Object.assign(window, {
  DashboardScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Estoque.jsx
try { (() => {
const {
  Card,
  CardHeader,
  DataTable,
  Badge,
  Button,
  IconButton,
  Input,
  Select,
  Chip,
  Tabs,
  Pagination,
  Divider,
  Checkbox,
  Modal,
  Field,
  Textarea,
  Progress,
  EmptyState
} = window.SysControlDesignSystem_02daf6;
function EstoqueScreen() {
  const D = window.SC_DATA;
  const [tab, setTab] = React.useState("todas");
  const [q, setQ] = React.useState("");
  const [sel, setSel] = React.useState([]);
  const [detail, setDetail] = React.useState(null);
  const base = D.pecas.filter(p => tab === "todas" || tab === "baixo" && p.qtd < p.min && p.qtd > 0 || tab === "zerado" && p.qtd === 0);
  const rows = base.filter(p => p.nome.toLowerCase().includes(q.toLowerCase()) || p.sku.toLowerCase().includes(q.toLowerCase()));
  const toggle = id => setSel(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      key: "todas",
      label: "Todas",
      count: D.pecas.length
    }, {
      key: "baixo",
      label: "Estoque baixo",
      count: D.pecas.filter(p => p.qtd < p.min && p.qtd > 0).length
    }, {
      key: "zerado",
      label: "Esgotadas",
      count: D.pecas.filter(p => p.qtd === 0).length
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    icon: "upload"
  }, "Importar planilha"), /*#__PURE__*/React.createElement(Button, {
    icon: "plus"
  }, "Nova pe\xE7a"))), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 20px",
      display: "flex",
      gap: 10,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 240
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    size: "sm",
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar por nome, c\xF3digo ou fabricante"
  })), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    fullWidth: false,
    placeholder: "Categoria",
    options: ["Freios", "Suspensão", "Motor", "Elétrica", "Filtros"],
    style: {
      width: 170
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    fullWidth: false,
    placeholder: "Fabricante",
    options: ["Bosch", "Cofap", "NGK", "Moura", "Tecfil"],
    style: {
      width: 170
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "sliders-horizontal",
    label: "Mais filtros",
    variant: "outline",
    size: "sm"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "download",
    label: "Exportar CSV",
    variant: "outline",
    size: "sm"
  })), sel.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 20px",
      background: "var(--primary-soft)",
      borderTop: "1px solid var(--primary-soft-border)",
      borderBottom: "1px solid var(--primary-soft-border)",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)",
      color: "var(--primary-soft-foreground)"
    }
  }, sel.length, " pe\xE7as selecionadas"), /*#__PURE__*/React.createElement(Button, {
    variant: "flat",
    size: "sm",
    icon: "tag"
  }, "Ajustar pre\xE7o"), /*#__PURE__*/React.createElement(Button, {
    variant: "flat",
    size: "sm",
    icon: "truck"
  }, "Pedir ao fornecedor"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setSel([]),
    style: {
      marginLeft: "auto"
    }
  }, "Limpar sele\xE7\xE3o")) : /*#__PURE__*/React.createElement(Divider, null), rows.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "package-search",
    title: "Nenhuma pe\xE7a encontrada",
    description: "Ajuste os filtros ou cadastre uma nova pe\xE7a.",
    action: /*#__PURE__*/React.createElement(Button, {
      icon: "plus"
    }, "Nova pe\xE7a")
  }) : /*#__PURE__*/React.createElement(DataTable, {
    selectable: true,
    rows: rows.map(r => ({
      ...r,
      select: /*#__PURE__*/React.createElement(Checkbox, {
        checked: sel.includes(r.id),
        onChange: () => toggle(r.id)
      })
    })),
    onRowClick: setDetail,
    columns: [{
      key: "sku",
      header: "Código",
      mono: true,
      width: 100
    }, {
      key: "nome",
      header: "Peça",
      wrap: true,
      render: r => /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: "var(--weight-medium)"
        }
      }, r.nome), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: "var(--text-tiny)",
          color: "var(--muted-foreground)"
        }
      }, r.marca))
    }, {
      key: "cat",
      header: "Categoria",
      width: 120
    }, {
      key: "qtd",
      header: "Estoque",
      align: "right",
      mono: true,
      width: 100,
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-end",
          gap: 4
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.qtd === 0 ? "var(--danger)" : r.qtd < r.min ? "var(--warning-icon)" : "var(--foreground)",
          fontWeight: "var(--weight-semibold)"
        }
      }, r.qtd), /*#__PURE__*/React.createElement(Progress, {
        value: r.qtd,
        max: Math.max(r.min * 2, r.qtd),
        size: "sm",
        tone: r.qtd === 0 ? "danger" : r.qtd < r.min ? "warning" : "success",
        style: {
          width: 56
        }
      }))
    }, {
      key: "custo",
      header: "Custo",
      align: "right",
      mono: true,
      width: 100,
      render: r => window.SC_BRL(r.custo)
    }, {
      key: "preco",
      header: "Venda",
      align: "right",
      mono: true,
      width: 100,
      sortable: true,
      render: r => window.SC_BRL(r.preco)
    }, {
      key: "st",
      header: "Situação",
      width: 140,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.t,
        dot: true
      }, r.st)
    }, {
      key: "a",
      header: "",
      align: "right",
      width: 44,
      render: () => /*#__PURE__*/React.createElement(IconButton, {
        icon: "more-horizontal",
        label: "A\xE7\xF5es",
        size: "sm"
      })
    }]
  }), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px"
    }
  }, /*#__PURE__*/React.createElement(Pagination, {
    page: 1,
    pageCount: 8,
    total: 148,
    pageSize: rows.length || 8
  }))), /*#__PURE__*/React.createElement(Modal, {
    open: !!detail,
    onClose: () => setDetail(null),
    size: "lg",
    title: detail ? detail.nome : "",
    description: detail ? detail.sku + " · " + detail.marca + " · " + detail.cat : "",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setDetail(null)
    }, "Fechar"), /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      icon: "truck"
    }, "Pedir ao fornecedor"), /*#__PURE__*/React.createElement(Button, {
      icon: "check"
    }, "Salvar altera\xE7\xF5es"))
  }, detail ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Pre\xE7o de custo"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: detail.custo.toFixed(2).replace(".", ",")
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Pre\xE7o de venda"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: detail.preco.toFixed(2).replace(".", ",")
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Quantidade em estoque"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "un.",
    defaultValue: String(detail.qtd)
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Estoque m\xEDnimo",
    hint: "Dispara o alerta de reposi\xE7\xE3o"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "un.",
    defaultValue: String(detail.min)
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Localiza\xE7\xE3o"
  }, /*#__PURE__*/React.createElement(Select, {
    defaultValue: "A-12",
    options: ["A-12", "B-04", "C-21", "Depósito"]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Fornecedor"
  }, /*#__PURE__*/React.createElement(Select, {
    defaultValue: detail.marca,
    options: ["Bosch", "Cofap", "NGK", "Moura", "Tecfil", "Riffel", "Fremax", "Nakata"]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "span 2"
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Aplica\xE7\xF5es",
    hint: "Modelos compat\xEDveis"
  }, /*#__PURE__*/React.createElement(Textarea, {
    rows: 2,
    defaultValue: "Honda CG 160 (2016\u20132024), Honda Titan 160, Honda Start 160"
  })))) : null));
}
Object.assign(window, {
  EstoqueScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Estoque.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Pdv.jsx
try { (() => {
const {
  Card,
  CardHeader,
  Input,
  Button,
  IconButton,
  Badge,
  Chip,
  Divider,
  EmptyState,
  Modal,
  Field,
  Select,
  RadioGroup,
  DataTable,
  Toast
} = window.SysControlDesignSystem_02daf6;
function PdvScreen() {
  const D = window.SC_DATA;
  const [q, setQ] = React.useState("");
  const [cat, setCat] = React.useState("Todos");
  const [cart, setCart] = React.useState([{
    ...D.pecas[0],
    qty: 2
  }, {
    ...D.pecas[4],
    qty: 4
  }]);
  const [open, setOpen] = React.useState(false);
  const [toast, setToast] = React.useState(null);
  const cats = ["Todos", "Freios", "Suspensão", "Motor", "Elétrica", "Filtros"];
  const list = D.pecas.filter(p => (cat === "Todos" || p.cat === cat) && (p.nome.toLowerCase().includes(q.toLowerCase()) || p.sku.toLowerCase().includes(q.toLowerCase())));
  const add = p => setCart(c => {
    const i = c.findIndex(x => x.id === p.id);
    if (i > -1) {
      const n = [...c];
      n[i] = {
        ...n[i],
        qty: n[i].qty + 1
      };
      return n;
    }
    return [...c, {
      ...p,
      qty: 1
    }];
  });
  const bump = (id, d) => setCart(c => c.map(x => x.id === id ? {
    ...x,
    qty: Math.max(1, x.qty + d)
  } : x));
  const drop = id => setCart(c => c.filter(x => x.id !== id));
  const sub = cart.reduce((s, x) => s + x.preco * x.qty, 0);
  const desc = sub * 0.05,
    total = sub - desc;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 400px",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Buscar pe\xE7a, c\xF3digo ou fabricante"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    icon: "barcode",
    style: {
      flexShrink: 0
    }
  }, "Ler c\xF3digo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, cats.map(c => /*#__PURE__*/React.createElement(Chip, {
    key: c,
    selected: cat === c,
    onClick: () => setCat(c)
  }, c)))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 430,
      overflowY: "auto"
    }
  }, list.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "search-x",
    title: "Nenhuma pe\xE7a encontrada",
    description: 'Nada corresponde a "' + q + '". Verifique o código ou tente outro termo.'
  }) : /*#__PURE__*/React.createElement(DataTable, {
    dense: true,
    rows: list,
    onRowClick: add,
    columns: [{
      key: "sku",
      header: "Código",
      mono: true,
      width: 96
    }, {
      key: "nome",
      header: "Peça",
      wrap: true,
      render: r => /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          flexDirection: "column"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: "var(--weight-medium)"
        }
      }, r.nome), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: "var(--text-tiny)",
          color: "var(--muted-foreground)"
        }
      }, r.marca, " \xB7 ", r.cat))
    }, {
      key: "qtd",
      header: "Estoque",
      align: "right",
      mono: true,
      width: 80,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.qtd === 0 ? "var(--danger)" : r.qtd < r.min ? "var(--warning-icon)" : "var(--foreground)"
        }
      }, r.qtd)
    }, {
      key: "preco",
      header: "Preço",
      align: "right",
      mono: true,
      width: 100,
      render: r => window.SC_BRL(r.preco)
    }, {
      key: "a",
      header: "",
      align: "right",
      width: 44,
      render: r => /*#__PURE__*/React.createElement(IconButton, {
        icon: "plus",
        label: "Adicionar",
        variant: "outline",
        size: "sm"
      })
    }]
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: 0,
    style: {
      position: "sticky",
      top: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 20px 14px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-medium)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-heading)"
    }
  }, "Carrinho"), /*#__PURE__*/React.createElement(Badge, {
    tone: "primary"
  }, cart.reduce((s, x) => s + x.qty, 0), " itens")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "trash-2",
    label: "Limpar carrinho",
    variant: "danger",
    size: "sm",
    onClick: () => setCart([])
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 12,
      maxHeight: 300,
      overflowY: "auto"
    }
  }, cart.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    compact: true,
    icon: "shopping-cart",
    title: "Carrinho vazio",
    description: "Selecione uma pe\xE7a na lista ao lado."
  }) : null, cart.map(x => /*#__PURE__*/React.createElement("div", {
    key: x.id,
    style: {
      display: "flex",
      gap: 10,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-medium)"
    }
  }, x.nome), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-tiny)",
      color: "var(--muted-foreground)"
    }
  }, x.sku, " \xB7 ", window.SC_BRL(x.preco))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "minus",
    label: "Menos",
    variant: "outline",
    size: "sm",
    onClick: () => bump(x.id, -1)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 24,
      textAlign: "center",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-body)",
      fontVariantNumeric: "tabular-nums"
    }
  }, x.qty), /*#__PURE__*/React.createElement(IconButton, {
    icon: "plus",
    label: "Mais",
    variant: "outline",
    size: "sm",
    onClick: () => bump(x.id, 1)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 82,
      textAlign: "right",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(x.preco * x.qty)), /*#__PURE__*/React.createElement(IconButton, {
    icon: "x",
    label: "Remover",
    size: "sm",
    onClick: () => drop(x.id)
  })))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, [["Subtotal", window.SC_BRL(sub)], ["Desconto 5%", "− " + window.SC_BRL(desc)]].map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: "var(--text-body)",
      color: "var(--muted-foreground)"
    }
  }, /*#__PURE__*/React.createElement("span", null, l), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontVariantNumeric: "tabular-nums"
    }
  }, v))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      paddingTop: 8,
      borderTop: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)"
    }
  }, "Total"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h3)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-display)",
      fontVariantNumeric: "tabular-nums"
    }
  }, window.SC_BRL(total))), /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    size: "lg",
    icon: "check",
    fullWidth: true,
    disabled: cart.length === 0,
    onClick: () => setOpen(true)
  }, "Finalizar venda"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: "pause",
    fullWidth: true
  }, "Salvar or\xE7amento"))), /*#__PURE__*/React.createElement(Modal, {
    open: open,
    onClose: () => setOpen(false),
    title: "Finalizar venda",
    description: "Pedido #2042 · " + cart.reduce((s, x) => s + x.qty, 0) + " itens · " + window.SC_BRL(total),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setOpen(false)
    }, "Cancelar"), /*#__PURE__*/React.createElement(Button, {
      variant: "success",
      icon: "check",
      onClick: () => {
        setOpen(false);
        setCart([]);
        setToast(true);
      }
    }, "Confirmar pagamento"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Cliente"
  }, /*#__PURE__*/React.createElement(Select, {
    placeholder: "Consumidor final",
    options: D.clientes.map(c => c.nome)
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Forma de pagamento"
  }, /*#__PURE__*/React.createElement(RadioGroup, {
    defaultValue: "pix",
    options: [{
      value: "pix",
      label: "Pix",
      description: "Confirmação imediata"
    }, {
      value: "credito",
      label: "Cartão de crédito",
      description: "Até 12x, taxa de 2,9%"
    }, {
      value: "debito",
      label: "Cartão de débito"
    }, {
      value: "dinheiro",
      label: "Dinheiro"
    }]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Valor recebido",
    hint: "Troco calculado automaticamente"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    suffix: "BRL",
    defaultValue: total.toFixed(2).replace(".", ",")
  })))), toast ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 24,
      bottom: 24,
      zIndex: 80
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    title: "Venda #2042 finalizada",
    description: "Recibo enviado por WhatsApp",
    onClose: () => setToast(null),
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "link",
      size: "sm",
      onClick: () => setToast(null)
    }, "Desfazer")
  })) : null);
}
Object.assign(window, {
  PdvScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Pdv.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Vendas.jsx
try { (() => {
const {
  Card,
  CardHeader,
  DataTable,
  Badge,
  Button,
  IconButton,
  Input,
  Select,
  Tabs,
  Pagination,
  Divider,
  Avatar,
  StatCard
} = window.SysControlDesignSystem_02daf6;
function VendasScreen() {
  const D = window.SC_DATA;
  const [tab, setTab] = React.useState("todas");
  const rows = D.vendas.filter(v => tab === "todas" || tab === "pagas" && v.st === "Pago" || tab === "pendentes" && v.st === "Pendente" || tab === "canceladas" && v.st === "Cancelado");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Vendas hoje",
    value: "63",
    unit: "pedidos",
    delta: -4.1,
    deltaLabel: "vs. ontem",
    icon: "receipt"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Faturado",
    value: window.SC_BRL(14280.5),
    delta: 12.4,
    icon: "banknote",
    tone: "primary"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "A receber",
    value: window.SC_BRL(5310),
    unit: "1 boleto",
    icon: "clock",
    tone: "warning"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Cancelamentos",
    value: "1",
    unit: "pedido",
    icon: "circle-x",
    tone: "danger"
  })), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 20px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      key: "todas",
      label: "Todas",
      count: D.vendas.length
    }, {
      key: "pagas",
      label: "Pagas",
      count: 4
    }, {
      key: "pendentes",
      label: "Pendentes",
      count: 1
    }, {
      key: "canceladas",
      label: "Canceladas",
      count: 1
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    size: "sm",
    placeholder: "Pedido ou cliente",
    fullWidth: false,
    style: {
      width: 230
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    fullWidth: false,
    placeholder: "Vendedor",
    options: ["Marcos Ribeiro", "Ana Lima", "Diego Farias"],
    style: {
      width: 160
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    icon: "download"
  }, "Exportar"))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement(DataTable, {
    rows: rows,
    columns: [{
      key: "id",
      header: "Pedido",
      mono: true,
      width: 90,
      render: r => "#" + r.id
    }, {
      key: "hora",
      header: "Hora",
      mono: true,
      width: 70
    }, {
      key: "cliente",
      header: "Cliente",
      wrap: true
    }, {
      key: "vend",
      header: "Vendedor",
      width: 180,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 8
        }
      }, /*#__PURE__*/React.createElement(Avatar, {
        name: r.vend,
        size: 24
      }), r.vend)
    }, {
      key: "pag",
      header: "Pagamento",
      width: 120
    }, {
      key: "itens",
      header: "Itens",
      align: "right",
      mono: true,
      width: 70
    }, {
      key: "total",
      header: "Total",
      align: "right",
      mono: true,
      width: 130,
      render: r => window.SC_BRL(r.total)
    }, {
      key: "st",
      header: "Situação",
      width: 130,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.t,
        dot: true
      }, r.st)
    }, {
      key: "a",
      header: "",
      align: "right",
      width: 80,
      render: () => /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          gap: 2
        }
      }, /*#__PURE__*/React.createElement(IconButton, {
        icon: "printer",
        label: "Imprimir",
        size: "sm"
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "more-horizontal",
        label: "A\xE7\xF5es",
        size: "sm"
      }))
    }]
  }), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px"
    }
  }, /*#__PURE__*/React.createElement(Pagination, {
    page: 1,
    pageCount: 11,
    total: 63,
    pageSize: 6
  }))));
}
function ClientesScreen() {
  const D = window.SC_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: [{
      key: "todos",
      label: "Todos",
      count: D.clientes.length
    }, {
      key: "oficinas",
      label: "Oficinas",
      count: 2
    }, {
      key: "balcao",
      label: "Balcão",
      count: 2
    }]
  }), /*#__PURE__*/React.createElement(Button, {
    icon: "user-plus"
  }, "Novo cliente")), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 20px"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    size: "sm",
    placeholder: "Buscar por nome, CNPJ/CPF ou telefone"
  })), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement(DataTable, {
    rows: D.clientes,
    columns: [{
      key: "nome",
      header: "Cliente",
      wrap: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 10
        }
      }, /*#__PURE__*/React.createElement(Avatar, {
        name: r.nome,
        size: 32,
        tone: r.tipo === "Balcão" ? "neutral" : "primary"
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          display: "flex",
          flexDirection: "column"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: "var(--weight-medium)"
        }
      }, r.nome), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "var(--font-mono)",
          fontSize: "var(--text-tiny)",
          color: "var(--muted-foreground)"
        }
      }, r.doc)))
    }, {
      key: "tipo",
      header: "Tipo",
      width: 110,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.tipo === "Revenda" ? "primary" : "neutral"
      }, r.tipo)
    }, {
      key: "tel",
      header: "Telefone",
      mono: true,
      width: 150
    }, {
      key: "compras",
      header: "Compras",
      align: "right",
      mono: true,
      width: 90
    }, {
      key: "total",
      header: "Total gasto",
      align: "right",
      mono: true,
      width: 140,
      render: r => window.SC_BRL(r.total)
    }, {
      key: "ult",
      header: "Última compra",
      width: 130
    }, {
      key: "a",
      header: "",
      align: "right",
      width: 44,
      render: () => /*#__PURE__*/React.createElement(IconButton, {
        icon: "more-horizontal",
        label: "A\xE7\xF5es",
        size: "sm"
      })
    }]
  })));
}
Object.assign(window, {
  VendasScreen,
  ClientesScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Vendas.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/data.js
try { (() => {
window.SC_DATA = {
  pecas: [{
    id: 1,
    sku: "FR-2280",
    nome: "Pastilha de freio dianteira",
    marca: "Bosch",
    cat: "Freios",
    qtd: 148,
    min: 40,
    preco: 189.9,
    custo: 112.4,
    st: "Em estoque",
    t: "success"
  }, {
    id: 2,
    sku: "SU-1044",
    nome: "Amortecedor traseiro CG 160",
    marca: "Cofap",
    cat: "Suspensão",
    qtd: 9,
    min: 15,
    preco: 312.0,
    custo: 198.0,
    st: "Estoque baixo",
    t: "warning"
  }, {
    id: 3,
    sku: "MO-7715",
    nome: "Kit relação Titan 150",
    marca: "Riffel",
    cat: "Motor",
    qtd: 0,
    min: 12,
    preco: 248.5,
    custo: 161.0,
    st: "Esgotado",
    t: "danger"
  }, {
    id: 4,
    sku: "EL-3390",
    nome: "Bateria selada 12V 5Ah",
    marca: "Moura",
    cat: "Elétrica",
    qtd: 37,
    min: 20,
    preco: 179.0,
    custo: 104.9,
    st: "Em estoque",
    t: "success"
  }, {
    id: 5,
    sku: "FI-0121",
    nome: "Filtro de óleo Fiat Argo 1.0",
    marca: "Tecfil",
    cat: "Filtros",
    qtd: 212,
    min: 60,
    preco: 34.9,
    custo: 17.8,
    st: "Em estoque",
    t: "success"
  }, {
    id: 6,
    sku: "FR-9034",
    nome: "Disco de freio ventilado Onix",
    marca: "Fremax",
    cat: "Freios",
    qtd: 26,
    min: 18,
    preco: 268.0,
    custo: 172.0,
    st: "Em estoque",
    t: "success"
  }, {
    id: 7,
    sku: "MO-4408",
    nome: "Vela de ignição iridium NGK",
    marca: "NGK",
    cat: "Motor",
    qtd: 11,
    min: 24,
    preco: 79.9,
    custo: 41.2,
    st: "Estoque baixo",
    t: "warning"
  }, {
    id: 8,
    sku: "SU-6650",
    nome: "Bieleta dianteira HB20",
    marca: "Nakata",
    cat: "Suspensão",
    qtd: 64,
    min: 20,
    preco: 96.5,
    custo: 52.0,
    st: "Em estoque",
    t: "success"
  }],
  vendas: [{
    id: "2041",
    cliente: "Oficina Dois Irmãos",
    itens: 6,
    total: 1842.30,
    pag: "Pix",
    vend: "Marcos Ribeiro",
    hora: "14:32",
    st: "Pago",
    t: "success"
  }, {
    id: "2040",
    cliente: "Rafael Sampaio",
    itens: 2,
    total: 389.80,
    pag: "Crédito 3x",
    vend: "Ana Lima",
    hora: "14:05",
    st: "Pago",
    t: "success"
  }, {
    id: "2039",
    cliente: "Moto Peças Vale",
    itens: 14,
    total: 5310.00,
    pag: "Boleto",
    vend: "Marcos Ribeiro",
    hora: "13:48",
    st: "Pendente",
    t: "warning"
  }, {
    id: "2038",
    cliente: "Juliana Prado",
    itens: 1,
    total: 179.00,
    pag: "Débito",
    vend: "Ana Lima",
    hora: "12:57",
    st: "Pago",
    t: "success"
  }, {
    id: "2037",
    cliente: "Auto Center Norte",
    itens: 9,
    total: 2764.40,
    pag: "Pix",
    vend: "Diego Farias",
    hora: "11:20",
    st: "Pago",
    t: "success"
  }, {
    id: "2036",
    cliente: "Consumidor final",
    itens: 3,
    total: 512.70,
    pag: "Dinheiro",
    vend: "Ana Lima",
    hora: "10:44",
    st: "Cancelado",
    t: "danger"
  }],
  caixa: [{
    hora: "08:00",
    tipo: "Abertura",
    desc: "Fundo de troco",
    forma: "Dinheiro",
    valor: 300.00,
    e: 1
  }, {
    hora: "10:44",
    tipo: "Venda",
    desc: "Pedido #2036",
    forma: "Dinheiro",
    valor: 512.70,
    e: 1
  }, {
    hora: "11:20",
    tipo: "Venda",
    desc: "Pedido #2037",
    forma: "Pix",
    valor: 2764.40,
    e: 1
  }, {
    hora: "12:10",
    tipo: "Sangria",
    desc: "Depósito bancário",
    forma: "Dinheiro",
    valor: 500.00,
    e: 0
  }, {
    hora: "12:57",
    tipo: "Venda",
    desc: "Pedido #2038",
    forma: "Débito",
    valor: 179.00,
    e: 1
  }, {
    hora: "13:30",
    tipo: "Despesa",
    desc: "Frete transportadora",
    forma: "Dinheiro",
    valor: 142.00,
    e: 0
  }, {
    hora: "14:32",
    tipo: "Venda",
    desc: "Pedido #2041",
    forma: "Pix",
    valor: 1842.30,
    e: 1
  }],
  clientes: [{
    nome: "Oficina Dois Irmãos",
    doc: "12.884.301/0001-55",
    tipo: "Oficina",
    tel: "(11) 98812-4410",
    compras: 47,
    total: 68420.90,
    ult: "Hoje"
  }, {
    nome: "Moto Peças Vale",
    doc: "08.117.442/0001-09",
    tipo: "Revenda",
    tel: "(11) 3388-2140",
    compras: 112,
    total: 214880.00,
    ult: "Hoje"
  }, {
    nome: "Auto Center Norte",
    doc: "22.940.118/0001-72",
    tipo: "Oficina",
    tel: "(11) 99640-7712",
    compras: 38,
    total: 51230.40,
    ult: "Ontem"
  }, {
    nome: "Rafael Sampaio",
    doc: "318.442.190-04",
    tipo: "Balcão",
    tel: "(11) 98120-3345",
    compras: 6,
    total: 2140.60,
    ult: "Hoje"
  }, {
    nome: "Juliana Prado",
    doc: "402.110.887-31",
    tipo: "Balcão",
    tel: "(11) 99880-1204",
    compras: 3,
    total: 640.00,
    ult: "3 dias"
  }],
  nav: [{
    key: "painel",
    label: "Painel",
    icon: "layout-dashboard"
  }, {
    section: "Operação"
  }, {
    key: "pdv",
    label: "PDV",
    icon: "shopping-cart"
  }, {
    key: "vendas",
    label: "Vendas",
    icon: "receipt"
  }, {
    key: "caixa",
    label: "Caixa",
    icon: "banknote"
  }, {
    section: "Catálogo"
  }, {
    key: "estoque",
    label: "Estoque",
    icon: "package",
    badge: 12
  }, {
    key: "clientes",
    label: "Clientes",
    icon: "users"
  }, {
    key: "fornecedores",
    label: "Fornecedores",
    icon: "truck"
  }, {
    section: "Gestão"
  }, {
    key: "relatorios",
    label: "Relatórios",
    icon: "chart-column"
  }, {
    key: "config",
    label: "Configurações",
    icon: "settings"
  }]
};
window.SC_BRL = n => n.toLocaleString("pt-BR", {
  style: "currency",
  currency: "BRL"
});
window.SC_NUM = n => n.toLocaleString("pt-BR");
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Topbar = __ds_scope.Topbar;

__ds_ns.TopbarStatus = __ds_scope.TopbarStatus;

})();
