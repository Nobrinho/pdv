# SysControl Design System

SysControl is a web and mobile application for **auto and motorcycle parts retail** — selling parts over the counter, managing sales, controlling stock, and running the till (*caixa*). It is a Portuguese-language (pt-BR) business tool used all day by counter staff, stockroom staff and store managers. The interface is dense, keyboard- and barcode-driven, and optimised for repetition: hundreds of lookups, dozens of sales, one cash close per shift per register.

This design system is the shared visual and interaction language for both surfaces:

- **SysControl Web** — the desktop back-office and point of sale. Persistent teal sidebar, 56px topbar, data-table-heavy content column.
- **SysControl Mobile** — the phone app for counter sales, quick stock checks and till oversight. Tab bar, bottom sheets, card lists instead of tables.

## Sources

The visual foundations were built by reading two component libraries the user provided as reference:

- **shadcn/ui** — https://github.com/shadcn-ui/ui
  Supplies the control geometry and token vocabulary: `--radius: 0.625rem` and its derived scale, 32/36/40px control heights, `px-4` / `gap-2` paddings, `shadow-xs` / `shadow-sm`, the 3px focus ring at 50% opacity, and the semantic slot names (`background`, `foreground`, `card`, `muted`, `accent`, `border`, `input`, `ring`, `destructive`). Read: `apps/v4/registry/new-york-v4/ui/{button,card,input,badge,table}.tsx` and the v4 globals stylesheet.
- **HeroUI** — https://github.com/heroui-inc/heroui
  Supplies the colour ramps and interaction feel: the 50→900 ramp shape with a 500 DEFAULT step, the green/yellow/blue palettes verbatim, the `content1`–`content4` layered-surface stack, the divider alpha, `defaultLayout`'s font-size/line-height pairs and `boxShadow` small/medium/large, the 250ms `ease` default transition and the 0.97 pressed scale. Read: `packages/core/theme/src/colors/*.ts`, `default-layout.ts`, `utilities/transition.ts`, `components/{button,card,chip}.ts`.

Neither repository is a SysControl-branded asset library — they are generic open-source kits. Everything SysControl-specific (the petroleum-teal brand ramp, the wordmark treatment, the pt-BR copy, the app chrome, both UI kits) was authored here. **Explore both repositories directly for anything this system does not cover** — they carry far more component detail than could be distilled into these files.

**No logo file was supplied.** The wordmark is set in plain type (Sora Bold) next to a Lucide `wrench` glyph in a teal square. Replace it as soon as a real mark exists — see `guidelines/brand-wordmark.card.html`.

**No brand font files were supplied.** Sora, Barlow and Roboto Mono are Google Fonts choices made here, loaded from the Google Fonts CDN in `tokens/fonts.css`. If SysControl has licensed brand faces, send the binaries and the substitution can be swapped out in one file.

---

## Content fundamentals

**Language is pt-BR, always.** Every label, empty state, error and button in the product is Portuguese. Never mix English UI words in ("Dashboard", "Checkout", "Settings") — it is *Painel*, *Finalizar venda*, *Configurações*. Domain nouns stay in the trade's own vocabulary: *peça*, *estoque*, *caixa*, *sangria*, *suprimento*, *balcão*, *orçamento*, *NF-e*, *pedido*.

**Address the user with imperative verbs, not "you".** Buttons and instructions are commands: "Finalizar venda", "Ler código", "Gerar pedido de compra", "Confira o dinheiro em gaveta antes de fechar". The system never says *você* in UI copy and never speaks in the first person ("Vamos começar!", "Estamos carregando…"). It reports state flatly: "Venda #2041 finalizada", "12 peças abaixo do estoque mínimo".

**Sentence case everywhere except the two caps roles.** Labels, buttons, titles and menu items are sentence case ("Nova venda", "Estoque baixo", "Movimentações de hoje"). ALL CAPS with `--tracking-caps` is reserved for exactly two things: table column headers and the small metric captions on `StatCard` / section headings ("FATURAMENTO HOJE", "SITUAÇÃO"). Title Case Like This is never used.

**Numbers carry the meaning, so they get the typography.** Money is always `R$ 14.280,50` — pt-BR formatting, comma decimal, dot thousands, currency symbol with a non-breaking space. Quantities take a unit when ambiguous ("37 un.", "6 itens", "63 pedidos"). Percentages get an explicit sign when they are a delta ("+12,4%", "−4,1%"). Everything numeric renders in the mono face with tabular figures.

**Status vocabulary is fixed.** Reuse these exact strings rather than inventing synonyms:

| State | String | Badge tone |
|---|---|---|
| Sale settled | Pago | success |
| Awaiting payment | Pendente | warning |
| Voided | Cancelado | danger |
| Being picked | Em separação | info |
| Stock healthy | Em estoque | success |
| Below reorder point | Estoque baixo | warning |
| Zero on hand | Esgotado | danger |
| Unsent | Rascunho | neutral |

**Empty states name the next action.** Never "Nenhum resultado." alone. It is "Carrinho vazio / Leia o código de barras para começar." plus a button. Errors state what is wrong and what the number should be: "O fechamento de ontem apresenta diferença de R$ 42,00."

**No emoji, anywhere.** Not in labels, not in empty states, not in notifications. Status is carried by a Badge, a tinted dot, or a Lucide glyph. No exclamation marks either — warnings are stated, not shouted: "12 peças abaixo do estoque mínimo", not "Atenção! Estoque baixo!".

**Tone: matter-of-fact, unhurried, slightly formal.** This is money and inventory; the app never jokes, never congratulates, never uses marketing language. The most enthusiastic it gets is a green Toast that says what happened and offers to undo it.

---

## Visual foundations

**Colour.** One brand colour does the work: a desaturated petroleum teal (`--teal-500` `#0f7391`) that reads as industrial rather than tech-startup. It is the only saturated colour in the chrome — used for primary buttons, active nav, focus rings and the first chart series. The sidebar is `--teal-800` `#063040`, near-black with a teal cast, so the app reads as two zones: a dark rail and a light `--zinc-50` canvas. Everything else is zinc: surfaces white, borders `--zinc-200`, secondary text `--zinc-500`. Semantic colour is functional only — green means money in and stock healthy, yellow means below reorder point, red means cancelled/out/money out. Because red and green carry financial meaning, they never appear decoratively. `--money-positive` and `--money-negative` are separate aliases so a P&L number is never accidentally styled as a "success badge". Never more than two background tones on one screen (canvas + card).

**Type.** Sora for display, Barlow for UI, Roboto Mono for numbers. Sora's tight geometric caps at `-0.03em` tracking give headline numbers (`R$ 14.280,50`) the presence of a readout. Barlow is a condensed-ish grotesque that survives at 13–14px in dense tables — the UI default is **14px/500**, one notch smaller than a consumer app, because these screens hold a lot. Roboto Mono handles every SKU, quantity, price and timestamp with `font-variant-numeric: tabular-nums`, so decimal points line up down a column. The type scale is small at the top: h1 is 44px and appears almost nowhere; the real hierarchy lives between 12px caps captions and 32px metrics.

**Spacing and layout.** Strict 4px grid. Page gutter 24px, card padding 20px (16px on mobile), 16px between cards, 8px between related controls. The desktop shell is fixed: 248px sidebar (64px collapsed), 56px topbar, scrolling content column, `--page-max` 1440px. Content is left-aligned and full-width — never centred in a narrow reading column; a table should use every pixel it is given. Cards do not float on the canvas in a masonry; they sit in explicit grids (4-up stats, 1.7fr/1fr split for chart + list).

**Backgrounds.** Flat colour only. No gradients, no photography, no patterns, no textures, no illustration. The single "graphic" moment in the whole product is the dark teal band behind the headline metric on the mobile Painel, and that is solid `--teal-800`. There is no hero imagery because there is no marketing surface — this is a tool that opens at 08:00 and closes at 18:00.

**Cards.** White `--card`, 1px `--border`, 14px radius (`--radius-xl`), `--shadow-xs`. That is the whole recipe. Interactive cards lift to `--shadow-sm` on hover. Nested surfaces drop the border and use `--content2` instead of stacking another shadow. Controls use the smaller 8px `--radius-md`; badges and chips use `--radius-full`; nothing in the system is a perfect square except the 4px `--radius-xs` checkbox.

**Elevation.** Four rungs, each with one job: `--shadow-xs` cards and inputs, `--shadow-sm` card hover, `--shadow-medium` toasts and tooltips, `--shadow-large` modals. HeroUI's three-layer shadow recipe is used verbatim for the overlay rungs. Shadows are never coloured and never used to separate two things a border could separate.

**Borders.** 1px is the default and carries most of the separation work — table rows, card edges, panel splits, the topbar rule. 2px appears only as the active tab underline. 3px only as the focus ring. Dashed borders are not used.

**Motion.** Fast and unshowy. 250ms `ease` for colour, background and opacity (HeroUI's default). 150ms for transforms and the focus ring. 120ms for the table-row hover tint, so scanning a list never feels laggy. `cubic-bezier(0.16,1,0.3,1)` for anything that travels distance — the switch thumb, the bottom sheet, a progress bar filling. No bounce, no spring, no stagger, no entrance animations on page load. The one continuous animation is the 700ms linear spinner arc; the one repeating one is the 1.4s skeleton shimmer.

**Hover.** Filled buttons darken one ramp step (`--primary` → `--primary-hover`). Ghost and outline controls take an `--accent` (`--zinc-100`) wash. Table rows tint `--zinc-50`. Cards lift a shadow rung. Opacity is never used as a hover effect — only as a disabled state (`--disabled-opacity: 0.5`).

**Press.** `scale(0.97)` on buttons and icon buttons, 150ms — HeroUI's value. No colour change on press beyond the hover state already applied. Tap targets on mobile are never below 44px.

**Focus.** A 3px ring in `--ring` at 25% opacity plus a solid `--ring` border, per shadcn/ui. Focus is always visible — this is a keyboard-and-barcode product where operators tab through a sale without touching the mouse.

**Transparency and blur.** Almost never. Two exceptions: the modal scrim (`rgba(0,0,0,0.5)` with a 2px backdrop blur) and the sidebar's `rgba(255,255,255,0.08)` internal rules. There is no frosted-glass chrome, no translucent header, no protection gradient — because there is no imagery under anything.

**Imagery.** There is none, by design. Products are represented by their SKU and name, not photos; where a thumbnail slot exists in the mobile list it is a grey square with a Lucide `package` glyph. If real part photography is ever added, it should be neutral, evenly lit, on white, cropped square — never warm-filtered or dramatically lit.

**Dark mode** is a full second theme, not an inversion. Add `class="dark"` to `<html>` or any ancestor and every alias re-points: canvas `#111113`, cards `--zinc-900`, primary lifts to `--teal-400` (the 500 is too dark to read on a dark surface) with a near-black `--primary-foreground`, and the semantic tones move to their 400/500 steps with dark foregrounds so a green "Finalizar venda" button stays legible. Soft tones become low-alpha washes of their hue rather than the light theme's tinted 50-step, borders become `rgba(255,255,255,0.10)`, and shadows deepen to 40–50% black with a 1px inset white highlight — HeroUI's dark-surface treatment. Both UI kits ship a moon/sun toggle in the topbar (mobile: the app bar) that persists to `localStorage`.

Because of that, **components must never reference a raw ramp step** (`--zinc-200`, `--teal-100`, `--yellow-600`). Every interaction value has an alias that flips with the theme: `--hover-surface`, `--secondary-hover`, `--primary-soft-hover`, `--danger-hover`, `--success-hover`, `--ring-shadow`, the five `--*-soft-border` pairs, `--switch-track` / `--switch-thumb`, `--tooltip` / `--tooltip-foreground`, `--icon-muted`, `--skeleton-from` / `--skeleton-to`, the three `--avatar-*` tints, and the `--sidebar-*` internals. Reach for the alias; if one is missing, add it to both scopes rather than hardcoding.

---

## Iconography

**Lucide, exclusively** — the icon set shadcn/ui ships with, loaded from CDN (`https://unpkg.com/lucide@0.469.0/dist/umd/lucide.js`) and wrapped by the `Icon` component. Nothing in this system is a hand-drawn SVG.

- **Stroke 2px, `currentColor`, square 24 viewBox.** Active sidebar items bump to 2.2 so the current section reads slightly heavier without changing colour alone.
- **Sizes are fixed by context:** 12px inside a Badge, 14px in a small Button, 16px in a default control or table cell, 18px in the sidebar and IconButton, 20–22px in mobile tab bars and empty-state discs.
- **The working vocabulary:** `layout-dashboard` (painel), `shopping-cart` (PDV), `receipt` (vendas), `banknote` (caixa), `package` (estoque/peça), `users` (clientes), `truck` (fornecedores/pedido de compra), `chart-column` (relatórios), `settings`, `barcode` (leitura de código), `wrench` (the brand mark), `triangle-alert` / `circle-alert` / `circle-check` / `info` (the four alert tones, chosen by tone — never overridden), `arrow-down-left` / `arrow-up-right` (entrada / saída de caixa), `chevrons-up-down` (sortable column), `more-horizontal` (row actions).
- **No emoji is ever used as an icon**, and no Unicode glyphs stand in for icons — the only non-Lucide symbols in the product are the currency prefix `R$`, the minus sign `−` in negative money, and the `*` on required field labels.
- **No icon font, no sprite sheet, no PNG icons.** If Lucide lacks a glyph, compose from two Lucide glyphs or use a text label; do not draw one.

The Lucide substitution is flagged: **neither source repository shipped a SysControl-owned icon set**, so Lucide was chosen because shadcn/ui — one of the two references — is built on it. If SysControl has its own glyphs, they should replace the CDN link.

---

## Index

**Foundations**
- `styles.css` — the single entry point consumers link. `@import` lines only.
- `tokens/colors.css` · `typography.css` · `spacing.css` · `radius.css` · `elevation.css` · `motion.css` · `semantic.css` · `fonts.css`
- `guidelines/*.card.html` — 19 specimen cards (Colors, Type, Spacing, Brand) rendered in the Design System tab.
- `thumbnail.html` — the project tile.

**Components** — `components/<group>/<Name>.{jsx,d.ts,prompt.md}`, one `@dsCard` HTML per group.
- `core/` — Button, IconButton, Badge, Chip, Card (+ CardHeader, CardFooter), Divider, Avatar, Spinner, Icon
- `forms/` — Field, Input, Textarea, Select, Checkbox, Switch, RadioGroup
- `data/` — DataTable, StatCard, Progress, Pagination, EmptyState, Skeleton
- `feedback/` — Alert, Modal, Tooltip, Toast
- `navigation/` — Sidebar, Topbar (+ TopbarStatus), Tabs, Breadcrumbs

**UI kits**
- `ui_kits/web_app/` — desktop app. `index.html` (shell + nav), `Dashboard.jsx`, `Pdv.jsx`, `Estoque.jsx`, `Caixa.jsx`, `Vendas.jsx` (Vendas + Clientes), `data.js` (shared fixtures).
- `ui_kits/mobile_app/` — phone app. `index.html`, `Screens.jsx` (Painel, PDV, Estoque, Caixa, Mais + StatusBar/AppBar/TabBar/Sheet chrome). Reuses `web_app/data.js`.

**Other**
- `SKILL.md` — Agent Skills entry point.
- `github.md` — source-repo association for one-click upstream sync.

### Intentional additions

The two source repositories are generic kits, not a SysControl inventory, so the component list was scoped to what the product's six screens actually need. Three entries exist that neither repo defines as such:

- **`Icon`** — a thin wrapper over Lucide so every glyph in the system inherits one stroke weight and size scale.
- **`StatCard`** — the dashboard KPI tile. Composed from primitives in both sources, but frequent enough in SysControl to deserve a contract.
- **`Sidebar` / `Topbar` / `TopbarStatus`** — the app chrome. shadcn/ui's sidebar block is a different architecture; these are SysControl's own, sized to `--sidebar-w` / `--topbar-h`.
