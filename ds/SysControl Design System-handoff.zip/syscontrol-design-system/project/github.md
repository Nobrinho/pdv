repo: shadcn-ui/ui
branch: main

## Also referenced
repo: heroui-inc/heroui
branch: main
path: packages/core/theme/src

## Last sync
date: 2026-08-06T00:00:00Z

### Updated in this project
- Control geometry, radius scale, shadow-xs/sm and semantic slot names taken from shadcn/ui v4 registry primitives.
- Colour ramps, content1-4 surface stack, font-size/line-height pairs, 250ms ease transition and 0.97 press scale taken from the HeroUI theme package.
- SysControl's own petroleum-teal primary ramp, pt-BR content rules and app chrome authored on top.
- Web and mobile UI kits built from the resulting token set.

## Screen map
| Project screen / file | Repo files it was built from |
| --- | --- |
| tokens/radius.css, tokens/elevation.css, tokens/spacing.css | shadcn-ui/ui: apps/v4/registry/new-york-v4/ui/{button,card,input,badge,table}.tsx; templates/react-router-monorepo/packages/ui/src/styles/globals.css |
| tokens/colors.css, tokens/typography.css, tokens/motion.css, tokens/semantic.css | heroui-inc/heroui: packages/core/theme/src/colors/*.ts, default-layout.ts, utilities/transition.ts |
| components/core/*, components/forms/* | shadcn-ui/ui button/input/badge/card primitives; heroui-inc/heroui components/{button,card,chip}.ts |
| components/data/DataTable.jsx | shadcn-ui/ui: apps/v4/registry/new-york-v4/ui/table.tsx |
| ui_kits/web_app/*, ui_kits/mobile_app/* | Composed from this project's own components; no direct repo counterpart |
